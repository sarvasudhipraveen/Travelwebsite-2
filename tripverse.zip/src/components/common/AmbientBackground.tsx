import React from 'react';
import { motion } from 'motion/react';

interface AmbientBackgroundProps {
  variant?: 'hero' | 'subtle' | 'page';
  className?: string;
  children?: React.ReactNode;
}

export const AmbientBackground: React.FC<AmbientBackgroundProps> = ({
  variant = 'hero',
  className = '',
  children
}) => {
  if (variant === 'page') {
    return (
      <div className={`relative overflow-hidden ${className}`}>
        {/* Multi-color ambient background layer */}
        <div className="absolute inset-0 pointer-events-none -z-10 overflow-hidden">
          <div className="absolute -top-32 -left-32 w-96 h-96 bg-cyan-400/10 rounded-full blur-[100px]" />
          <div className="absolute top-1/4 -right-32 w-96 h-96 bg-amber-400/10 rounded-full blur-[120px]" />
          <div className="absolute top-1/2 left-1/4 w-80 h-80 bg-emerald-400/8 rounded-full blur-[110px]" />
          <div className="absolute -bottom-20 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[130px]" />
          <div className="absolute bottom-10 -left-20 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px]" />
        </div>
        {children}
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white ${className}`}
    >
      {/* Dynamic multi-color ambient lighting mesh */}
      <motion.div
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.25, 0.35, 0.25],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute -top-24 -right-20 w-[420px] h-[420px] bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full blur-[90px] pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.18, 0.28, 0.18],
        }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
        className="absolute top-1/3 -left-24 w-[380px] h-[380px] bg-gradient-to-tr from-amber-500 to-rose-500 rounded-full blur-[100px] pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.15, 0.22, 0.15],
        }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay: 4 }}
        className="absolute -bottom-20 right-1/4 w-[360px] h-[360px] bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full blur-[110px] pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.25, 1],
          opacity: [0.12, 0.2, 0.12],
        }}
        transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        className="absolute top-10 left-1/2 -translate-x-1/2 w-[340px] h-[340px] bg-gradient-to-b from-purple-500 to-indigo-600 rounded-full blur-[120px] pointer-events-none"
      />

      {/* Subtle travel wanderlust grid overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Foreground content */}
      <div className="relative z-10">{children}</div>
    </div>
  );
};
