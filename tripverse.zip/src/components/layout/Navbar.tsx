import { Link, useLocation } from 'react-router-dom';
import { Plane, Hotel, Train, Bus, Car, Bike, Mountain, User, LogOut, Menu, X, Sun, Moon } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../lib/AuthContext';
import { useCurrency } from '../../lib/CurrencyContext';
import { useTheme } from '../../lib/ThemeContext';

const navItems = [
  { name: 'Flights', icon: Plane, path: '/flights' },
  { name: 'Hotels', icon: Hotel, path: '/hotels' },
  { name: 'Trains', icon: Train, path: '/trains' },
  { name: 'Buses', icon: Bus, path: '/buses' },
  { name: 'Holidays', icon: Mountain, path: '/holidays' },
  { name: 'Cars & Cabs', icon: Car, path: '/cabs' },
  { name: 'Bikes & Scooters', icon: Bike, path: '/bikes' },
];

export function Navbar({ user: propUser }: { user?: any }) {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { user: authUser, logout } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const { theme, toggleTheme } = useTheme();
  const user = propUser || authUser;

  return (
    <nav className="h-16 bg-white border-b border-[#E0E4E9] flex items-center justify-between px-6 md:px-10 sticky top-0 z-[100]">
      <Link to="/" className="flex items-center gap-2 text-2xl font-extrabold text-brand tracking-tighter shrink-0">
        <span>✈️</span>
        TripVerse
      </Link>

      <div className="hidden lg:flex items-center gap-7">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.name}
              to={item.path}
              className={cn(
                "flex items-center gap-1.5 text-xs font-black transition-all duration-200 py-5 border-b-2 border-transparent",
                isActive ? "text-brand border-brand" : "text-text-secondary hover:text-brand"
              )}
            >
              <item.icon size={16} />
              {item.name}
            </Link>
          );
        })}
      </div>

      <div className="flex items-center gap-3">
        {/* Global Persistent Currency Switcher */}
        <div className="flex items-center bg-gray-100 p-1 rounded-xl border border-gray-200/90 shadow-2xs">
          <button
            type="button"
            onClick={() => setCurrency('INR')}
            className={cn(
              "px-2.5 py-1 text-xs font-black rounded-lg transition-all flex items-center gap-1 cursor-pointer select-none",
              currency === 'INR'
                ? "bg-brand text-white shadow-xs"
                : "text-gray-600 hover:text-gray-900"
            )}
            title="Switch global currency to Indian Rupee (₹)"
          >
            <span>₹</span>
            <span className="text-[11px] font-bold">INR</span>
          </button>
          <button
            type="button"
            onClick={() => setCurrency('USD')}
            className={cn(
              "px-2.5 py-1 text-xs font-black rounded-lg transition-all flex items-center gap-1 cursor-pointer select-none",
              currency === 'USD'
                ? "bg-brand text-white shadow-xs"
                : "text-gray-600 hover:text-gray-900"
            )}
            title="Switch global currency to US Dollar ($)"
          >
            <span>$</span>
            <span className="text-[11px] font-bold">USD</span>
          </button>
        </div>

        {/* Dark / Light Theme Switcher */}
        <button
          type="button"
          onClick={toggleTheme}
          className="p-2 rounded-xl border border-gray-200 bg-gray-100 text-gray-700 hover:text-brand hover:scale-105 transition-all shadow-2xs cursor-pointer flex items-center justify-center"
          title={theme === 'dark' ? "Switch to Light Theme" : "Switch to Dark Theme"}
          aria-label="Toggle Light and Dark Theme"
        >
          {theme === 'dark' ? (
            <Sun size={17} className="text-amber-400" />
          ) : (
            <Moon size={17} className="text-slate-700" />
          )}
        </button>

        {user ? (
          <div className="flex items-center gap-3">
             <Link to="/dashboard" className="flex items-center gap-2 bg-[#f0f7ff] hover:bg-[#e0f0ff] px-3.5 py-1.5 rounded-xl transition-colors group border border-blue-100">
              <div className="w-8 h-8 rounded-full bg-brand flex items-center justify-center text-white font-bold overflow-hidden text-xs shadow-sm">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  user.displayName?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || 'U'
                )}
              </div>
              <div className="hidden sm:block text-left">
                <span className="text-xs font-black text-brand block leading-tight">
                  {user.displayName?.split(' ')[0] || 'My Trip'}
                </span>
                <span className="text-[10px] text-gray-500 font-medium">Dashboard</span>
              </div>
            </Link>
            <button 
              onClick={() => logout()}
              className="p-2 text-text-secondary hover:text-accent hover:bg-red-50 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut size={18} />
            </button>
          </div>
        ) : (
          <Link to="/login" className="bg-[#008CFF] text-white px-4 py-2 rounded-xl text-xs sm:text-sm font-bold hover:bg-[#0070cc] transition-all shadow-sm shrink-0">
            Sign In
          </Link>
        )}
        
        <button className="lg:hidden p-2 text-gray-700" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-16 left-0 w-full bg-white border-b border-[#E0E4E9] p-6 lg:hidden flex flex-col gap-4 shadow-xl z-50"
          >
             {/* Mobile Currency Switcher */}
             <div className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-xl mb-2">
               <span className="text-xs font-black text-gray-700">Display Currency</span>
               <div className="flex items-center bg-gray-200/80 p-0.5 rounded-lg">
                 <button
                   onClick={() => setCurrency('INR')}
                   className={cn(
                     "px-3 py-1 text-xs font-black rounded-md transition-all",
                     currency === 'INR' ? "bg-white text-brand shadow-xs" : "text-gray-600"
                   )}
                 >
                   ₹ INR
                 </button>
                 <button
                   onClick={() => setCurrency('USD')}
                   className={cn(
                     "px-3 py-1 text-xs font-black rounded-md transition-all",
                     currency === 'USD' ? "bg-white text-brand shadow-xs" : "text-gray-600"
                   )}
                 >
                   $ USD
                 </button>
               </div>
             </div>

             {/* Mobile Theme Switcher */}
             <div className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-xl mb-2">
               <span className="text-xs font-black text-gray-700">Theme Mode</span>
               <button
                 type="button"
                 onClick={toggleTheme}
                 className="flex items-center gap-2 px-3 py-1.5 text-xs font-black rounded-lg bg-white border border-gray-200 text-gray-800 shadow-2xs cursor-pointer"
               >
                 {theme === 'dark' ? (
                   <>
                     <Sun size={15} className="text-amber-400" />
                     <span>Dark Theme</span>
                   </>
                 ) : (
                   <>
                     <Moon size={15} className="text-slate-700" />
                     <span>Light Theme</span>
                   </>
                 )}
               </button>
             </div>

             {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-3 text-lg font-bold text-text-secondary hover:text-brand transition-colors py-1"
              >
                <item.icon size={20} />
                {item.name}
              </Link>
            ))}
            <div className="pt-4 border-t border-gray-100">
              {user ? (
                <div className="flex items-center justify-between">
                  <Link to="/dashboard" onClick={() => setIsOpen(false)} className="font-bold text-brand flex items-center gap-2">
                    <User size={18} /> {user.displayName || 'My Dashboard'}
                  </Link>
                  <button onClick={() => { logout(); setIsOpen(false); }} className="text-sm text-red-500 font-bold">
                    Logout
                  </button>
                </div>
              ) : (
                <Link to="/login" onClick={() => setIsOpen(false)} className="w-full text-center block bg-brand text-white py-2.5 rounded-xl font-bold">
                  Sign In / Register
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

