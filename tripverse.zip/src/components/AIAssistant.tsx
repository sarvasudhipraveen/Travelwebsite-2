import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  RotateCcw,
  Compass,
  Users,
  Plane,
  ChevronRight
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';
import { useTheme } from '../lib/ThemeContext';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp?: string;
}

const QUICK_PROMPTS = [
  "How does ticket price scale for 4 passengers?",
  "Best luxury hotels with ocean view in Goa",
  "Compare Flight vs Vande Bharat Train to Delhi",
  "Car rental with chauffeur allowance & fuel"
];

export const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: "👋 **Hello! I'm TripBot**, your real-time TripVerse AI Travel Assistant.\n\nAsk me about flights, hotels, trains, cars, or how **pricing adjusts dynamically with the number of persons**!",
      timestamp: 'Just now'
    }
  ]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { theme } = useTheme();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chat, loading]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen]);

  const handleSend = async (userText?: string) => {
    const textToSend = userText || message;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = { 
      role: 'user', 
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newHistory = [...chat, userMsg];
    setChat(newHistory);
    setMessage('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: newHistory.map(c => ({
            role: c.role === 'model' ? 'model' : 'user',
            parts: [{ text: c.text }]
          }))
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const botMsg: ChatMessage = {
        role: 'model',
        text: data.text || "I'm here to help with your trip details. Please feel free to ask about destinations, routes, or fares!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChat(prev => [...prev, botMsg]);
    } catch (error) {
      console.error('Chat error:', error);
      setChat(prev => [
        ...prev, 
        { 
          role: 'model', 
          text: "I'm currently connected to real-time TripVerse intelligence. Try asking about our **Flight routes**, **Hotel guest tariffs**, or **Multi-passenger price discounts**!",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setChat([
      {
        role: 'model',
        text: "✨ Chat refreshed. What travel journey can I help you plan next?",
        timestamp: 'Just now'
      }
    ]);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[150]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 25, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 25, scale: 0.92 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className={cn(
              "absolute bottom-20 right-0 w-[420px] max-w-[calc(100vw-32px)] h-[580px] max-h-[80vh]",
              "rounded-3xl shadow-2xl border flex flex-col overflow-hidden backdrop-blur-xl",
              theme === 'dark' 
                ? "bg-[#0F172A]/95 border-[#1E293B] text-slate-100 shadow-cyan-950/40" 
                : "bg-white/95 border-gray-200 text-gray-900 shadow-2xl"
            )}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] p-5 text-white flex items-center justify-between shrink-0 shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/15 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20 shadow-inner">
                  <Bot size={22} className="text-cyan-300" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-base tracking-tight">TripBot Real-Time</h3>
                    <span className="bg-cyan-400/20 text-cyan-200 text-[9px] font-black uppercase px-2 py-0.5 rounded-full border border-cyan-300/30">
                      Gemini 3.8
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
                    <span className="text-[10px] font-bold text-blue-100 uppercase tracking-wider">
                      Live AI Travel Advisor
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleReset}
                  className="hover:bg-white/15 p-2 rounded-xl text-white/80 hover:text-white transition-all cursor-pointer"
                  title="Reset Conversation"
                >
                  <RotateCcw size={16} />
                </button>
                <button 
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-white/15 p-2 rounded-xl text-white/80 hover:text-white transition-all cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Chat Messages Body */}
            <div 
              ref={scrollRef} 
              className={cn(
                "flex-1 overflow-y-auto p-4 space-y-4 text-xs font-medium scrollbar-thin",
                theme === 'dark' ? "bg-[#0B1220]" : "bg-slate-50/80"
              )}
            >
              {chat.map((msg, i) => {
                const isUser = msg.role === 'user';
                return (
                  <div 
                    key={i} 
                    className={cn(
                      "flex items-start gap-2.5",
                      isUser ? "flex-row-reverse" : "flex-row"
                    )}
                  >
                    <div className={cn(
                      "w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-white shadow-2xs mt-0.5",
                      isUser 
                        ? "bg-gradient-to-tr from-blue-600 to-indigo-600" 
                        : "bg-gradient-to-tr from-cyan-600 to-blue-700"
                    )}>
                      {isUser ? <User size={14} /> : <Bot size={14} />}
                    </div>

                    <div className={cn(
                      "p-3.5 rounded-2xl max-w-[82%] leading-relaxed shadow-xs text-xs space-y-1.5",
                      isUser 
                        ? "bg-[#008CFF] text-white rounded-tr-none font-semibold" 
                        : theme === 'dark'
                          ? "bg-[#1E293B] text-slate-100 rounded-tl-none border border-slate-700/60"
                          : "bg-white text-gray-800 rounded-tl-none border border-gray-200"
                    )}>
                      <div className="prose prose-xs dark:prose-invert max-w-none text-xs">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                      {msg.timestamp && (
                        <div className={cn(
                          "text-[9px] font-bold text-right opacity-60 select-none pt-0.5",
                          isUser ? "text-blue-100" : "text-gray-400"
                        )}>
                          {msg.timestamp}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {loading && (
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-700 text-white flex items-center justify-center shrink-0">
                    <Bot size={14} />
                  </div>
                  <div className={cn(
                    "p-3.5 rounded-2xl rounded-tl-none border shadow-xs flex items-center gap-1.5",
                    theme === 'dark' ? "bg-[#1E293B] border-slate-700" : "bg-white border-gray-200"
                  )}>
                    <span className="text-[11px] font-bold text-cyan-500 mr-1">Thinking</span>
                    <span className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce" />
                  </div>
                </div>
              )}
            </div>

            {/* Quick Suggestions Chips */}
            <div className={cn(
              "px-3 py-2 border-t flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0",
              theme === 'dark' ? "bg-[#0F172A] border-[#1E293B]" : "bg-white border-gray-100"
            )}>
              <span className="text-[10px] font-black uppercase text-brand flex items-center gap-1 shrink-0">
                <Sparkles size={11} /> Quick:
              </span>
              {QUICK_PROMPTS.map((prompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSend(prompt)}
                  disabled={loading}
                  className={cn(
                    "text-[10px] font-bold px-2.5 py-1 rounded-full whitespace-nowrap transition-all border shrink-0 cursor-pointer",
                    theme === 'dark'
                      ? "bg-[#1E293B] text-slate-300 border-slate-700 hover:border-cyan-400 hover:text-white"
                      : "bg-slate-100 text-slate-700 border-slate-200 hover:border-brand hover:text-brand"
                  )}
                >
                  {prompt}
                </button>
              ))}
            </div>

            {/* Input Box */}
            <div className={cn(
              "p-3 border-t flex items-center gap-2 shrink-0",
              theme === 'dark' ? "bg-[#0F172A] border-[#1E293B]" : "bg-white border-gray-200"
            )}>
              <input 
                ref={inputRef}
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask TripBot about trips, passenger fares..." 
                disabled={loading}
                className={cn(
                  "flex-1 rounded-xl px-3.5 py-2.5 text-xs font-semibold outline-none transition-all border",
                  theme === 'dark'
                    ? "bg-[#1E293B] text-white border-slate-700 focus:border-cyan-400 placeholder:text-slate-500"
                    : "bg-slate-50 text-gray-900 border-gray-200 focus:border-brand placeholder:text-gray-400"
                )}
              />
              <button 
                type="button"
                onClick={() => handleSend()}
                disabled={loading || !message.trim()}
                className="bg-brand text-white p-2.5 rounded-xl hover:bg-brand-dark transition-all shadow-md shadow-brand/30 disabled:scale-95 disabled:opacity-40 cursor-pointer"
              >
                <Send size={16} />
              </button>
            </div>
            
            {/* Footer Badge */}
            <div className={cn(
              "text-[9px] text-center py-1 font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 shrink-0 select-none",
              theme === 'dark' ? "bg-[#090D16] text-slate-500" : "bg-slate-100 text-slate-500"
            )}>
              <Sparkles size={10} className="text-cyan-400" />
              <span>Real-Time Gemini AI • Dynamic Person Calculation Enabled</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Launcher Button */}
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.94 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-gradient-to-r from-brand to-[#0056b3] text-white rounded-2xl shadow-xl shadow-brand/40 flex items-center justify-center transition-all relative z-[150] cursor-pointer border border-white/20"
        aria-label="Open AI Assistant"
      >
        {isOpen ? <X size={26} /> : <Bot size={28} className="animate-pulse" />}
        {!isOpen && (
          <span className="absolute -top-1.5 -right-1.5 bg-accent text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-md animate-bounce">
            AI BOT
          </span>
        )}
      </motion.button>
    </div>
  );
};
