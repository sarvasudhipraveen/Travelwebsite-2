import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext';
import { Plane, Shield } from 'lucide-react';
import { motion } from 'motion/react';

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center bg-[#F2F5F8] p-6">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
          className="w-16 h-16 rounded-full border-4 border-[#008CFF]/20 border-t-[#008CFF] flex items-center justify-center mb-4 shadow-lg shadow-blue-500/10"
        >
          <Plane className="text-brand" size={24} />
        </motion.div>
        <h3 className="text-lg font-black text-gray-800 tracking-tight">Verifying Traveler Session...</h3>
        <p className="text-xs text-gray-500 font-medium mt-1">Connecting to TripVerse secure traveler services</p>
      </div>
    );
  }

  if (!user) {
    // Redirect to login page while saving the attempted destination
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};
