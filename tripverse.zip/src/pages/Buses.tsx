import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bus, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  Star, 
  Search, 
  SlidersHorizontal, 
  RotateCcw, 
  CheckCircle2, 
  Printer, 
  X, 
  ArrowRight, 
  Sparkles, 
  Wifi, 
  Zap, 
  User, 
  Info 
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';

interface BusRoute {
  id: string;
  operator: string;
  type: 'Volvo Multi-Axle Sleeper' | 'Scania Luxury' | 'Mercedes AC Sleeper' | 'BharatBenz Glider';
  from: string;
  to: string;
  dep: string;
  arr: string;
  duration: string;
  priceInr: number;
  rating: number;
  reviewsCount: number;
  availableSeats: number;
  image: string;
  amenities: string[];
}

const busesData: BusRoute[] = [
  {
    id: 'b1',
    operator: 'Zingbus Premium Lounge',
    type: 'Volvo Multi-Axle Sleeper',
    from: 'Delhi (Kashmere Gate)',
    to: 'Manali (Mall Road)',
    dep: '20:30',
    arr: '08:00',
    duration: '11h 30m',
    priceInr: 1250,
    rating: 4.8,
    reviewsCount: 840,
    availableSeats: 14,
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1000&q=80',
    amenities: ['Individual USB & AC Vents', 'Clean Bedding & Blanket', 'Live Bus Tracking', 'Emergency SOS']
  },
  {
    id: 'b2',
    operator: 'IntrCity SmartBus Executive',
    type: 'Mercedes AC Sleeper',
    from: 'Bengaluru (Majestic)',
    to: 'Goa (Panaji)',
    dep: '21:00',
    arr: '07:30',
    duration: '10h 30m',
    priceInr: 1650,
    rating: 4.9,
    reviewsCount: 1120,
    availableSeats: 8,
    image: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=1000&q=80',
    amenities: ['Private Capsule Berth', 'High Speed WiFi', 'Complimentary Water & Snack', 'Air Suspension']
  },
  {
    id: 'b3',
    operator: 'RedBus Go Intercity',
    type: 'BharatBenz Glider',
    from: 'Delhi (ISBT)',
    to: 'Rishikesh (Tapovan)',
    dep: '23:00',
    arr: '05:30',
    duration: '6h 30m',
    priceInr: 780,
    rating: 4.7,
    reviewsCount: 650,
    availableSeats: 22,
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1000&q=80',
    amenities: ['Pushback Recliners', 'Reading Lights', 'Luggage Compartment', 'Sanitized Cabin']
  }
];

export default function Buses() {
  const { user } = useAuth();
  const { currency, convertInr } = useCurrency();

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOperator, setSelectedOperator] = useState('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'ratingDesc'>('recommended');

  // Booking Modal
  const [selectedBus, setSelectedBus] = useState<BusRoute | null>(null);
  const [seatCount, setSeatCount] = useState(1);
  const [passengerName, setPassengerName] = useState(user?.displayName || '');
  const [passengerPhone, setPassengerPhone] = useState(user?.phoneNumber || '');
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);

  const bookingPrices = useMemo(() => {
    if (!selectedBus) return { baseInr: 0, discountInr: 0, taxInr: 0, totalInr: 0 };
    const baseInr = selectedBus.priceInr * seatCount;
    const discountInr = Math.round(baseInr * 0.10);
    const taxInr = Math.round((baseInr - discountInr) * 0.05);
    const totalInr = (baseInr - discountInr) + taxInr;
    return { baseInr, discountInr, taxInr, totalInr };
  }, [selectedBus, seatCount]);

  const filteredBuses = useMemo(() => {
    return busesData
      .filter((bus) => {
        const matchOperator = selectedOperator === 'All' || bus.operator.includes(selectedOperator);
        const matchSearch = !searchQuery || 
          bus.operator.toLowerCase().includes(searchQuery.toLowerCase()) ||
          bus.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
          bus.to.toLowerCase().includes(searchQuery.toLowerCase()) ||
          bus.type.toLowerCase().includes(searchQuery.toLowerCase());
        return matchOperator && matchSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'priceAsc') return a.priceInr - b.priceInr;
        if (sortBy === 'ratingDesc') return b.rating - a.rating;
        return 0;
      });
  }, [selectedOperator, searchQuery, sortBy]);

  const handleConfirmBus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBus) return;
    const bookingId = 'TV-BUS-' + Math.floor(100000 + Math.random() * 900000);
    setBookingConfirmed({
      bookingId,
      bus: selectedBus,
      seatCount,
      seatNumbers: Array.from({ length: seatCount }, (_, i) => `L-${12 + i}`).join(', '),
      passengerName: passengerName.trim() || 'Passenger',
      passengerPhone: passengerPhone.trim() || '+91 98765 43210',
      pricing: bookingPrices
    });
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-24 relative overflow-hidden">
      {/* Multi-Color Tourism Ambient Effects */}
      <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      <div className="absolute top-20 -left-20 w-80 h-80 bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute top-32 right-10 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-96 left-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-[110px] pointer-events-none" />

      {/* Hero */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Bus size={15} /> Luxury Intercity Bus Travels
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Book AC Sleeper & Volvo Multi-Axle Buses
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            Direct departures from Zingbus, IntrCity SmartBus & RedBus Go with live tracking and GPS berths.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-5 border border-[#E0E4E9] grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
            <Search size={16} className="text-gray-400 mr-2 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search destination or operator..."
              className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
            />
          </div>

          <div>
            <select
              value={selectedOperator}
              onChange={(e) => setSelectedOperator(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
            >
              <option value="All">All Operators</option>
              <option value="Zingbus">Zingbus Premium</option>
              <option value="IntrCity">IntrCity SmartBus</option>
              <option value="RedBus">RedBus Go</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
            >
              <option value="recommended">Recommended</option>
              <option value="priceAsc">Fare: Low to High</option>
              <option value="ratingDesc">Highest Customer Rating</option>
            </select>
            {(searchQuery || selectedOperator !== 'All' || sortBy !== 'recommended') && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedOperator('All');
                  setSortBy('recommended');
                }}
                className="p-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl text-gray-600 transition-colors cursor-pointer"
                title="Reset filters"
              >
                <RotateCcw size={16} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Buses List */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="grid grid-cols-1 gap-6">
          {filteredBuses.map((bus) => {
            const price = convertInr(bus.priceInr);
            return (
              <motion.div
                key={bus.id}
                whileHover={{ scale: 1.008 }}
                className="bg-white rounded-3xl border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 justify-between"
              >
                <div className="flex items-center gap-5 w-full md:w-1/3">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 bg-gray-100 shadow-sm">
                    <img src={bus.image} alt={bus.operator} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-gray-900">{bus.operator}</h3>
                    <p className="text-xs text-text-secondary font-bold">{bus.type}</p>
                    <div className="flex items-center gap-1 text-yellow-500 font-bold text-xs mt-1">
                      <Star size={12} fill="currentColor" />
                      <span>{bus.rating}</span>
                      <span className="text-gray-400 font-normal">({bus.reviewsCount} reviews)</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between w-full md:flex-1 px-0 md:px-8 border-y md:border-y-0 md:border-x border-gray-100 py-4 md:py-0">
                  <div>
                    <p className="text-2xl font-black text-gray-900">{bus.dep}</p>
                    <p className="text-xs text-text-secondary font-medium">{bus.from}</p>
                  </div>
                  <div className="text-center px-4">
                    <span className="text-[10px] font-black text-gray-400 uppercase">{bus.duration}</span>
                    <div className="w-24 h-[2px] bg-gray-200 mx-auto my-1" />
                    <span className="text-[10px] text-green-700 font-bold">{bus.availableSeats} Seats Available</span>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-black text-gray-900">{bus.arr}</p>
                    <p className="text-xs text-text-secondary font-medium">{bus.to}</p>
                  </div>
                </div>

                <div className="flex items-center gap-6 w-full md:w-auto">
                  <div className="text-right flex-1 md:flex-none">
                    <p className="text-3xl font-black text-brand leading-none">{price.primaryFormatted}</p>
                    <p className="text-[11px] font-bold text-gray-500 mt-1">({price.secondaryFormatted})</p>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedBus(bus);
                      setBookingConfirmed(null);
                    }}
                    className="bg-brand text-white px-7 py-3 rounded-xl font-black text-xs shadow-md hover:bg-brand-dark transition-all flex items-center gap-2 cursor-pointer"
                  >
                    BOOK SEATS <ArrowRight size={14} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Bus Modal */}
      <AnimatePresence>
        {selectedBus && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden relative my-auto border border-[#E0E4E9]"
            >
              <button
                onClick={() => setSelectedBus(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="bg-gradient-to-r from-[#041422] to-[#008CFF] p-6 text-white">
                <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded-md inline-block mb-1">
                  Bus Ticket Reservation
                </span>
                <h3 className="text-2xl font-black">{selectedBus.operator}</h3>
                <p className="text-white/80 text-xs font-semibold mt-1">
                  {selectedBus.from} ➔ {selectedBus.to} • {selectedBus.type}
                </p>
              </div>

              <div className="p-6">
                {!bookingConfirmed ? (
                  <form onSubmit={handleConfirmBus} className="space-y-4 text-xs">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[10px] font-black uppercase text-gray-500">Passengers / Seats</label>
                        <span className="text-[10px] font-bold text-brand">Money Scales with Persons</span>
                      </div>
                      <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5">
                        <button
                          type="button"
                          onClick={() => setSeatCount(Math.max(1, seatCount - 1))}
                          className="w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-800 font-black text-sm hover:bg-gray-100 flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                          title="Decrease person (reduces total money)"
                        >
                          -
                        </button>
                        <div className="text-center px-2">
                          <span className="text-xs font-black text-gray-900 block">{seatCount} Passenger{seatCount > 1 ? 's' : ''}</span>
                          <span className="text-[9px] text-gray-500 font-semibold">{seatCount} Seat{seatCount > 1 ? 's' : ''} reserved</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSeatCount(Math.min(6, seatCount + 1))}
                          className="w-8 h-8 rounded-lg bg-brand text-white font-black text-sm hover:bg-brand-dark flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                          title="Increase person (increases total money)"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Lead Passenger Name</label>
                      <input
                        type="text"
                        required
                        value={passengerName}
                        onChange={(e) => setPassengerName(e.target.value)}
                        placeholder="John Doe"
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Phone Number</label>
                      <input
                        type="tel"
                        required
                        value={passengerPhone}
                        onChange={(e) => setPassengerPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold outline-none"
                      />
                    </div>

                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Bus Fare ({seatCount} Seat x {selectedBus.type}):</span>
                        <span className="font-bold">{convertInr(bookingPrices.baseInr).combined}</span>
                      </div>
                      <div className="flex justify-between text-green-700">
                        <span>Promo Discount (10%):</span>
                        <span>-{convertInr(bookingPrices.discountInr).combined}</span>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between items-baseline font-black">
                        <span>Total Payable ({currency}):</span>
                        <span className="text-2xl text-brand">{convertInr(bookingPrices.totalInr).primaryFormatted}</span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-brand text-white py-3.5 rounded-xl font-black text-sm shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      <ShieldCheck size={16} />
                      <span>CONFIRM BUS BOOKING ({convertInr(bookingPrices.totalInr).primaryFormatted} / {convertInr(bookingPrices.totalInr).secondaryFormatted})</span>
                    </button>
                  </form>
                ) : (
                  <div className="text-center py-4 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle2 size={32} />
                    </div>
                    <h4 className="text-xl font-black text-gray-900">Bus Seats Confirmed!</h4>
                    <p className="text-xs text-text-secondary">Booking Reference: <strong className="text-brand">{bookingConfirmed.bookingId}</strong></p>
                    <div className="bg-gray-50 rounded-2xl p-4 text-left text-xs space-y-1.5">
                      <div className="flex justify-between"><span>Passenger:</span><span className="font-bold">{bookingConfirmed.passengerName}</span></div>
                      <div className="flex justify-between"><span>Seats:</span><span className="font-bold">{bookingConfirmed.seatNumbers}</span></div>
                      <div className="flex justify-between border-t border-gray-200 pt-2 font-black">
                        <span>Total Paid:</span>
                        <span className="text-brand">{convertInr(bookingConfirmed.pricing.totalInr).combined}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedBus(null)}
                      className="bg-brand text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow cursor-pointer"
                    >
                      Done
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
