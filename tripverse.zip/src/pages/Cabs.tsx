import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Car, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Clock, 
  Calendar, 
  Fuel, 
  Gauge, 
  Check, 
  X, 
  ArrowRight, 
  Search, 
  Sparkles, 
  CheckCircle2, 
  Printer, 
  Users,
  Briefcase,
  SlidersHorizontal,
  RotateCcw,
  Zap,
  Info,
  DollarSign
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';

interface CarRental {
  id: string;
  name: string;
  category: 'Sedan' | 'SUV' | 'Luxury' | 'Electric' | '4x4 Off-Road';
  seats: number;
  luggage: number;
  transmission: 'Automatic' | 'Manual';
  fuelType: 'Petrol' | 'Diesel' | 'Electric';
  engine: string;
  mileage: string;
  pricePerDayInr: number;
  rating: number;
  tripsCount: number;
  image: string;
  badge?: string;
  availableCities: string[];
  features: string[];
  description: string;
}

const carsData: CarRental[] = [
  {
    id: 'c1',
    name: 'Toyota Innova Crysta (7-Seater)',
    category: 'SUV',
    seats: 7,
    luggage: 4,
    transmission: 'Automatic',
    fuelType: 'Diesel',
    engine: '2.4L GD Turbo Diesel',
    mileage: '14.5 kmpl',
    pricePerDayInr: 3200,
    rating: 4.9,
    tripsCount: 840,
    badge: 'Family Favorite',
    availableCities: ['Delhi', 'Mumbai', 'Bengaluru', 'Goa', 'Jaipur', 'Rishikesh'],
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1000&q=80',
    features: ['Captain Seats (Middle Row)', 'Dual Climate Control AC', 'GPS Navigation & Apple CarPlay', 'Zero Security Deposit'],
    description: 'The undisputed gold standard for family vacations and highway tours. Superb comfort, plush captain seats, and mammoth luggage capacity.'
  },
  {
    id: 'c2',
    name: 'Mercedes-Benz E-Class Executive',
    category: 'Luxury',
    seats: 5,
    luggage: 3,
    transmission: 'Automatic',
    fuelType: 'Petrol',
    engine: '2.0L Turbocharged (197 hp)',
    mileage: '13 kmpl',
    pricePerDayInr: 8500,
    rating: 5.0,
    tripsCount: 420,
    badge: 'VIP Elite',
    availableCities: ['Delhi', 'Mumbai', 'Bengaluru', 'Goa'],
    image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1000&q=80',
    features: ['Burmester 3D Surround Audio', 'Panoramic Sunroof', 'Ambient 64-Color Lighting', 'Chauffeur on Request'],
    description: 'First-class luxury travel with whisper-quiet cabin insulation, leather recliner comfort, and prestigious road presence for weddings and executive tours.'
  },
  {
    id: 'c3',
    name: 'Tata Nexon EV Max (Smart Electric)',
    category: 'Electric',
    seats: 5,
    luggage: 3,
    transmission: 'Automatic',
    fuelType: 'Electric',
    engine: '40.5 kWh High Energy Battery',
    mileage: '453 km Range',
    pricePerDayInr: 2400,
    rating: 4.8,
    tripsCount: 310,
    badge: 'Eco Smart',
    availableCities: ['Bengaluru', 'Delhi', 'Goa', 'Mumbai'],
    image: 'https://images.unsplash.com/photo-1570733117311-d990c3816c47?auto=format&fit=crop&w=1000&q=80',
    features: ['Fast Charging Compatible', 'Wireless Smartphone Charger', 'Electronic Parking Brake', 'Zero Carbon Emissions'],
    description: 'Instant electric acceleration, cutting-edge infotainment, and 450+ km driving range. Zero fuel bills with complimentary hub charging.'
  },
  {
    id: 'c4',
    name: 'Mahindra Thar 4x4 Convertible',
    category: '4x4 Off-Road',
    seats: 4,
    luggage: 2,
    transmission: 'Manual',
    fuelType: 'Diesel',
    engine: '2.2L mHawk Turbo (130 PS)',
    mileage: '12 kmpl',
    pricePerDayInr: 3800,
    rating: 4.9,
    tripsCount: 650,
    badge: 'Adventure King',
    availableCities: ['Goa', 'Rishikesh', 'Jaipur', 'Manali', 'Leh Ladakh'],
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80',
    features: ['Mechanical Shift-on-Fly 4WD', 'Roll Cage & Hill Descent Assist', 'Waterproof Interior & Touchscreen', 'Removable Roof Panels'],
    description: 'Iconic open-top off-roading built for beaches in Goa, desert dunes in Rajasthan, and Himalayan river crossings in Rishikesh and Manali.'
  },
  {
    id: 'c5',
    name: 'Hyundai Creta SX (Sunroof Edition)',
    category: 'SUV',
    seats: 5,
    luggage: 3,
    transmission: 'Automatic',
    fuelType: 'Petrol',
    engine: '1.5L Smartstream MPi',
    mileage: '17 kmpl',
    pricePerDayInr: 2600,
    rating: 4.8,
    tripsCount: 780,
    badge: 'Best Seller',
    availableCities: ['Delhi', 'Mumbai', 'Bengaluru', 'Goa', 'Jaipur'],
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1000&q=80',
    features: ['Voice Controlled Panoramic Sunroof', 'Bose Premium 8-Speaker Audio', 'Ventilated Front Seats', 'Cruise Control'],
    description: 'The preferred choice for modern road trips. Smooth automatic drive, commanding high-seating posture, and panoramic views from the glass roof.'
  },
  {
    id: 'c6',
    name: 'Maruti Suzuki Dzire VXi Sedan',
    category: 'Sedan',
    seats: 5,
    luggage: 2,
    transmission: 'Manual',
    fuelType: 'Petrol',
    engine: '1.2L DualJet Dual VVT',
    mileage: '23 kmpl',
    pricePerDayInr: 1600,
    rating: 4.7,
    tripsCount: 920,
    badge: 'Value Champion',
    availableCities: ['Delhi', 'Mumbai', 'Bengaluru', 'Goa', 'Jaipur', 'Rishikesh'],
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1000&q=80',
    features: ['High Fuel Economy (23+ kmpl)', 'Rear AC Vents & Armrest', 'Compact & Easy City Parking', 'Android Auto & Apple CarPlay'],
    description: 'Ultra economical, nimble city sedan with great air conditioning and ample boot space for weekend getaways and airport transfers.'
  },
  {
    id: 'c7',
    name: 'Land Rover Defender 110 (Expedition 4x4)',
    category: '4x4 Off-Road',
    seats: 7,
    luggage: 5,
    transmission: 'Automatic',
    fuelType: 'Diesel',
    engine: '3.0L Ingenium 6-Cylinder Turbo',
    mileage: '11.5 kmpl',
    pricePerDayInr: 11500,
    rating: 5.0,
    tripsCount: 190,
    badge: 'Ultimate Expedition',
    availableCities: ['Delhi', 'Mumbai', 'Goa', 'Manali', 'Leh Ladakh'],
    image: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=1000&q=80',
    features: ['Air Suspension with 291mm Clearance', 'Meridian Surround Audio', 'Wade Sensing 900mm Water Depth', 'Terrain Response 2 System'],
    description: 'The world-renowned expedition vehicle. Indestructible monocoque architecture, air-cushioned terrain ride, and pinnacle British prestige.'
  },
  {
    id: 'c8',
    name: 'BMW 3 Series Gran Limousine',
    category: 'Luxury',
    seats: 5,
    luggage: 3,
    transmission: 'Automatic',
    fuelType: 'Petrol',
    engine: '2.0L BMW TwinPower Turbo (258 hp)',
    mileage: '15 kmpl',
    pricePerDayInr: 7800,
    rating: 4.9,
    tripsCount: 280,
    badge: 'German Luxury',
    availableCities: ['Delhi', 'Mumbai', 'Bengaluru', 'Goa'],
    image: 'https://images.unsplash.com/photo-1555353540-64580b51c258?auto=format&fit=crop&w=1000&q=80',
    features: ['Curved Dual Display Dash', 'Panoramic Glass Roof', 'Vernasca Leather Seats', 'Wireless Apple CarPlay & Harman Kardon'],
    description: 'Extended wheelbase limousine offering lounge-grade legroom in the rear and unmatched driving dynamics behind the wheel.'
  },
  {
    id: 'c9',
    name: 'Mahindra Scorpio-N Z8L 4x4',
    category: 'SUV',
    seats: 7,
    luggage: 4,
    transmission: 'Automatic',
    fuelType: 'Diesel',
    engine: '2.2L mHawk Turbo Diesel (175 PS)',
    mileage: '14 kmpl',
    pricePerDayInr: 3400,
    rating: 4.8,
    tripsCount: 520,
    badge: 'Big Daddy of SUVs',
    availableCities: ['Delhi', 'Jaipur', 'Rishikesh', 'Manali', 'Goa'],
    image: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1000&q=80',
    features: ['4XPLOR Intelligent Terrain Modes', 'Sony 12-Speaker 3D Audio', 'Dual Zone Climate AC', 'High Ground Clearance'],
    description: 'Commanding road presence, ladder-frame toughness, and true 4x4 capability to conquer rough mountain highways and wilderness routes.'
  }
];

export default function Cabs() {
  const { user } = useAuth();
  const { currency, convertInr } = useCurrency();

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Sedan' | 'SUV' | 'Luxury' | 'Electric' | '4x4 Off-Road'>('All');
  const [selectedTransmission, setSelectedTransmission] = useState<'All' | 'Automatic' | 'Manual'>('All');
  const [selectedFuel, setSelectedFuel] = useState<'All' | 'Petrol' | 'Diesel' | 'Electric'>('All');
  const [seatingFilter, setSeatingFilter] = useState<'All' | '4-5' | '7+'>('All');
  const [budgetFilter, setBudgetFilter] = useState<'All' | 'under2000' | 'under3500' | 'luxury'>('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'priceDesc' | 'ratingDesc'>('recommended');

  // Booking Modal State
  const [selectedCar, setSelectedCar] = useState<CarRental | null>(null);
  const [rentalDays, setRentalDays] = useState(2);
  const [passengersCount, setPassengersCount] = useState(2);
  const [pickupCity, setPickupCity] = useState('Delhi');
  const [pickupLocation, setPickupLocation] = useState('IGI Airport Terminal 3');
  const [dropLocation, setDropLocation] = useState('Connaught Place Hotel');
  const [tripType, setTripType] = useState<'Self-Drive' | 'Chauffeur Driven' | 'Airport Transfer'>('Self-Drive');
  const [pickupDate, setPickupDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [driverName, setDriverName] = useState(user?.displayName || '');
  const [driverPhone, setDriverPhone] = useState(user?.phoneNumber || '');
  const [licenseNumber, setLicenseNumber] = useState('DL-082020005432');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);

  // Price calculations
  const bookingPrices = useMemo(() => {
    if (!selectedCar) return { baseInr: 0, chauffeurInr: 0, passengerInsuranceInr: 0, discountInr: 0, taxInr: 0, totalInr: 0 };
    const baseInr = selectedCar.pricePerDayInr * rentalDays;
    const chauffeurInr = tripType === 'Chauffeur Driven' ? 600 * rentalDays : 0;
    const passengerInsuranceInr = passengersCount * 250;
    const subtotal = baseInr + chauffeurInr + passengerInsuranceInr;
    const discountInr = Math.round(subtotal * 0.10); // 10% promo discount
    const taxInr = Math.round((subtotal - discountInr) * 0.05); // 5% GST
    const totalInr = (subtotal - discountInr) + taxInr;
    return { baseInr, chauffeurInr, passengerInsuranceInr, discountInr, taxInr, totalInr };
  }, [selectedCar, rentalDays, tripType, passengersCount]);

  // Filtered & Sorted List
  const filteredCars = useMemo(() => {
    return carsData
      .filter((car) => {
        const matchCity = selectedCity === 'All' || car.availableCities.includes(selectedCity);
        const matchCategory = selectedCategory === 'All' || car.category === selectedCategory;
        const matchTransmission = selectedTransmission === 'All' || car.transmission === selectedTransmission;
        const matchFuel = selectedFuel === 'All' || car.fuelType === selectedFuel;
        
        let matchSeating = true;
        if (seatingFilter === '4-5') matchSeating = car.seats <= 5;
        else if (seatingFilter === '7+') matchSeating = car.seats >= 7;

        let matchBudget = true;
        if (budgetFilter === 'under2000') matchBudget = car.pricePerDayInr <= 2000;
        else if (budgetFilter === 'under3500') matchBudget = car.pricePerDayInr <= 3500;
        else if (budgetFilter === 'luxury') matchBudget = car.pricePerDayInr >= 5000;

        const matchSearch = !searchQuery || 
          car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          car.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          car.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          car.features.some(f => f.toLowerCase().includes(searchQuery.toLowerCase()));
        
        return matchCity && matchCategory && matchTransmission && matchFuel && matchSeating && matchBudget && matchSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'priceAsc') return a.pricePerDayInr - b.pricePerDayInr;
        if (sortBy === 'priceDesc') return b.pricePerDayInr - a.pricePerDayInr;
        if (sortBy === 'ratingDesc') return b.rating - a.rating;
        return 0;
      });
  }, [selectedCity, selectedCategory, selectedTransmission, selectedFuel, seatingFilter, budgetFilter, searchQuery, sortBy]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (selectedCity !== 'All') count++;
    if (selectedCategory !== 'All') count++;
    if (selectedTransmission !== 'All') count++;
    if (selectedFuel !== 'All') count++;
    if (seatingFilter !== 'All') count++;
    if (budgetFilter !== 'All') count++;
    if (sortBy !== 'recommended') count++;
    return count;
  }, [searchQuery, selectedCity, selectedCategory, selectedTransmission, selectedFuel, seatingFilter, budgetFilter, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCity('All');
    setSelectedCategory('All');
    setSelectedTransmission('All');
    setSelectedFuel('All');
    setSeatingFilter('All');
    setBudgetFilter('All');
    setSortBy('recommended');
  };

  const handleConfirmCarBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCar) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const bookingId = 'TV-CAR-' + Math.floor(100000 + Math.random() * 900000);
      setBookingConfirmed({
        bookingId,
        carName: selectedCar.name,
        category: selectedCar.category,
        image: selectedCar.image,
        tripType,
        rentalDays,
        pickupCity,
        pickupLocation,
        dropLocation,
        pickupDate,
        driverName: driverName.trim() || 'Guest Traveler',
        driverPhone: driverPhone.trim() || '+91 98765 43210',
        licenseNumber,
        pricing: bookingPrices,
        bookedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      });
      setIsSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-24 relative overflow-hidden">
      {/* ================= MULTI-COLOR TOURISM AMBIENT BACKGROUND EFFECTS ================= */}
      <div className="absolute top-0 left-0 w-full h-[520px] bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      {/* Radiant Cyan Orb */}
      <div className="absolute top-16 -left-20 w-[420px] h-[420px] bg-cyan-400/20 rounded-full blur-[100px] pointer-events-none" />
      {/* Warm Sunset Amber Orb */}
      <div className="absolute top-28 right-10 w-[400px] h-[400px] bg-amber-500/20 rounded-full blur-[120px] pointer-events-none" />
      {/* Emerald Oasis Orb */}
      <div className="absolute top-80 left-1/3 w-[380px] h-[380px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      {/* Royal Violet Aura */}
      <div className="absolute top-36 left-1/2 -translate-x-1/2 w-[350px] h-[350px] bg-purple-500/15 rounded-full blur-[120px] pointer-events-none" />
      {/* Radial Stars Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Top Hero Banner with rich tourism colors */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        {/* Internal glowing light orbs */}
        <div className="absolute -top-12 -right-12 w-80 h-80 bg-cyan-400/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-10 left-1/4 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-10 left-10 w-64 h-64 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 w-60 h-60 bg-purple-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[size:28px_28px] opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Car size={15} /> Premium Car Rentals & Cab Services
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Book Self-Drive Cars & Luxury Cabs
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            From 4x4 adventure beasts like <strong>Mahindra Thar</strong> and <strong>Defender 110</strong> to executive <strong>Mercedes-Benz</strong> and 7-seater <strong>Innova Crysta</strong>. Fully insured with zero security deposit.
          </p>
        </div>
      </div>

      {/* ================= COMPREHENSIVE FILTER OPTIONS BAR ================= */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-5 border border-[#E0E4E9] space-y-4">
          {/* Main Selectors Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
            {/* Search Model */}
            <div className="relative">
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Search Model / Brand / Feature
              </label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
                <Search size={16} className="text-gray-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Innova, Thar, Mercedes, Defender..."
                  className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
                />
              </div>
            </div>

            {/* City Selector */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Pickup City / Destination
              </label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">🌍 All Available Cities</option>
                <option value="Delhi">🏛️ New Delhi & NCR</option>
                <option value="Mumbai">🏙️ Mumbai, Maharashtra</option>
                <option value="Bengaluru">🌳 Bengaluru, Karnataka</option>
                <option value="Goa">🏖️ Goa (North & South)</option>
                <option value="Jaipur">🏰 Jaipur, Rajasthan</option>
                <option value="Rishikesh">⛰️ Rishikesh & Dehradun</option>
                <option value="Manali">🏔️ Manali, Himachal</option>
                <option value="Leh Ladakh">🏔️ Leh Ladakh</option>
              </select>
            </div>

            {/* Category Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Vehicle Segment
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">All Vehicle Segments</option>
                <option value="SUV">🚙 SUVs & MPVs (Innova / Creta / Scorpio)</option>
                <option value="Sedan">🚗 Sedans (Dzire / City)</option>
                <option value="Luxury">👑 Luxury VIP (Mercedes-Benz / BMW)</option>
                <option value="Electric">⚡ Electric EVs (Tata Nexon EV)</option>
                <option value="4x4 Off-Road">🏔️ 4x4 Off-Road (Thar / Defender)</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Sort Pricing & Rating
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="recommended">Recommended Picks</option>
                <option value="priceAsc">Rate: Low to High</option>
                <option value="priceDesc">Rate: High to Low</option>
                <option value="ratingDesc">Highest Customer Rating</option>
              </select>
            </div>
          </div>

          {/* Secondary Filter Row: Transmission, Fuel, Seating, Budget */}
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {/* Transmission Filter */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSelectedTransmission('All')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedTransmission === 'All' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  All Gears
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTransmission('Automatic')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedTransmission === 'Automatic' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Automatic
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTransmission('Manual')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedTransmission === 'Manual' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Manual
                </button>
              </div>

              {/* Fuel Filter */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSelectedFuel('All')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedFuel === 'All' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  All Fuels
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedFuel('Diesel')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedFuel === 'Diesel' ? "bg-amber-600 text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Diesel
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedFuel('Petrol')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedFuel === 'Petrol' ? "bg-blue-600 text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Petrol
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedFuel('Electric')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-0.5",
                    selectedFuel === 'Electric' ? "bg-emerald-600 text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  <Zap size={11} /> EV
                </button>
              </div>

              {/* Seating Capacity */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSeatingFilter('All')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    seatingFilter === 'All' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Any Seats
                </button>
                <button
                  type="button"
                  onClick={() => setSeatingFilter('4-5')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    seatingFilter === '4-5' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  4-5 Seats
                </button>
                <button
                  type="button"
                  onClick={() => setSeatingFilter('7+')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    seatingFilter === '7+' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  7+ Family Seats
                </button>
              </div>

              {/* Budget Chips */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setBudgetFilter('All')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    budgetFilter === 'All' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  All Budgets
                </button>
                <button
                  type="button"
                  onClick={() => setBudgetFilter('under2000')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    budgetFilter === 'under2000' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  &lt; ₹2k ($24)
                </button>
                <button
                  type="button"
                  onClick={() => setBudgetFilter('under3500')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    budgetFilter === 'under3500' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  &lt; ₹3.5k ($42)
                </button>
                <button
                  type="button"
                  onClick={() => setBudgetFilter('luxury')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    budgetFilter === 'luxury' ? "bg-purple-600 text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  Luxury &gt; ₹5k ($60)
                </button>
              </div>
            </div>

            {/* Clear All Filters */}
            {activeFiltersCount > 0 && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw size={13} />
                Reset Filters ({activeFiltersCount})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Car Cards Grid */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-black text-brand bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200 uppercase tracking-widest inline-flex items-center gap-1.5 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></span>
                Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
              </span>
            </div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Available Cars & Cabs ({filteredCars.length})
            </h2>
            <p className="text-xs md:text-sm text-text-secondary font-medium">
              Choose self-drive or chauffeur driven. Includes unlimited kilometers, roadside assistance, and instant delivery.
            </p>
          </div>
        </div>

        {filteredCars.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-[#E0E4E9] shadow-sm max-w-lg mx-auto">
            <Car size={48} className="text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-black text-gray-800">No vehicles match your filters</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Try clearing some filters or searching for another car model.</p>
            <button
              onClick={handleResetFilters}
              className="bg-brand text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm hover:bg-brand-dark transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCars.map((car, i) => {
              const carPrice = convertInr(car.pricePerDayInr);
              return (
                <motion.div
                  key={car.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group border border-[#E0E4E9] flex flex-col justify-between"
                >
                  {/* Image Section with Rich Car Photos */}
                  <div className="h-60 relative overflow-hidden bg-gray-100">
                    <img
                      src={car.image}
                      alt={car.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                    {/* Top Badges */}
                    <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                      <span className="bg-brand text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
                        <Sparkles size={11} /> {car.badge || car.category}
                      </span>
                      <span className="bg-black/60 backdrop-blur-md text-white text-[11px] font-bold px-2.5 py-0.5 rounded-md border border-white/20">
                        {car.fuelType} • {car.transmission}
                      </span>
                    </div>

                    {/* Title & Rating */}
                    <div className="absolute bottom-3 left-4 right-4 text-white">
                      <div className="flex items-center gap-1 text-yellow-400 text-xs font-black mb-0.5">
                        <Star size={12} fill="currentColor" />
                        <span>{car.rating}</span>
                        <span className="text-white/80 font-medium text-[10px]">({car.tripsCount} trips)</span>
                      </div>
                      <h3 className="text-lg font-black leading-tight drop-shadow-sm">{car.name}</h3>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Specs Pill Grid */}
                      <div className="grid grid-cols-2 gap-2 text-xs font-bold text-gray-700 mb-4 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                        <div className="flex items-center gap-1.5">
                          <Users size={13} className="text-brand shrink-0" />
                          <span>{car.seats} Seats Capacity</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Briefcase size={13} className="text-brand shrink-0" />
                          <span>{car.luggage} Bags Boot</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Gauge size={13} className="text-brand shrink-0" />
                          <span className="truncate">{car.engine}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Fuel size={13} className="text-brand shrink-0" />
                          <span>{car.mileage}</span>
                        </div>
                      </div>

                      <p className="text-xs text-text-secondary line-clamp-2 mb-4 font-medium">
                        {car.description}
                      </p>

                      {/* Top Features */}
                      <div className="space-y-1.5 mb-5">
                        {car.features.slice(0, 3).map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-xs text-gray-600 font-medium">
                            <Check size={12} className="text-emerald-500 shrink-0" />
                            <span>{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Price & CTA */}
                    <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-bold text-text-secondary uppercase block">Per Day Rate</span>
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-black text-brand">
                            {carPrice.primaryFormatted}
                          </span>
                          <span className="text-xs text-text-secondary font-bold">/day</span>
                        </div>
                        <span className="text-[11px] font-bold text-gray-400 block -mt-1">
                          ({carPrice.secondaryFormatted})
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedCar(car);
                          setBookingConfirmed(null);
                        }}
                        className="bg-brand text-white px-5 py-2.5 rounded-xl font-black text-xs hover:bg-brand-dark transition-all flex items-center gap-1.5 shadow-md shadow-brand/20 cursor-pointer"
                      >
                        <span>BOOK CAR</span>
                        <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Car Booking Modal */}
      <AnimatePresence>
        {selectedCar && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              <button
                onClick={() => setSelectedCar(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="relative h-44 bg-gradient-to-r from-[#041422] to-[#008CFF] overflow-hidden">
                <img
                  src={selectedCar.image}
                  alt={selectedCar.name}
                  className="w-full h-full object-cover opacity-60 mix-blend-overlay"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-6 flex flex-col justify-end text-white">
                  <span className="text-[10px] font-black uppercase tracking-widest bg-brand px-2.5 py-0.5 rounded-md inline-block mb-1 w-max">
                    {selectedCar.category} • {selectedCar.transmission}
                  </span>
                  <h3 className="text-2xl font-black">{selectedCar.name}</h3>
                  <p className="text-white/80 text-xs font-semibold mt-0.5">
                    {selectedCar.seats} Seater • {selectedCar.fuelType} • {selectedCar.engine}
                  </p>
                </div>
              </div>

              <div className="p-6 overflow-y-auto flex-1">
                {!bookingConfirmed ? (
                  <form onSubmit={handleConfirmCarBooking} className="space-y-4 text-xs">
                    {/* Trip Type Selector */}
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-1">
                        Rental Mode
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['Self-Drive', 'Chauffeur Driven', 'Airport Transfer'] as const).map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => setTripType(type)}
                            className={cn(
                              "py-2.5 px-3 rounded-xl border text-center font-black transition-all cursor-pointer",
                              tripType === type
                                ? "bg-brand text-white border-brand shadow-xs"
                                : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                            )}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Rental Duration</label>
                        <select
                          value={rentalDays}
                          onChange={(e) => setRentalDays(Number(e.target.value))}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        >
                          {[1, 2, 3, 4, 5, 7, 10, 14].map(d => (
                            <option key={d} value={d}>{d} Day{d > 1 ? 's' : ''} {d >= 7 ? '(Weekly Deal)' : ''}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] font-black uppercase text-gray-500">Travelers / Persons</label>
                          <span className="text-[10px] font-bold text-brand">±₹250/person</span>
                        </div>
                        <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5">
                          <button
                            type="button"
                            onClick={() => setPassengersCount(Math.max(1, passengersCount - 1))}
                            className="w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-800 font-black text-sm hover:bg-gray-100 flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Decrease person (reduces total money)"
                          >
                            -
                          </button>
                          <div className="text-center px-1">
                            <span className="text-xs font-black text-gray-900 block">{passengersCount} Person{passengersCount > 1 ? 's' : ''}</span>
                            <span className="text-[9px] text-gray-500 font-semibold">Max {selectedCar.seats} seats</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setPassengersCount(Math.min(selectedCar.seats, passengersCount + 1))}
                            className="w-8 h-8 rounded-lg bg-brand text-white font-black text-sm hover:bg-brand-dark flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Increase person (increases total money)"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Pickup Date</label>
                        <input
                          type="date"
                          value={pickupDate}
                          onChange={(e) => setPickupDate(e.target.value)}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Primary Driver Name</label>
                        <input
                          type="text"
                          required
                          value={driverName}
                          onChange={(e) => setDriverName(e.target.value)}
                          placeholder="Full Name as per DL"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Pickup Location / Hub</label>
                        <input
                          type="text"
                          required
                          value={pickupLocation}
                          onChange={(e) => setPickupLocation(e.target.value)}
                          placeholder="e.g. Airport Terminal 3 / Hotel"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Drop-off Location</label>
                        <input
                          type="text"
                          required
                          value={dropLocation}
                          onChange={(e) => setDropLocation(e.target.value)}
                          placeholder="e.g. City Center Hub"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Mobile / WhatsApp Number</label>
                        <input
                          type="text"
                          required
                          value={driverPhone}
                          onChange={(e) => setDriverPhone(e.target.value)}
                          placeholder="+91 98765 43210"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Driving License Number</label>
                        <input
                          type="text"
                          required
                          value={licenseNumber}
                          onChange={(e) => setLicenseNumber(e.target.value)}
                          placeholder="DL-082020005432"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                    </div>

                    {/* Price Breakdown in Rupees and Dollars */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2 font-medium">
                      <div className="flex justify-between text-gray-600">
                        <span>Base Rental ({rentalDays} days × {convertInr(selectedCar.pricePerDayInr).primaryFormatted})</span>
                        <span className="font-bold text-gray-900">{convertInr(bookingPrices.baseInr).primaryFormatted}</span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>Traveler Protection Shield ({passengersCount} Person{passengersCount > 1 ? 's' : ''} × ₹250)</span>
                        <span className="font-bold text-gray-900">{convertInr(bookingPrices.passengerInsuranceInr).primaryFormatted}</span>
                      </div>
                      {tripType === 'Chauffeur Driven' && (
                        <div className="flex justify-between text-gray-600">
                          <span>Professional Chauffeur Allowance</span>
                          <span className="font-bold text-gray-900">{convertInr(bookingPrices.chauffeurInr).primaryFormatted}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-emerald-600 font-bold">
                        <span>Online Promo Discount (10% OFF)</span>
                        <span>- {convertInr(bookingPrices.discountInr).primaryFormatted}</span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>Roadside Insurance & GST (5%)</span>
                        <span className="font-bold text-gray-900">{convertInr(bookingPrices.taxInr).primaryFormatted}</span>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between text-sm font-black text-gray-900">
                        <span>Total Payable Amount</span>
                        <div className="text-right">
                          <span className="text-brand text-base block">
                            {convertInr(bookingPrices.totalInr).primaryFormatted}
                          </span>
                          <span className="text-[11px] text-gray-500 font-bold block">
                            ({convertInr(bookingPrices.totalInr).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-brand hover:bg-brand-dark text-white font-black py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                    >
                      <ShieldCheck size={18} />
                      <span>CONFIRM CAR RENTAL ({convertInr(bookingPrices.totalInr).primaryFormatted})</span>
                    </button>
                  </form>
                ) : (
                  /* Confirmed Car Rental Voucher */
                  <div className="text-center py-4 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle2 size={32} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-gray-900">Car Reservation Confirmed!</h4>
                      <p className="text-gray-500 text-xs mt-1">
                        Vehicle dispatch and doorstep key handover confirmed for <strong>{bookingConfirmed.driverName}</strong>
                      </p>
                    </div>

                    {/* Voucher Card */}
                    <div className="bg-white border-2 border-dashed border-gray-300 rounded-2xl p-5 text-left space-y-3 shadow-inner">
                      <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                        <div>
                          <span className="text-[10px] font-black uppercase tracking-wider text-brand">TRIPVERSE CAR RENTAL VOUCHER</span>
                          <h5 className="font-black text-gray-800">{bookingConfirmed.carName}</h5>
                        </div>
                        <span className="bg-blue-50 text-brand px-2 py-1 rounded text-xs font-black">
                          {bookingConfirmed.bookingId}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Driver Name</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.driverName}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Trip Mode</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.tripType}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Pickup Hub</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.pickupLocation}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Duration</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.rentalDays} Days ({bookingConfirmed.pickupDate})</span>
                        </div>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between items-center text-xs">
                        <span className="font-bold text-gray-500">Total Amount Paid</span>
                        <div className="text-right">
                          <span className="font-black text-brand text-sm block">
                            {convertInr(bookingConfirmed.pricing.totalInr).primaryFormatted}
                          </span>
                          <span className="text-[10px] font-bold text-gray-500">
                            ({convertInr(bookingConfirmed.pricing.totalInr).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedCar(null)}
                      className="w-full bg-gray-900 text-white font-black py-3 rounded-xl hover:bg-black transition-all cursor-pointer text-xs"
                    >
                      Close & Return to Cars
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
