import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Clock, Star, Bed, Plane, Camera, Calendar, Check, X, ShieldCheck, ArrowRight, Sparkles, Users } from 'lucide-react';
import { cn, formatDualPrice } from '../lib/utils';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';

interface Package {
  id: number;
  title: string;
  dest: string;
  duration: string;
  priceUsd: number;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  description: string;
  highlights: string[];
  includes: any[];
}

const packages: Package[] = [
  {
    id: 1,
    title: "Maldives Paradise Escape",
    dest: "Male & Dhaalu Atoll, Maldives",
    duration: "5 Nights / 6 Days",
    priceUsd: 1240,
    rating: 4.9,
    reviews: 184,
    badge: "Bestseller",
    image: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=1200&q=80",
    description: "Indulge in pure luxury over turquoise lagoons with private overwater bungalows, speedboat transfers, coral reef snorkeling, and romantic sunset beach dinners.",
    highlights: ["Overwater Villa with Ocean Deck", "Speedboat Airport Transfers", "All-Inclusive Tropical Breakfast & Dinner", "Guided Snorkeling & Dolphin Cruise"],
    includes: [Plane, Bed, Camera]
  },
  {
    id: 2,
    title: "Cultural Rajasthan Tour",
    dest: "Jaipur, Jodhpur & Udaipur, Rajasthan, India",
    duration: "4 Nights / 5 Days",
    priceUsd: 450,
    rating: 4.9,
    reviews: 295,
    badge: "Heritage Special",
    image: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80",
    description: "Experience the royal heritage of the Maharajas across the Pink City of Jaipur, Mehrangarh Fort in Jodhpur, and Lake Pichola in Udaipur with private palace stays.",
    highlights: ["Amber Fort Elephant/Jeep Safari", "Palace Heritage Hotel Stays", "Private Sunset Boat Ride on Lake Pichola", "Chokhi Dhani Royal Cultural Evening"],
    includes: [Bed, Camera]
  },
  {
    id: 3,
    title: "Romantic Paris & French Alps",
    dest: "Paris & Chamonix, France",
    duration: "7 Nights / 8 Days",
    priceUsd: 2850,
    rating: 5.0,
    reviews: 142,
    badge: "Couples Choice",
    image: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=1200&q=80",
    description: "Stroll the Champs-Élysées, cruise the River Seine at twilight, and take the alpine cable car high into the snow-capped Mont Blanc peaks in the French Alps.",
    highlights: ["Eiffel Tower Priority Summit Access", "Seine River Dinner Cruise", "Mont Blanc Alpine Cable Car Pass", "Boutique 4-Star Central Hotel"],
    includes: [Plane, Bed, Camera]
  },
  {
    id: 4,
    title: "Swiss Luxury Explorer",
    dest: "Zurich, Lucerne & Interlaken, Switzerland",
    duration: "6 Nights / 7 Days",
    priceUsd: 3400,
    rating: 4.8,
    reviews: 98,
    badge: "Premium Experience",
    image: "https://images.unsplash.com/photo-1531219572328-a0171b4448a3?auto=format&fit=crop&w=1200&q=80",
    description: "Ride the iconic Glacier Express, marvel at the peaks of Jungfraujoch - Top of Europe, and unwind on scenic Lake Geneva with luxury 5-star alpine accommodations.",
    highlights: ["1st Class Swiss Travel Pass", "Jungfraujoch Mountain Excursion", "Lake Lucerne Private Steamboat Cruise", "Alpine Spa Resort Stays"],
    includes: [Plane, Bed, Camera]
  }
];

const Holidays = () => {
  const { user } = useAuth();
  const { currency, convertUsd } = useCurrency();
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [travelersCount, setTravelersCount] = useState(2);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const filteredPackages = packages.filter(pkg => {
    if (activeFilter === 'Domestic') return pkg.dest.includes('India');
    if (activeFilter === 'International') return !pkg.dest.includes('India');
    if (activeFilter === 'Honeymoon') return pkg.title.includes('Maldives') || pkg.title.includes('Paris');
    return true;
  });

  return (
    <div className="bg-[#F2F5F8] min-h-screen pb-20 relative overflow-hidden">
      {/* Top Hero Banner with rich tourism ambient effects */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] py-14 px-6 md:px-10 text-white relative overflow-hidden">
        {/* Multi-Color Ambient Orbs */}
        <div className="absolute -top-24 -right-20 w-[420px] h-[420px] bg-cyan-400/25 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-1/3 -left-20 w-[380px] h-[380px] bg-amber-500/20 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute -bottom-16 right-1/4 w-[360px] h-[360px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Sparkles size={14} /> Curated Holiday Experiences
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Curated Holiday Packages
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            Explore handcrafted domestic & international tours with transparent prices shown in both Rupees (₹) and US Dollars ($).
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        {/* Filters Mini Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-4 flex flex-wrap gap-3 items-center justify-between border border-[#E0E4E9]">
          <div className="flex flex-wrap gap-2">
            {['All', 'Domestic', 'International', 'Honeymoon'].map((label) => (
              <button
                key={label}
                onClick={() => setActiveFilter(label)}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer",
                  activeFilter === label 
                    ? "bg-brand text-white shadow-md shadow-brand/20" 
                    : "bg-gray-100 text-text-secondary hover:bg-gray-200"
                )}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 bg-blue-50 text-brand px-3.5 py-2 rounded-xl text-xs font-bold border border-blue-100">
            <Calendar size={16} />
            <span>Dual Currency: 1 USD ≈ ₹84 INR</span>
          </div>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10">
          {filteredPackages.map((pkg, i) => {
            const pkgPrice = convertUsd(pkg.priceUsd);
            return (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group border border-[#E0E4E9] flex flex-col justify-between"
              >
                {/* Image Section */}
                <div className="h-72 relative overflow-hidden">
                  <img 
                    src={pkg.image} 
                    alt={pkg.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  
                  {/* Badges */}
                  <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                    <span className="bg-brand text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg flex items-center gap-1">
                      <Sparkles size={11} /> {pkg.badge || "Featured"}
                    </span>
                    <div className="flex gap-1.5">
                      {pkg.includes.map((Icon, idx) => (
                        <div key={idx} className="bg-black/50 backdrop-blur-md p-1.5 rounded-lg text-white border border-white/20">
                          <Icon size={14} />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Title & Dest Overlay */}
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <div className="flex items-center gap-2 text-yellow-400 mb-1">
                      <div className="flex items-center gap-0.5">
                        {[...Array(5)].map((_, s) => (
                          <Star key={s} size={13} fill="currentColor" />
                        ))}
                      </div>
                      <span className="text-xs font-black text-white">{pkg.rating}</span>
                      <span className="text-white/80 text-[11px] font-semibold">({pkg.reviews} verified reviews)</span>
                    </div>

                    <h3 className="text-2xl font-black leading-tight text-white">{pkg.title}</h3>
                    <p className="flex items-center gap-1 text-white/80 text-xs font-medium mt-1">
                      <MapPin size={13} className="text-brand shrink-0" />
                      <span>{pkg.dest}</span>
                    </p>
                  </div>
                </div>
                
                {/* Body Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-text-secondary font-bold mb-3">
                      <span className="flex items-center gap-1.5 bg-gray-50 border border-gray-200 px-2.5 py-1 rounded-lg">
                        <Clock size={13} className="text-brand" /> {pkg.duration}
                      </span>
                      <span className="text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded">
                        ✓ Flights & Stay Included
                      </span>
                    </div>

                    <p className="text-xs text-text-secondary line-clamp-2 mb-4 leading-relaxed font-medium">
                      {pkg.description}
                    </p>

                    <div className="space-y-1 mb-5">
                      {pkg.highlights.slice(0, 2).map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-xs text-gray-700 font-semibold">
                          <Check size={14} className="text-green-600 shrink-0" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Dual Price & CTA */}
                  <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                        Starting Per Person
                      </p>
                      {/* Dual currency display: Rupees and Dollars */}
                      <div className="flex items-baseline gap-2">
                        <p className="text-2xl font-black text-brand leading-none">
                          {pkgPrice.primaryFormatted}
                        </p>
                        <span className="text-sm font-bold text-gray-500">
                          ({pkgPrice.secondaryFormatted})
                        </span>
                      </div>
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedPackage(pkg);
                        setBookingSuccess(false);
                      }}
                      className="bg-brand hover:bg-brand-dark text-white px-6 py-3 rounded-xl font-black text-xs shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>VIEW DETAILS & BOOK</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Package Detail & Booking Modal */}
      <AnimatePresence>
        {selectedPackage && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-2xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              <button
                onClick={() => setSelectedPackage(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="relative h-52 shrink-0">
                <img src={selectedPackage.image} alt={selectedPackage.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
                <div className="absolute bottom-4 left-6 right-12 text-white">
                  <span className="bg-brand text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full mb-1 inline-block">
                    {selectedPackage.duration}
                  </span>
                  <h3 className="text-2xl font-black">{selectedPackage.title}</h3>
                  <p className="text-white/80 text-xs font-semibold flex items-center gap-1 mt-0.5">
                    <MapPin size={12} className="text-brand" /> {selectedPackage.dest}
                  </p>
                </div>
              </div>

              <div className="p-6 overflow-y-auto flex-1 space-y-6">
                {!bookingSuccess ? (
                  <>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-gray-900 mb-2">Package Overview</h4>
                      <p className="text-xs text-text-secondary leading-relaxed font-medium">
                        {selectedPackage.description}
                      </p>
                    </div>

                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-gray-900 mb-2">Package Inclusions</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {selectedPackage.highlights.map((h, i) => (
                          <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 border border-gray-100 rounded-xl text-xs font-semibold text-gray-800">
                            <Check size={14} className="text-brand shrink-0" />
                            <span>{h}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Travelers Count & Dual Price Calculation */}
                    <div className="bg-gradient-to-br from-white to-blue-50/50 border border-blue-200 rounded-2xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-black uppercase text-gray-900 flex items-center gap-1.5">
                          <Users size={15} className="text-brand" /> Number of Travelers
                        </span>
                        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-2 py-1">
                          <button
                            type="button"
                            onClick={() => setTravelersCount(Math.max(1, travelersCount - 1))}
                            className="w-6 h-6 rounded bg-gray-100 font-bold hover:bg-gray-200"
                          >
                            -
                          </button>
                          <span className="text-xs font-black px-2">{travelersCount} Person(s)</span>
                          <button
                            type="button"
                            onClick={() => setTravelersCount(travelersCount + 1)}
                            className="w-6 h-6 rounded bg-gray-100 font-bold hover:bg-gray-200"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="border-t border-blue-100 pt-3 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-bold uppercase text-text-secondary block">
                            Total Tour Cost ({travelersCount} Person{travelersCount > 1 ? 's' : ''})
                          </span>
                          <span className="text-xs text-green-700 font-semibold">Taxes & transfers included</span>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-black text-brand leading-none">
                            {convertUsd(selectedPackage.priceUsd * travelersCount).primaryFormatted}
                          </div>
                          <span className="text-xs font-bold text-gray-500">
                            ({convertUsd(selectedPackage.priceUsd * travelersCount).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setBookingSuccess(true)}
                      className="w-full bg-brand hover:bg-brand-dark text-white py-3.5 rounded-xl font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck size={16} />
                      <span>CONFIRM HOLIDAY RESERVATION ({convertUsd(selectedPackage.priceUsd * travelersCount).primaryFormatted} / {convertUsd(selectedPackage.priceUsd * travelersCount).secondaryFormatted})</span>
                    </button>
                  </>
                ) : (
                  <div className="text-center py-6 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
                      <Check size={28} />
                    </div>
                    <h4 className="text-xl font-black text-gray-900">Holiday Tour Reserved!</h4>
                    <p className="text-xs text-text-secondary max-w-sm mx-auto">
                      Your booking for <strong>{selectedPackage.title}</strong> has been secured for {travelersCount} traveler(s). Our holiday concierge will contact you within 2 hours.
                    </p>
                    <div className="p-3 bg-gray-50 rounded-xl text-xs font-bold text-gray-700 inline-block">
                      Total: {formatDualPrice(selectedPackage.priceUsd * travelersCount).combined}
                    </div>
                    <div>
                      <button
                        onClick={() => setSelectedPackage(null)}
                        className="bg-brand text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow cursor-pointer"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Holidays;
