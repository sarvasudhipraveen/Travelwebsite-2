import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Train, 
  Clock, 
  MapPin, 
  ChevronRight, 
  ShieldCheck, 
  Star, 
  Search, 
  SlidersHorizontal, 
  RotateCcw, 
  CheckCircle2, 
  Printer, 
  X, 
  ArrowRight, 
  Sparkles, 
  Utensils, 
  Wifi, 
  Coffee, 
  Zap, 
  User, 
  Info,
  Calendar,
  Layers
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';

interface TrainClassOption {
  code: '1A' | '2A' | '3A' | 'CC' | 'EC';
  name: string;
  priceInr: number;
  availableSeats: number;
  status: 'Available' | 'RAC' | 'WL';
}

interface TrainRoute {
  id: string;
  number: string;
  name: string;
  type: 'Vande Bharat' | 'Rajdhani' | 'Shatabdi' | 'Tejas' | 'Heritage';
  fromStation: string;
  fromCity: string;
  toStation: string;
  toCity: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  runningDays: string;
  speed: string;
  isHighSpeed: boolean;
  rating: number;
  reviewsCount: number;
  image: string;
  badge?: string;
  classes: TrainClassOption[];
  hasPantry: boolean;
  hasWifi: boolean;
  description: string;
}

const trainsData: TrainRoute[] = [
  {
    id: 't1',
    number: '22436',
    name: 'Vande Bharat Express',
    type: 'Vande Bharat',
    fromStation: 'NDLS',
    fromCity: 'New Delhi',
    toStation: 'BSB',
    toCity: 'Varanasi Cantt',
    departureTime: '06:00',
    arrivalTime: '14:00',
    duration: '8h 00m',
    runningDays: 'Tue, Wed, Fri, Sat, Sun',
    speed: '130 km/h Avg',
    isHighSpeed: true,
    rating: 4.9,
    reviewsCount: 1240,
    badge: 'Semi-High Speed 18',
    image: 'https://images.unsplash.com/photo-1532105956626-9569c03602f6?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: true,
    classes: [
      { code: 'CC', name: 'AC Chair Car', priceInr: 1750, availableSeats: 48, status: 'Available' },
      { code: 'EC', name: 'Executive Chair Car', priceInr: 3300, availableSeats: 16, status: 'Available' }
    ],
    description: 'India flagship semi-high speed train equipped with 180-degree rotating seats, panoramic bio-vacuum windows, onboard infotainment, and hot gourmet catering.'
  },
  {
    id: 't2',
    number: '12952',
    name: 'Mumbai Rajdhani Express',
    type: 'Rajdhani',
    fromStation: 'NDLS',
    fromCity: 'New Delhi',
    toStation: 'MMCT',
    toCity: 'Mumbai Central',
    departureTime: '16:55',
    arrivalTime: '08:35',
    duration: '15h 40m',
    runningDays: 'Daily',
    speed: '120 km/h Avg',
    isHighSpeed: true,
    rating: 4.9,
    reviewsCount: 2180,
    badge: 'King of Tracks',
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: false,
    classes: [
      { code: '3A', name: 'AC 3 Tier (Economy)', priceInr: 2150, availableSeats: 72, status: 'Available' },
      { code: '2A', name: 'AC 2 Tier (Comfort)', priceInr: 3100, availableSeats: 34, status: 'Available' },
      { code: '1A', name: 'First AC (Royal Coupe)', priceInr: 5200, availableSeats: 8, status: 'Available' }
    ],
    description: 'The legendary premium overnight express connecting the capital to Mumbai. Includes 4-course hot dining, fresh bedding, and supreme track priority.'
  },
  {
    id: 't3',
    number: '82902',
    name: 'IRCTC Tejas Express',
    type: 'Tejas',
    fromStation: 'ADI',
    fromCity: 'Ahmedabad',
    toStation: 'MMCT',
    toCity: 'Mumbai Central',
    departureTime: '06:40',
    arrivalTime: '13:05',
    duration: '6h 25m',
    runningDays: 'Mon, Wed, Thu, Fri, Sat, Sun',
    speed: '115 km/h Avg',
    isHighSpeed: false,
    rating: 4.8,
    reviewsCount: 890,
    badge: 'Corporate Luxury',
    image: 'https://images.unsplash.com/photo-1515165562839-978bbcf18277?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: true,
    classes: [
      { code: 'CC', name: 'Smart AC Chair Car', priceInr: 1480, availableSeats: 56, status: 'Available' },
      { code: 'EC', name: 'Executive Luxury Class', priceInr: 2750, availableSeats: 12, status: 'Available' }
    ],
    description: 'Privately operated high-tech train featuring flight-style hostess service, tea/coffee vending machines, complimentary travel insurance, and personalized LCD screens.'
  },
  {
    id: 't4',
    number: '12002',
    name: 'Bhopal Shatabdi Express',
    type: 'Shatabdi',
    fromStation: 'NDLS',
    fromCity: 'New Delhi',
    toStation: 'AGC',
    toCity: 'Agra Cantt (Taj Mahal)',
    departureTime: '06:00',
    arrivalTime: '07:50',
    duration: '1h 50m',
    runningDays: 'Daily',
    speed: '125 km/h Avg',
    isHighSpeed: true,
    rating: 4.7,
    reviewsCount: 1540,
    badge: 'Fastest Taj Connection',
    image: 'https://images.unsplash.com/photo-1541427468627-a89a96e5ca1d?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: false,
    classes: [
      { code: 'CC', name: 'AC Chair Car', priceInr: 750, availableSeats: 82, status: 'Available' },
      { code: 'EC', name: 'Executive Chair Car', priceInr: 1520, availableSeats: 22, status: 'Available' }
    ],
    description: 'The quickest gateway to the Taj Mahal from New Delhi. Arrive in under 2 hours with hot morning breakfast, daily newspapers, and wide glass views.'
  },
  {
    id: 't5',
    number: '12414',
    name: 'Jaipur Intercity Superfast',
    type: 'Rajdhani',
    fromStation: 'NDLS',
    fromCity: 'New Delhi',
    toStation: 'JP',
    toCity: 'Jaipur Junction',
    departureTime: '15:20',
    arrivalTime: '19:50',
    duration: '4h 30m',
    runningDays: 'Daily',
    speed: '110 km/h Avg',
    isHighSpeed: false,
    rating: 4.8,
    reviewsCount: 760,
    badge: 'Pink City Express',
    image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: false,
    classes: [
      { code: '3A', name: 'AC 3 Tier', priceInr: 890, availableSeats: 45, status: 'Available' },
      { code: '2A', name: 'AC 2 Tier', priceInr: 1350, availableSeats: 20, status: 'Available' },
      { code: 'CC', name: 'AC Chair Car', priceInr: 680, availableSeats: 94, status: 'Available' }
    ],
    description: 'Smooth superfast journey across the Aravalli hills into Rajasthan royal capital. Highly punctual with afternoon refreshments included.'
  },
  {
    id: 't6',
    number: '04505',
    name: 'Kalka Shimla Himalayan Toy Train',
    type: 'Heritage',
    fromStation: 'KLK',
    fromCity: 'Kalka Station',
    toStation: 'SML',
    toCity: 'Shimla Ridge',
    departureTime: '07:00',
    arrivalTime: '12:15',
    duration: '5h 15m',
    runningDays: 'Daily',
    speed: '25 km/h Scenic',
    isHighSpeed: false,
    rating: 5.0,
    reviewsCount: 1650,
    badge: 'UNESCO World Heritage',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80',
    hasPantry: false,
    hasWifi: false,
    classes: [
      { code: 'CC', name: 'Shivalik Deluxe Express', priceInr: 510, availableSeats: 30, status: 'Available' },
      { code: 'EC', name: 'Himalayan Queen Vistadome', priceInr: 1100, availableSeats: 14, status: 'Available' }
    ],
    description: 'Enchanting narrow-gauge rail ride traversing 103 tunnels and 800+ bridges amidst pine forests and misty Himalayan peaks.'
  },
  {
    id: 't7',
    number: '20833',
    name: 'Vande Bharat Express (Secunderabad - Vizag)',
    type: 'Vande Bharat',
    fromStation: 'SC',
    fromCity: 'Secunderabad',
    toStation: 'VSKP',
    toCity: 'Visakhapatnam',
    departureTime: '15:00',
    arrivalTime: '23:30',
    duration: '8h 30m',
    runningDays: 'Mon, Tue, Wed, Thu, Fri, Sun',
    speed: '130 km/h Avg',
    isHighSpeed: true,
    rating: 4.9,
    reviewsCount: 920,
    badge: 'Coastal Aerodynamic',
    image: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=1000&q=80',
    hasPantry: true,
    hasWifi: true,
    classes: [
      { code: 'CC', name: 'AC Chair Car', priceInr: 1665, availableSeats: 62, status: 'Available' },
      { code: 'EC', name: 'Executive Chair Car', priceInr: 3120, availableSeats: 18, status: 'Available' }
    ],
    description: 'Rapid interstate rail corridor connecting Hyderabad tech hubs to the Bay of Bengal coastline with high comfort and silent cabin insulation.'
  }
];

export default function Trains() {
  const { user } = useAuth();
  const { currency, convertInr } = useCurrency();

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRoute, setSelectedRoute] = useState('All');
  const [selectedType, setSelectedType] = useState<'All' | 'Vande Bharat' | 'Rajdhani' | 'Shatabdi' | 'Tejas' | 'Heritage'>('All');
  const [selectedClass, setSelectedClass] = useState<'All' | '1A' | '2A' | '3A' | 'CC' | 'EC'>('All');
  const [onlyHighSpeed, setOnlyHighSpeed] = useState(false);
  const [onlyWifi, setOnlyWifi] = useState(false);
  const [onlyPantry, setOnlyPantry] = useState(false);
  const [budgetFilter, setBudgetFilter] = useState<'All' | 'under1000' | 'under2000' | 'luxury'>('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'priceDesc' | 'durationAsc' | 'ratingDesc'>('recommended');

  // Booking Modal States
  const [selectedTrain, setSelectedTrain] = useState<TrainRoute | null>(null);
  const [selectedCoachCode, setSelectedCoachCode] = useState<string>('CC');
  const [passengerName, setPassengerName] = useState(user?.displayName || '');
  const [passengerAge, setPassengerAge] = useState<number>(28);
  const [passengerGender, setPassengerGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [berthPreference, setBerthPreference] = useState('Window Seat / Lower Berth');
  const [mealChoice, setMealChoice] = useState<'Veg' | 'Non-Veg' | 'No Meal'>('Veg');
  const [travelDate, setTravelDate] = useState(() => {
    const today = new Date();
    today.setDate(today.getDate() + 3);
    return today.toISOString().split('T')[0];
  });
  const [passengersCount, setPassengersCount] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);

  // Active Coach Object
  const activeCoach = useMemo(() => {
    if (!selectedTrain) return null;
    return selectedTrain.classes.find(c => c.code === selectedCoachCode) || selectedTrain.classes[0];
  }, [selectedTrain, selectedCoachCode]);

  // Pricing calculations
  const bookingPrices = useMemo(() => {
    if (!activeCoach) return { baseInr: 0, mealInr: 0, irctcTaxInr: 0, totalInr: 0 };
    const baseInr = activeCoach.priceInr * passengersCount;
    const mealInr = mealChoice !== 'No Meal' ? 180 * passengersCount : 0;
    const irctcTaxInr = Math.round((baseInr + mealInr) * 0.05); // 5% GST & catering surcharge
    const totalInr = baseInr + mealInr + irctcTaxInr;
    return { baseInr, mealInr, irctcTaxInr, totalInr };
  }, [activeCoach, passengersCount, mealChoice]);

  // Filtered Trains
  const filteredTrains = useMemo(() => {
    return trainsData
      .filter((train) => {
        const matchRoute = selectedRoute === 'All' || 
          `${train.fromCity} to ${train.toCity}`.toLowerCase().includes(selectedRoute.toLowerCase()) ||
          train.toCity.toLowerCase().includes(selectedRoute.toLowerCase());
        
        const matchType = selectedType === 'All' || train.type === selectedType;
        const matchClass = selectedClass === 'All' || train.classes.some(c => c.code === selectedClass);
        const matchHighSpeed = !onlyHighSpeed || train.isHighSpeed;
        const matchWifi = !onlyWifi || train.hasWifi;
        const matchPantry = !onlyPantry || train.hasPantry;

        let matchBudget = true;
        const minClassPrice = Math.min(...train.classes.map(c => c.priceInr));
        if (budgetFilter === 'under1000') matchBudget = minClassPrice <= 1000;
        else if (budgetFilter === 'under2000') matchBudget = minClassPrice <= 2000;
        else if (budgetFilter === 'luxury') matchBudget = minClassPrice >= 2500;

        const matchSearch = !searchQuery || 
          train.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          train.number.includes(searchQuery) ||
          train.fromCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
          train.toCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
          train.fromStation.toLowerCase().includes(searchQuery.toLowerCase()) ||
          train.toStation.toLowerCase().includes(searchQuery.toLowerCase());

        return matchRoute && matchType && matchClass && matchHighSpeed && matchWifi && matchPantry && matchBudget && matchSearch;
      })
      .sort((a, b) => {
        const aMinPrice = Math.min(...a.classes.map(c => c.priceInr));
        const bMinPrice = Math.min(...b.classes.map(c => c.priceInr));
        if (sortBy === 'priceAsc') return aMinPrice - bMinPrice;
        if (sortBy === 'priceDesc') return bMinPrice - aMinPrice;
        if (sortBy === 'durationAsc') return a.duration.localeCompare(b.duration);
        if (sortBy === 'ratingDesc') return b.rating - a.rating;
        return 0; // recommended
      });
  }, [selectedRoute, selectedType, selectedClass, onlyHighSpeed, onlyWifi, onlyPantry, budgetFilter, searchQuery, sortBy]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (selectedRoute !== 'All') count++;
    if (selectedType !== 'All') count++;
    if (selectedClass !== 'All') count++;
    if (onlyHighSpeed) count++;
    if (onlyWifi) count++;
    if (onlyPantry) count++;
    if (budgetFilter !== 'All') count++;
    if (sortBy !== 'recommended') count++;
    return count;
  }, [searchQuery, selectedRoute, selectedType, selectedClass, onlyHighSpeed, onlyWifi, onlyPantry, budgetFilter, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedRoute('All');
    setSelectedType('All');
    setSelectedClass('All');
    setOnlyHighSpeed(false);
    setOnlyWifi(false);
    setOnlyPantry(false);
    setBudgetFilter('All');
    setSortBy('recommended');
  };

  const handleConfirmTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrain || !activeCoach) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const pnr = 'PNR-' + Math.floor(1000000 + Math.random() * 9000000);
      const coachLetter = activeCoach.code === 'EC' ? 'E1' : activeCoach.code === '1A' ? 'H1' : activeCoach.code === '2A' ? 'A1' : activeCoach.code === '3A' ? 'B1' : 'C1';
      const berthNumber = Math.floor(12 + Math.random() * 50);

      setBookingConfirmed({
        pnr,
        trainNumber: selectedTrain.number,
        trainName: selectedTrain.name,
        fromCity: selectedTrain.fromCity,
        fromStation: selectedTrain.fromStation,
        toCity: selectedTrain.toCity,
        toStation: selectedTrain.toStation,
        departureTime: selectedTrain.departureTime,
        arrivalTime: selectedTrain.arrivalTime,
        travelDate,
        coachCode: activeCoach.code,
        coachName: activeCoach.name,
        coachSeat: `${coachLetter}-${berthNumber}`,
        berthPreference,
        mealChoice,
        passengersCount,
        passengerName: passengerName.trim() || 'Passenger',
        pricing: bookingPrices,
        bookedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      });
      setIsSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-24 relative overflow-hidden">
      {/* ================= MULTI-COLOR TOURISM AMBIENT BACKGROUND EFFECTS ================= */}
      <div className="absolute top-0 left-0 w-full h-[520px] bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      {/* Radiant Cyan Orb */}
      <div className="absolute top-16 -left-20 w-[420px] h-[420px] bg-cyan-400/20 rounded-full blur-[100px] pointer-events-none" />
      {/* Warm Sunset Amber Orb */}
      <div className="absolute top-28 right-10 w-[400px] h-[400px] bg-amber-500/20 rounded-full blur-[120px] pointer-events-none" />
      {/* Emerald Oasis Orb */}
      <div className="absolute top-80 left-1/3 w-[380px] h-[380px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      {/* Royal Violet Aura */}
      <div className="absolute top-36 left-1/2 -translate-x-1/2 w-[350px] h-[350px] bg-purple-500/15 rounded-full blur-[120px] pointer-events-none" />
      {/* Radial Stars Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Top Hero Banner with rich tourism colors */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        {/* Internal ambient glowing orbs */}
        <div className="absolute -top-12 -right-12 w-80 h-80 bg-cyan-400/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-10 left-1/4 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-10 left-10 w-64 h-64 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 w-60 h-60 bg-purple-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[size:28px_28px] opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Train size={15} /> IRCTC Authorized Premium Rail Bookings
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Book Vande Bharat, Rajdhani & Shatabdi
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            Reserve confirmed seats with real-time live availability, gourmet meals, and transparent pricing in {currency === 'INR' ? 'Rupees (₹)' : 'Dollars ($)'}.
          </p>
        </div>
      </div>

      {/* ================= COMPREHENSIVE FILTER OPTIONS BAR ================= */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-5 border border-[#E0E4E9] space-y-4">
          {/* Main Selectors Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
            {/* Search Train */}
            <div className="relative">
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Search Train / Number / Station
              </label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
                <Search size={16} className="text-gray-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Vande Bharat, 22436, NDLS..."
                  className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
                />
              </div>
            </div>

            {/* Route Selector */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Route / Corridor
              </label>
              <select
                value={selectedRoute}
                onChange={(e) => setSelectedRoute(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">🌍 All Rail Corridors</option>
                <option value="Varanasi">New Delhi ➔ Varanasi (Vande Bharat)</option>
                <option value="Mumbai">New Delhi ➔ Mumbai (Rajdhani)</option>
                <option value="Agra">New Delhi ➔ Agra Cantt (Shatabdi)</option>
                <option value="Jaipur">New Delhi ➔ Jaipur (Pink City)</option>
                <option value="Shimla">Kalka ➔ Shimla (Himalayan Toy Train)</option>
                <option value="Visakhapatnam">Secunderabad ➔ Visakhapatnam (Coastal)</option>
              </select>
            </div>

            {/* Train Category */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Train Type
              </label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">All Train Types</option>
                <option value="Vande Bharat">🚄 Vande Bharat Express (Semi-High Speed)</option>
                <option value="Rajdhani">👑 Rajdhani Express (Premium AC Sleeper)</option>
                <option value="Shatabdi">⚡ Shatabdi Express (Superfast Day Train)</option>
                <option value="Tejas">✨ Tejas Express (Smart Private Rail)</option>
                <option value="Heritage">🏔️ Heritage Scenic Rail (Toy Train)</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Sort Pricing & Speed
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="recommended">Recommended Picks</option>
                <option value="priceAsc">Fare: Low to High</option>
                <option value="priceDesc">Fare: High to Low</option>
                <option value="durationAsc">Fastest Duration</option>
                <option value="ratingDesc">Highest Customer Rating</option>
              </select>
            </div>
          </div>

          {/* Secondary Filter Row: Coach Class, Amenities & Budget */}
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {/* Class Filter Chips */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSelectedClass('All')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === 'All' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  All Coaches
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedClass('EC')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === 'EC' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  EC Exec
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedClass('CC')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === 'CC' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  CC Chair
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedClass('1A')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === '1A' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  1A First AC
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedClass('2A')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === '2A' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  2A Tier
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedClass('3A')}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                    selectedClass === '3A' ? "bg-brand text-white shadow-xs" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  3A Tier
                </button>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-2 pl-2">
                <label className="flex items-center gap-1.5 text-xs font-bold text-gray-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={onlyHighSpeed}
                    onChange={(e) => setOnlyHighSpeed(e.target.checked)}
                    className="rounded text-brand focus:ring-brand"
                  />
                  <span className="flex items-center gap-0.5"><Zap size={11} className="text-amber-500" /> High-Speed (120+ km/h)</span>
                </label>
                <label className="flex items-center gap-1.5 text-xs font-bold text-gray-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={onlyWifi}
                    onChange={(e) => setOnlyWifi(e.target.checked)}
                    className="rounded text-brand focus:ring-brand"
                  />
                  <span className="flex items-center gap-0.5"><Wifi size={11} className="text-blue-500" /> Free Wi-Fi</span>
                </label>
                <label className="flex items-center gap-1.5 text-xs font-bold text-gray-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={onlyPantry}
                    onChange={(e) => setOnlyPantry(e.target.checked)}
                    className="rounded text-brand focus:ring-brand"
                  />
                  <span className="flex items-center gap-0.5"><Utensils size={11} className="text-green-500" /> Catering Pantry</span>
                </label>
              </div>
            </div>

            {/* Clear All Filters */}
            {activeFiltersCount > 0 && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw size={13} />
                Reset Filters ({activeFiltersCount})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Train Cards Listing */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-black text-brand bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200 uppercase tracking-widest inline-flex items-center gap-1.5 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></span>
                Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
              </span>
            </div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Available Trains & Express Routes ({filteredTrains.length})
            </h2>
            <p className="text-xs md:text-sm text-text-secondary font-medium">
              Real-time reservation availability with instant IRCTC PNR generation and catering meal selection.
            </p>
          </div>
        </div>

        {filteredTrains.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-[#E0E4E9] shadow-sm max-w-lg mx-auto">
            <Train size={48} className="text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-black text-gray-800">No trains match your filters</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Try clearing some filters or searching for another station.</p>
            <button
              onClick={handleResetFilters}
              className="bg-brand text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm hover:bg-brand-dark transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {filteredTrains.map((train) => {
              const lowestPrice = Math.min(...train.classes.map(c => c.priceInr));
              const trainPrice = convertInr(lowestPrice);

              return (
                <motion.div
                  key={train.id}
                  whileHover={{ scale: 1.006 }}
                  className="bg-white rounded-3xl border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all p-5 md:p-7 flex flex-col lg:flex-row items-center gap-6 justify-between overflow-hidden relative"
                >
                  {/* Left: Train Photo & Identifiers */}
                  <div className="flex items-center gap-4 w-full lg:w-2/5">
                    <div className="w-28 h-24 rounded-2xl overflow-hidden bg-gray-100 shrink-0 relative shadow-2xs group border border-gray-100">
                      <img
                        src={train.image}
                        alt={train.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-2">
                        <span className="text-[9px] font-black text-white uppercase tracking-wider flex items-center gap-1">
                          <Star size={10} className="text-amber-400 fill-amber-400" /> {train.rating} ({train.reviewsCount})
                        </span>
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h4 className="font-black text-lg text-gray-900 truncate">{train.name}</h4>
                        {train.badge && (
                          <span className="text-[9px] font-black text-brand bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0">
                            {train.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-text-secondary font-bold uppercase tracking-wider">
                        #{train.number} • Runs: {train.runningDays}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[10px] font-bold text-gray-500">
                        <span className="bg-gray-100 px-2 py-0.5 rounded flex items-center gap-1">
                          <Zap size={11} className="text-amber-500" /> {train.speed}
                        </span>
                        {train.hasPantry && (
                          <span className="bg-green-50 text-green-700 px-2 py-0.5 rounded flex items-center gap-1">
                            <Utensils size={10} /> Pantry Meals
                          </span>
                        )}
                        {train.hasWifi && (
                          <span className="bg-blue-50 text-brand px-2 py-0.5 rounded flex items-center gap-1">
                            <Wifi size={10} /> Onboard Wi-Fi
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Middle: Timing Route Graph */}
                  <div className="flex items-center justify-between w-full lg:flex-1 px-0 lg:px-6 border-y lg:border-y-0 lg:border-x border-gray-100 py-4 lg:py-0">
                    <div className="text-center lg:text-left">
                      <h3 className="text-2xl font-black text-gray-900">{train.departureTime}</h3>
                      <p className="text-sm font-bold text-gray-800">{train.fromCity}</p>
                      <span className="text-[10px] font-bold text-text-secondary uppercase">({train.fromStation})</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <p className="text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">{train.duration}</p>
                      <div className="w-28 sm:w-36 h-[2px] bg-gray-200 relative">
                        <div className="absolute -top-1 left-0 w-2 h-2 rounded-full border border-brand bg-white" />
                        <div className="absolute -top-1 right-0 w-2 h-2 rounded-full border border-brand bg-white" />
                      </div>
                      <span className="text-[10px] font-bold text-emerald-600 mt-1 uppercase">Confirmed Priority</span>
                    </div>
                    <div className="text-center lg:text-right">
                      <h3 className="text-2xl font-black text-gray-900">{train.arrivalTime}</h3>
                      <p className="text-sm font-bold text-gray-800">{train.toCity}</p>
                      <span className="text-[10px] font-bold text-text-secondary uppercase">({train.toStation})</span>
                    </div>
                  </div>

                  {/* Right: Classes & Price CTA */}
                  <div className="flex items-center gap-5 w-full lg:w-auto justify-between lg:justify-end">
                    <div className="flex flex-col items-start lg:items-end flex-1 lg:flex-none">
                      <span className="text-[10px] font-bold text-text-secondary uppercase">Fares From</span>
                      <p className="text-3xl font-black text-brand leading-none">
                        {trainPrice.primaryFormatted}
                      </p>
                      <p className="text-[11px] font-bold text-gray-500 mt-1">
                        ({trainPrice.secondaryFormatted})
                      </p>
                      <span className="text-[10px] text-gray-400 font-semibold">{train.classes.length} Coaches Available</span>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedTrain(train);
                        setSelectedCoachCode(train.classes[0].code);
                        setBookingConfirmed(null);
                      }}
                      className="bg-brand text-white px-7 py-3.5 rounded-xl font-black text-xs shadow-lg hover:bg-brand-dark transition-all flex items-center gap-2 cursor-pointer shrink-0"
                    >
                      <span>SELECT SEATS</span>
                      <ArrowRight size={16} />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Train Booking Modal */}
      <AnimatePresence>
        {selectedTrain && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              <button
                onClick={() => setSelectedTrain(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="relative h-40 bg-gradient-to-r from-[#041422] to-[#008CFF] overflow-hidden">
                <img
                  src={selectedTrain.image}
                  alt={selectedTrain.name}
                  className="w-full h-full object-cover opacity-50 mix-blend-overlay"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-6 flex flex-col justify-end text-white">
                  <span className="text-[10px] font-black uppercase tracking-widest bg-brand px-2.5 py-0.5 rounded-md inline-block mb-1 w-max">
                    IRCTC Rail Reservation
                  </span>
                  <h3 className="text-2xl font-black">{selectedTrain.name} (#{selectedTrain.number})</h3>
                  <p className="text-white/80 text-xs font-semibold mt-0.5">
                    {selectedTrain.fromCity} ({selectedTrain.fromStation}) ➔ {selectedTrain.toCity} ({selectedTrain.toStation})
                  </p>
                </div>
              </div>

              <div className="p-6 overflow-y-auto flex-1">
                {!bookingConfirmed ? (
                  <form onSubmit={handleConfirmTicket} className="space-y-4 text-xs">
                    {/* Coach Class Picker */}
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-1">
                        Select Coach & Class
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {selectedTrain.classes.map((cls) => {
                          const isSelected = selectedCoachCode === cls.code;
                          const clsPrice = convertInr(cls.priceInr);
                          return (
                            <button
                              key={cls.code}
                              type="button"
                              onClick={() => setSelectedCoachCode(cls.code)}
                              className={cn(
                                "p-3 rounded-2xl border text-left transition-all cursor-pointer relative",
                                isSelected
                                  ? "bg-blue-50 border-brand shadow-xs"
                                  : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                              )}
                            >
                              <div className="flex justify-between items-start">
                                <span className={cn("font-black text-sm", isSelected ? "text-brand" : "text-gray-900")}>
                                  {cls.code}
                                </span>
                                <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                                  {cls.availableSeats} Left
                                </span>
                              </div>
                              <p className="text-[10px] text-text-secondary truncate mt-0.5 font-medium">{cls.name}</p>
                              <div className="mt-2 text-xs font-black text-gray-900">
                                {clsPrice.primaryFormatted}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Journey Date</label>
                        <input
                          type="date"
                          value={travelDate}
                          onChange={(e) => setTravelDate(e.target.value)}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] font-black uppercase text-gray-500">Passengers / Persons</label>
                          <span className="text-[10px] font-bold text-brand">Money Adjusts Dynamically</span>
                        </div>
                        <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5">
                          <button
                            type="button"
                            onClick={() => setPassengersCount(Math.max(1, passengersCount - 1))}
                            className="w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-800 font-black text-sm hover:bg-gray-100 flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Decrease person (reduces total money)"
                          >
                            -
                          </button>
                          <div className="text-center px-2">
                            <span className="text-xs font-black text-gray-900 block">{passengersCount} Passenger{passengersCount > 1 ? 's' : ''}</span>
                            <span className="text-[9px] text-gray-500 font-semibold">{passengersCount} Berth{passengersCount > 1 ? 's' : ''} reserved</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setPassengersCount(Math.min(6, passengersCount + 1))}
                            className="w-8 h-8 rounded-lg bg-brand text-white font-black text-sm hover:bg-brand-dark flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Increase person (increases total money)"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Primary Passenger Name</label>
                        <input
                          type="text"
                          required
                          value={passengerName}
                          onChange={(e) => setPassengerName(e.target.value)}
                          placeholder="Name as on Gov ID"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Berth Preference</label>
                        <select
                          value={berthPreference}
                          onChange={(e) => setBerthPreference(e.target.value)}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        >
                          <option value="Window Seat">Window Seat</option>
                          <option value="Lower Berth">Lower Berth</option>
                          <option value="Middle Berth">Middle Berth</option>
                          <option value="Upper Berth">Upper Berth</option>
                          <option value="Side Lower">Side Lower</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Gourmet Catering Meal</label>
                      <select
                        value={mealChoice}
                        onChange={(e) => setMealChoice(e.target.value as any)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                      >
                        <option value="Veg">Pure Vegetarian Gourmet Meal (+₹180 / $2.15)</option>
                        <option value="Non-Veg">Non-Vegetarian Chef Special (+₹180 / $2.15)</option>
                        <option value="No Meal">Opt Out of Catering (No Extra Charge)</option>
                      </select>
                    </div>

                    {/* Price Breakdown in Rupees and Dollars */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2 font-medium">
                      <div className="flex justify-between text-gray-600">
                        <span>Base Fare ({passengersCount} × {convertInr(activeCoach?.priceInr || 0).primaryFormatted})</span>
                        <span className="font-bold text-gray-900">{convertInr(bookingPrices.baseInr).primaryFormatted}</span>
                      </div>
                      {mealChoice !== 'No Meal' && (
                        <div className="flex justify-between text-gray-600">
                          <span>IRCTC Catering ({mealChoice})</span>
                          <span className="font-bold text-gray-900">{convertInr(bookingPrices.mealInr).primaryFormatted}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-gray-600">
                        <span>Rail GST & Platform Surcharge (5%)</span>
                        <span className="font-bold text-gray-900">{convertInr(bookingPrices.irctcTaxInr).primaryFormatted}</span>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between text-sm font-black text-gray-900">
                        <span>Total Payable Amount</span>
                        <div className="text-right">
                          <span className="text-brand text-base block">
                            {convertInr(bookingPrices.totalInr).primaryFormatted}
                          </span>
                          <span className="text-[11px] text-gray-500 font-bold block">
                            ({convertInr(bookingPrices.totalInr).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-brand hover:bg-brand-dark text-white font-black py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                    >
                      <ShieldCheck size={18} />
                      <span>CONFIRM RAIL BOOKING ({convertInr(bookingPrices.totalInr).primaryFormatted})</span>
                    </button>
                  </form>
                ) : (
                  /* Confirmed Rail Ticket Voucher */
                  <div className="text-center py-4 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle2 size={32} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-gray-900">Train Ticket Reserved!</h4>
                      <p className="text-gray-500 text-xs mt-1">
                        IRCTC Authorized Ticket issued for <strong>{bookingConfirmed.passengerName}</strong>
                      </p>
                    </div>

                    {/* Voucher Card */}
                    <div className="bg-white border-2 border-dashed border-gray-300 rounded-2xl p-5 text-left space-y-3 shadow-inner">
                      <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                        <div>
                          <span className="text-[10px] font-black uppercase tracking-wider text-brand">IRCTC ELECTRONIC RESERVATION SLIP</span>
                          <h5 className="font-black text-gray-800">{bookingConfirmed.trainName} (#{bookingConfirmed.trainNumber})</h5>
                        </div>
                        <span className="bg-blue-50 text-brand px-2 py-1 rounded text-xs font-black">
                          {bookingConfirmed.pnr}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Passenger</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.passengerName}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Coach & Seat</span>
                          <span className="font-bold text-emerald-600">{bookingConfirmed.coachSeat} ({bookingConfirmed.coachCode})</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Departure</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.fromCity} ({bookingConfirmed.departureTime})</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Destination</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.toCity} ({bookingConfirmed.arrivalTime})</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Travel Date</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.travelDate}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Catering Choice</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.mealChoice}</span>
                        </div>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between items-center text-xs">
                        <span className="font-bold text-gray-500">Total Amount Paid</span>
                        <div className="text-right">
                          <span className="font-black text-brand text-sm block">
                            {convertInr(bookingConfirmed.pricing.totalInr).primaryFormatted}
                          </span>
                          <span className="text-[10px] font-bold text-gray-500">
                            ({convertInr(bookingConfirmed.pricing.totalInr).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedTrain(null)}
                      className="w-full bg-gray-900 text-white font-black py-3 rounded-xl hover:bg-black transition-all cursor-pointer text-xs"
                    >
                      Close & Return to Trains
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
