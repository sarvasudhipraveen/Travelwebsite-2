import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  Plane, 
  Filter, 
  ArrowRight, 
  ShieldCheck, 
  Check, 
  X, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  User, 
  Search, 
  RotateCcw, 
  Sparkles, 
  Luggage, 
  Utensils,
  Star,
  Sunrise,
  Sun,
  Moon,
  SlidersHorizontal,
  ChevronDown,
  Printer
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useCurrency } from '../lib/CurrencyContext';
import { useAuth } from '../lib/AuthContext';
import { cn } from '../lib/utils';

interface Flight {
  id: number;
  airline: string;
  flightNo: string;
  aircraft: string;
  from: string;
  fromCity: string;
  to: string;
  toCity: string;
  priceUsd: number;
  time: string;
  duration: string;
  stops: string;
  baggage: string;
  mealsIncluded: boolean;
  image: string;
  rating: number;
  reviewsCount: number;
  departurePeriod: 'morning' | 'afternoon' | 'evening';
  badge?: string;
}

const flightData: Flight[] = [
  { 
    id: 1, 
    airline: 'Air India', 
    flightNo: 'AI-995', 
    aircraft: 'Airbus A350-900',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'DXB', 
    toCity: 'Dubai', 
    priceUsd: 240, 
    time: '14:20 - 17:50', 
    duration: '3h 30m', 
    stops: 'Non-stop',
    baggage: '25 kg check-in + 7 kg cabin',
    mealsIncluded: true,
    image: 'https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    reviewsCount: 840,
    departurePeriod: 'afternoon',
    badge: 'Flagship A350'
  },
  { 
    id: 2, 
    airline: 'Emirates', 
    flightNo: 'EK-511', 
    aircraft: 'Boeing 777-300ER',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'DXB', 
    toCity: 'Dubai', 
    priceUsd: 520, 
    time: '10:30 - 13:45', 
    duration: '3h 15m', 
    stops: 'Non-stop',
    baggage: '30 kg check-in + 7 kg cabin',
    mealsIncluded: true,
    image: 'https://images.unsplash.com/photo-1520437358207-323b43b50729?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    reviewsCount: 1420,
    departurePeriod: 'morning',
    badge: 'Top Rated 5-Star'
  },
  { 
    id: 3, 
    airline: 'IndiGo', 
    flightNo: '6E-1461', 
    aircraft: 'Airbus A321neo',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'DXB', 
    toCity: 'Dubai', 
    priceUsd: 190, 
    time: '20:15 - 23:55', 
    duration: '3h 40m', 
    stops: 'Non-stop',
    baggage: '20 kg check-in + 7 kg cabin',
    mealsIncluded: false,
    image: 'https://images.unsplash.com/photo-1570710891163-6d3b5c47248b?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    reviewsCount: 960,
    departurePeriod: 'evening',
    badge: 'Lowest Fare Guaranteed'
  },
  { 
    id: 4, 
    airline: 'Qatar Airways', 
    flightNo: 'QR-571', 
    aircraft: 'Boeing 787 Dreamliner',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'DXB', 
    toCity: 'Dubai', 
    priceUsd: 610, 
    time: '08:00 - 11:30', 
    duration: '3h 30m', 
    stops: '1 Stop via DOH',
    baggage: '35 kg check-in + 7 kg cabin',
    mealsIncluded: true,
    image: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    reviewsCount: 1100,
    departurePeriod: 'morning',
    badge: 'World Best Business'
  },
  { 
    id: 5, 
    airline: 'Singapore Airlines', 
    flightNo: 'SQ-403', 
    aircraft: 'Airbus A380 Superjumbo',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'SIN', 
    toCity: 'Singapore Changi', 
    priceUsd: 380, 
    time: '09:50 - 18:05', 
    duration: '5h 45m', 
    stops: 'Non-stop',
    baggage: '30 kg check-in + 7 kg cabin',
    mealsIncluded: true,
    image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=800&q=80',
    rating: 5.0,
    reviewsCount: 1850,
    departurePeriod: 'morning',
    badge: 'Iconic Double Decker'
  },
  { 
    id: 6, 
    airline: 'Lufthansa', 
    flightNo: 'LH-761', 
    aircraft: 'Boeing 747-8 Queen',
    from: 'DEL', 
    fromCity: 'New Delhi', 
    to: 'FRA', 
    toCity: 'Frankfurt Intl', 
    priceUsd: 490, 
    time: '03:15 - 08:20', 
    duration: '8h 35m', 
    stops: 'Non-stop',
    baggage: '32 kg check-in + 8 kg cabin',
    mealsIncluded: true,
    image: 'https://images.unsplash.com/photo-1517479149777-5f3b1511d5ad?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    reviewsCount: 720,
    departurePeriod: 'morning',
    badge: 'Queen of the Skies'
  }
];

export default function Flights() {
  const { formatPrice, currency, convertUsd } = useCurrency();
  const { user } = useAuth();

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAirline, setSelectedAirline] = useState('All');
  const [selectedStops, setSelectedStops] = useState('All');
  const [selectedPeriod, setSelectedPeriod] = useState<'All' | 'morning' | 'afternoon' | 'evening'>('All');
  const [budgetFilter, setBudgetFilter] = useState<'All' | 'under250' | 'under400' | 'under600'>('All');
  const [onlyMeals, setOnlyMeals] = useState(false);
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'priceDesc' | 'durationAsc' | 'ratingDesc'>('recommended');

  // Booking Modal States
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [passengerCount, setPassengerCount] = useState(1);
  const [cabinClass, setCabinClass] = useState<'Economy' | 'Business'>('Economy');
  const [passengerName, setPassengerName] = useState(user?.displayName || '');
  const [passengerEmail, setPassengerEmail] = useState(user?.email || '');
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);

  const calculateTotal = (baseUsd: number) => {
    const classMultiplier = cabinClass === 'Business' ? 2.2 : 1;
    const subtotal = Math.round(baseUsd * classMultiplier * passengerCount);
    const taxes = Math.round(subtotal * 0.12);
    return { subtotal, taxes, total: subtotal + taxes };
  };

  // Filtered & Sorted Flights
  const filteredFlights = useMemo(() => {
    return flightData
      .filter((flight) => {
        const matchAirline = selectedAirline === 'All' || flight.airline === selectedAirline;
        const matchStops = selectedStops === 'All' || flight.stops.includes(selectedStops);
        const matchPeriod = selectedPeriod === 'All' || flight.departurePeriod === selectedPeriod;
        
        let matchBudget = true;
        if (budgetFilter === 'under250') matchBudget = flight.priceUsd <= 250;
        else if (budgetFilter === 'under400') matchBudget = flight.priceUsd <= 400;
        else if (budgetFilter === 'under600') matchBudget = flight.priceUsd <= 600;

        const matchMeals = !onlyMeals || flight.mealsIncluded;

        const matchSearch = !searchQuery || 
          flight.airline.toLowerCase().includes(searchQuery.toLowerCase()) ||
          flight.flightNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
          flight.fromCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
          flight.toCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
          flight.aircraft.toLowerCase().includes(searchQuery.toLowerCase());
        
        return matchAirline && matchStops && matchPeriod && matchBudget && matchMeals && matchSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'priceAsc') return a.priceUsd - b.priceUsd;
        if (sortBy === 'priceDesc') return b.priceUsd - a.priceUsd;
        if (sortBy === 'durationAsc') return a.duration.localeCompare(b.duration);
        if (sortBy === 'ratingDesc') return b.rating - a.rating;
        return 0;
      });
  }, [selectedAirline, selectedStops, selectedPeriod, budgetFilter, onlyMeals, searchQuery, sortBy]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (selectedAirline !== 'All') count++;
    if (selectedStops !== 'All') count++;
    if (selectedPeriod !== 'All') count++;
    if (budgetFilter !== 'All') count++;
    if (onlyMeals) count++;
    if (sortBy !== 'recommended') count++;
    return count;
  }, [searchQuery, selectedAirline, selectedStops, selectedPeriod, budgetFilter, onlyMeals, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedAirline('All');
    setSelectedStops('All');
    setSelectedPeriod('All');
    setBudgetFilter('All');
    setOnlyMeals(false);
    setSortBy('recommended');
  };

  const handleConfirmFlight = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFlight) return;
    const totals = calculateTotal(selectedFlight.priceUsd);
    setBookingConfirmed({
      ticketNo: 'ETK-' + Math.floor(100000 + Math.random() * 900000),
      flight: selectedFlight,
      passengerName: passengerName.trim() || 'Passenger',
      passengerEmail: passengerEmail.trim() || 'passenger@tripverse.app',
      passengerCount,
      cabinClass,
      totalUsd: totals.total,
      bookedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    });
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-24 relative overflow-hidden">
      {/* ================= MULTI-COLOR TOURISM AMBIENT BACKGROUND EFFECTS ================= */}
      <div className="absolute top-0 left-0 w-full h-[520px] bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      {/* Radiant Cyan Orb */}
      <div className="absolute top-16 -left-20 w-[420px] h-[420px] bg-cyan-400/20 rounded-full blur-[100px] pointer-events-none" />
      {/* Warm Sunset Amber Orb */}
      <div className="absolute top-28 right-10 w-[400px] h-[400px] bg-amber-500/20 rounded-full blur-[120px] pointer-events-none" />
      {/* Emerald Oasis Orb */}
      <div className="absolute top-80 left-1/3 w-[380px] h-[380px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      {/* Royal Violet Aura */}
      <div className="absolute top-36 left-1/2 -translate-x-1/2 w-[350px] h-[350px] bg-purple-500/15 rounded-full blur-[120px] pointer-events-none" />
      {/* Radial Stars Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Hero Header with Rich Tourism Multi-Color Effects */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        {/* Internal ambient glowing orbs */}
        <div className="absolute -top-12 -right-12 w-80 h-80 bg-cyan-400/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-10 left-1/4 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-10 left-10 w-64 h-64 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 w-60 h-60 bg-purple-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[size:28px_28px] opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Plane size={15} /> Domestic & International Flight Booking
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Compare & Book Lowest Airfares
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            Direct airline inventory from Emirates, Air India, IndiGo & Qatar Airways. Real-time pricing in Rupees (₹) and Dollars ($).
          </p>
        </div>
      </div>

      {/* ================= COMPREHENSIVE FILTER OPTIONS BAR ================= */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-5 border border-[#E0E4E9] space-y-4">
          {/* Top Row: Search & Selectors */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
            {/* Search Airport / City */}
            <div className="relative">
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Search Airline, Flight No, City
              </label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
                <Search size={16} className="text-gray-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Air India, Emirates, DEL, DXB..."
                  className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
                />
              </div>
            </div>

            {/* Airline Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Airline Carrier
              </label>
              <select
                value={selectedAirline}
                onChange={(e) => setSelectedAirline(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">All Airlines</option>
                <option value="Air India">Air India (Flagship A350)</option>
                <option value="Emirates">Emirates (Boeing 777)</option>
                <option value="IndiGo">IndiGo (Airbus A321neo)</option>
                <option value="Qatar Airways">Qatar Airways (Dreamliner)</option>
                <option value="Singapore Airlines">Singapore Airlines (A380)</option>
                <option value="Lufthansa">Lufthansa (Boeing 747-8)</option>
              </select>
            </div>

            {/* Stops Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Stops / Layover
              </label>
              <select
                value={selectedStops}
                onChange={(e) => setSelectedStops(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">All Flight Routes</option>
                <option value="Non-stop">Non-Stop Direct Flights</option>
                <option value="1 Stop">1 Stop Connecting Flights</option>
              </select>
            </div>

            {/* Sort Airfare */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Sort Airfare
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="recommended">Best Value Picks</option>
                <option value="priceAsc">Fare: Low to High</option>
                <option value="priceDesc">Fare: High to Low</option>
                <option value="ratingDesc">Highest Customer Rating</option>
                <option value="durationAsc">Fastest Travel Time</option>
              </select>
            </div>
          </div>

          {/* Secondary Filter Row: Departure Timing & Budget Range */}
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
            {/* Departure Period Filter Chips */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 mr-1 flex items-center gap-1">
                <Clock size={12} /> Time:
              </span>
              <button
                type="button"
                onClick={() => setSelectedPeriod('All')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  selectedPeriod === 'All' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Any Time
              </button>
              <button
                type="button"
                onClick={() => setSelectedPeriod('morning')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                  selectedPeriod === 'morning' ? "bg-amber-500 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Sunrise size={12} /> Morning (06:00 - 12:00)
              </button>
              <button
                type="button"
                onClick={() => setSelectedPeriod('afternoon')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                  selectedPeriod === 'afternoon' ? "bg-orange-500 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Sun size={12} /> Afternoon (12:00 - 18:00)
              </button>
              <button
                type="button"
                onClick={() => setSelectedPeriod('evening')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                  selectedPeriod === 'evening' ? "bg-indigo-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Moon size={12} /> Evening (18:00+)
              </button>
            </div>

            {/* Budget Range Filter Chips */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 mr-1">
                Budget:
              </span>
              <button
                type="button"
                onClick={() => setBudgetFilter('All')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'All' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                All Fares
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under250')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under250' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Under $250 / ₹21,000
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under400')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under400' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Under $400 / ₹33,600
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under600')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under600' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Under $600 / ₹50,400
              </button>
            </div>

            {/* Meal Filter & Reset */}
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-xs font-bold text-gray-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={onlyMeals}
                  onChange={(e) => setOnlyMeals(e.target.checked)}
                  className="rounded text-brand focus:ring-brand"
                />
                <span>Free Meals Only</span>
              </label>

              {activeFiltersCount > 0 && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                >
                  <RotateCcw size={12} />
                  Reset ({activeFiltersCount})
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Flights Listing */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-black text-brand bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200 uppercase tracking-widest inline-flex items-center gap-1.5 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></span>
                Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
              </span>
            </div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Available Flights ({filteredFlights.length})
            </h2>
            <p className="text-xs md:text-sm text-text-secondary font-medium">
              Real-time published airline fares with free cabin baggage and instant e-ticket issuance.
            </p>
          </div>
        </div>

        {filteredFlights.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-[#E0E4E9] shadow-sm max-w-lg mx-auto">
            <Plane size={48} className="text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-black text-gray-800">No flights match your filters</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Try clearing some filters or selecting another airline.</p>
            <button
              onClick={handleResetFilters}
              className="bg-brand text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm hover:bg-brand-dark transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {filteredFlights.map((flight) => (
              <motion.div 
                whileHover={{ scale: 1.006 }}
                key={flight.id} 
                className="bg-white rounded-3xl border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all p-5 md:p-7 flex flex-col md:flex-row items-center gap-6 justify-between overflow-hidden relative"
              >
                {/* Airline & Aircraft Info with Aircraft Image */}
                <div className="flex items-center gap-4 w-full md:w-2/5">
                  <div className="w-24 h-20 rounded-2xl overflow-hidden bg-gray-100 shrink-0 relative shadow-2xs group border border-gray-100">
                    <img 
                      src={flight.image} 
                      alt={flight.airline}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-1.5">
                      <span className="text-[9px] font-black text-white uppercase tracking-wider flex items-center gap-0.5">
                        <Star size={10} className="text-amber-400 fill-amber-400" /> {flight.rating}
                      </span>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h4 className="font-black text-lg text-gray-900 truncate">{flight.airline}</h4>
                      {flight.badge && (
                        <span className="text-[9px] font-black text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0">
                          {flight.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-text-secondary font-bold uppercase tracking-wider">
                      {flight.flightNo} • {flight.stops}
                    </p>
                    <p className="text-[11px] text-gray-500 font-semibold mt-0.5">
                      {flight.aircraft}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[10px] font-bold text-gray-500">
                      <span className="flex items-center gap-1"><Luggage size={11} className="text-brand" /> {flight.baggage}</span>
                      {flight.mealsIncluded && (
                        <span className="flex items-center gap-1 text-green-700 bg-green-50 px-1.5 py-0.5 rounded"><Utensils size={10} /> Meal Included</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Timing & Destination */}
                <div className="flex items-center justify-between w-full md:flex-1 px-0 md:px-6 border-y md:border-y-0 md:border-x border-gray-100 py-4 md:py-0">
                  <div className="text-center md:text-left">
                    <h3 className="text-2xl font-black text-gray-900">{flight.time.split(' - ')[0]}</h3>
                    <p className="text-sm font-bold text-text-secondary">{flight.from} ({flight.fromCity})</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <p className="text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">{flight.duration}</p>
                    <div className="w-28 sm:w-36 h-[2px] bg-gray-200 relative">
                      <div className="absolute -top-1 left-0 w-2 h-2 rounded-full border border-brand bg-white" />
                      <div className="absolute -top-1 right-0 w-2 h-2 rounded-full border border-brand bg-white" />
                    </div>
                    <span className="text-[10px] font-bold text-brand mt-1 uppercase">{flight.stops}</span>
                  </div>
                  <div className="text-center md:text-right">
                    <h3 className="text-2xl font-black text-gray-900">{flight.time.split(' - ')[1]}</h3>
                    <p className="text-sm font-bold text-text-secondary">{flight.to} ({flight.toCity})</p>
                  </div>
                </div>

                {/* Dynamic Price Format & CTA */}
                <div className="flex items-center gap-5 w-full md:w-auto justify-between md:justify-end">
                  <div className="flex flex-col items-start md:items-end flex-1 md:flex-none">
                    <p className="text-3xl font-black text-brand leading-none">
                      {convertUsd(flight.priceUsd).primaryFormatted}
                    </p>
                    <p className="text-[11px] font-bold text-gray-500 mt-1">
                      ({convertUsd(flight.priceUsd).secondaryFormatted})
                    </p>
                    <p className="text-[10px] font-bold text-text-secondary uppercase">per traveler</p>
                  </div>
                  <button 
                    onClick={() => {
                      setSelectedFlight(flight);
                      setBookingConfirmed(null);
                    }}
                    className="bg-brand text-white px-7 py-3.5 rounded-xl font-black text-xs shadow-lg hover:bg-brand-dark transition-all flex items-center gap-2 cursor-pointer shrink-0"
                  >
                    BOOK <ArrowRight size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-12 p-8 bg-blue-50 border border-brand/10 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <div className="p-4 bg-white rounded-2xl shadow-sm text-brand shrink-0">
              <ShoppingBag size={32} />
            </div>
            <div>
              <h4 className="text-xl font-black text-gray-900">Get 10% instant airfare discount</h4>
              <p className="text-sm text-text-secondary font-medium">Extra baggage allowance on all international flights. Currency synchronized in {currency}.</p>
            </div>
          </div>
          <button className="text-sm font-black text-brand bg-white px-6 py-2.5 rounded-xl shadow-sm hover:shadow transition-all shrink-0 cursor-pointer">
            VIEW OFFER
          </button>
        </div>
      </div>

      {/* Flight Booking Modal */}
      <AnimatePresence>
        {selectedFlight && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              <button
                onClick={() => setSelectedFlight(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="relative h-36 bg-gradient-to-r from-[#041422] to-[#008CFF] overflow-hidden">
                <img 
                  src={selectedFlight.image} 
                  alt={selectedFlight.airline}
                  className="w-full h-full object-cover opacity-40 mix-blend-overlay"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 flex flex-col justify-end text-white">
                  <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded-md inline-block mb-1 w-max">
                    Confirmed Flight Reservation
                  </span>
                  <h3 className="text-2xl font-black">{selectedFlight.airline} • {selectedFlight.flightNo}</h3>
                  <p className="text-white/80 text-xs font-semibold mt-1">
                    {selectedFlight.from} ({selectedFlight.fromCity}) ➔ {selectedFlight.to} ({selectedFlight.toCity}) • {selectedFlight.aircraft}
                  </p>
                </div>
              </div>

              <div className="p-6 overflow-y-auto flex-1">
                {!bookingConfirmed ? (
                  <form onSubmit={handleConfirmFlight} className="space-y-4 text-xs">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Cabin Class</label>
                        <select
                          value={cabinClass}
                          onChange={(e) => setCabinClass(e.target.value as any)}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        >
                          <option value="Economy">Economy (Standard)</option>
                          <option value="Business">Business Class (+120%)</option>
                        </select>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] font-black uppercase text-gray-500">Travelers / Persons</label>
                          <span className="text-[10px] font-bold text-brand">Changes Total Money</span>
                        </div>
                        <div className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5">
                          <button
                            type="button"
                            onClick={() => setPassengerCount(Math.max(1, passengerCount - 1))}
                            className="w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-800 font-black text-sm hover:bg-gray-100 flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Decrease person (reduces total money)"
                          >
                            -
                          </button>
                          <div className="text-center px-2">
                            <span className="text-xs font-black text-gray-900 block">{passengerCount} Person{passengerCount > 1 ? 's' : ''}</span>
                            <span className="text-[9px] text-gray-500 font-semibold">{passengerCount} Seat{passengerCount > 1 ? 's' : ''} reserved</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setPassengerCount(Math.min(9, passengerCount + 1))}
                            className="w-8 h-8 rounded-lg bg-brand text-white font-black text-sm hover:bg-brand-dark flex items-center justify-center cursor-pointer shadow-2xs active:scale-95"
                            title="Increase person (increases total money)"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">Primary Passenger Name</label>
                        <input
                          type="text"
                          required
                          value={passengerName}
                          onChange={(e) => setPassengerName(e.target.value)}
                          placeholder="e.g. John Doe"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase text-gray-500 block mb-1">E-Ticket Delivery Email</label>
                        <input
                          type="email"
                          required
                          value={passengerEmail}
                          onChange={(e) => setPassengerEmail(e.target.value)}
                          placeholder="e.g. traveler@mail.com"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold text-gray-800"
                        />
                      </div>
                    </div>

                    {/* Price Breakdown in Active Currency */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2">
                      <div className="flex justify-between text-gray-600">
                        <span>Base Fare ({passengerCount} × {convertUsd(selectedFlight.priceUsd).primaryFormatted})</span>
                        <span className="font-bold text-gray-900">
                          {convertUsd(calculateTotal(selectedFlight.priceUsd).subtotal).primaryFormatted}
                        </span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>Aviation Taxes & Security (12%)</span>
                        <span className="font-bold text-gray-900">
                          {convertUsd(calculateTotal(selectedFlight.priceUsd).taxes).primaryFormatted}
                        </span>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between text-sm font-black text-gray-900">
                        <span>Total Payable Amount</span>
                        <div className="text-right">
                          <span className="text-brand text-base block">
                            {convertUsd(calculateTotal(selectedFlight.priceUsd).total).primaryFormatted}
                          </span>
                          <span className="text-[11px] text-gray-500 font-bold block">
                            ({convertUsd(calculateTotal(selectedFlight.priceUsd).total).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-brand hover:bg-brand-dark text-white font-black py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                    >
                      <ShieldCheck size={18} />
                      <span>CONFIRM & PAY ({convertUsd(calculateTotal(selectedFlight.priceUsd).total).primaryFormatted})</span>
                    </button>
                  </form>
                ) : (
                  /* Confirmed Boarding Pass Ticket */
                  <div className="text-center py-4 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle2 size={32} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-gray-900">E-Ticket Confirmed & Issued!</h4>
                      <p className="text-gray-500 text-xs mt-1">
                        Boarding pass details sent to <strong>{bookingConfirmed.passengerEmail}</strong>
                      </p>
                    </div>

                    {/* Ticket Voucher Card */}
                    <div className="bg-white border-2 border-dashed border-gray-300 rounded-2xl p-5 text-left space-y-3 shadow-inner">
                      <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                        <div>
                          <span className="text-[10px] font-black uppercase tracking-wider text-brand">TRIPVERSE BOARDING PASS</span>
                          <h5 className="font-black text-gray-800">{bookingConfirmed.flight.airline}</h5>
                        </div>
                        <span className="bg-blue-50 text-brand px-2 py-1 rounded text-xs font-black">
                          {bookingConfirmed.ticketNo}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Passenger</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.passengerName}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Route</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.flight.from} ➔ {bookingConfirmed.flight.to}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Flight / Aircraft</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.flight.flightNo} • {bookingConfirmed.flight.aircraft}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-bold">Class / Passengers</span>
                          <span className="font-bold text-gray-900">{bookingConfirmed.cabinClass} ({bookingConfirmed.passengerCount})</span>
                        </div>
                      </div>
                      <div className="border-t border-gray-200 pt-2 flex justify-between items-center text-xs">
                        <span className="font-bold text-gray-500">Amount Paid</span>
                        <div className="text-right">
                          <span className="font-black text-brand text-sm block">
                            {convertUsd(bookingConfirmed.totalUsd).primaryFormatted}
                          </span>
                          <span className="text-[10px] font-bold text-gray-500">
                            ({convertUsd(bookingConfirmed.totalUsd).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedFlight(null)}
                      className="w-full bg-gray-900 text-white font-black py-3 rounded-xl hover:bg-black transition-all cursor-pointer text-xs"
                    >
                      Close & Return to Flights
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
