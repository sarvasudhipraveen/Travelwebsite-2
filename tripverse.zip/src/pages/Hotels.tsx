import React, { useState, useMemo } from 'react';
import { 
  Star, 
  MapPin, 
  Wifi, 
  Coffee, 
  Wind, 
  CreditCard, 
  ChevronRight, 
  Users, 
  Calendar, 
  Bed, 
  Check, 
  X, 
  ShieldCheck, 
  Sparkles, 
  ThumbsUp, 
  Plus, 
  Minus, 
  MessageSquare, 
  Search, 
  SlidersHorizontal, 
  CheckCircle2, 
  Printer, 
  ArrowRight,
  Info,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { formatDualPrice, cn } from '../lib/utils';

interface RoomType {
  id: string;
  name: string;
  pricePerNight: number;
  bedType: string;
  maxPersons: number;
  sqft: number;
  amenities: string[];
  image: string;
  description: string;
}

interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  stayDetails: string;
  title: string;
  comment: string;
  helpfulCount: number;
  isVerified: boolean;
}

interface Hotel {
  id: number;
  name: string;
  location: string;
  city: string;
  rating: number;
  reviewsCount: number;
  basePricePerNight: number;
  image: string;
  gallery: string[];
  description: string;
  categoryRatings: {
    cleanliness: number;
    service: number;
    location: number;
    comfort: number;
    value: number;
  };
  amenities: string[];
  rooms: RoomType[];
  reviews: Review[];
}

const initialHotels: Hotel[] = [
  {
    id: 1,
    name: 'Grand Hyatt Bali Resort & Spa',
    location: 'Kawasan Wisata Nusa Dua BTDC, Bali, Indonesia',
    city: 'Bali',
    rating: 4.9,
    reviewsCount: 1240,
    basePricePerNight: 220,
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Set on the pristine white sands of Nusa Dua, Grand Hyatt Bali offers a blend of traditional Balinese architecture and modern five-star luxury with 5 outdoor swimming pools, full-service Kriya Spa, and 8 beachfront dining options.',
    categoryRatings: {
      cleanliness: 4.9,
      service: 4.8,
      location: 5.0,
      comfort: 4.9,
      value: 4.7
    },
    amenities: ['Private Beachfront', '5 Lagoon Pools', 'Free High-Speed WiFi', 'Breakfast Included', 'Kriya Luxury Spa', 'Kids Club & Activity Center', 'Fitness Studio'],
    rooms: [
      {
        id: 'r1',
        name: 'Deluxe Tropical King Room',
        pricePerNight: 220,
        bedType: '1 King Bed',
        maxPersons: 2,
        sqft: 490,
        amenities: ['Garden View Balcony', 'Marble Bathtub', 'High-Speed WiFi', 'Complimentary Breakfast', 'Mini Bar'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80',
        description: 'Spacious Balinese-inspired room overlooking lush botanical gardens with private teakwood balcony.'
      },
      {
        id: 'r2',
        name: 'Ocean View Grand Suite',
        pricePerNight: 340,
        bedType: '1 King Bed + Daybed',
        maxPersons: 3,
        sqft: 750,
        amenities: ['Direct Ocean View', 'Separate Living Area', 'Free Lounge Access', 'Espresso Machine', 'Luxury Robes'],
        image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
        description: 'Spectacular 180° views of the Indian Ocean with separate entertaining lounge and evening cocktails.'
      },
      {
        id: 'r3',
        name: 'Presidential Beachfront Pool Villa',
        pricePerNight: 580,
        bedType: '2 King Beds',
        maxPersons: 4,
        sqft: 1400,
        amenities: ['Private Plunge Pool', 'Personal 24/7 Butler', 'Direct Beach Access', 'Complimentary Champagne', 'Chef Breakfast'],
        image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=600&q=80',
        description: 'Exclusive beachfront sanctuary featuring private infinity pool, outdoor dining pavilion, and dedicated butler.'
      }
    ],
    reviews: [
      {
        id: 'rev1',
        author: 'Sarah Jenkins',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop',
        rating: 5,
        date: '2 weeks ago',
        stayDetails: 'Stayed 1 night with 2 persons • Deluxe King',
        title: 'Breathtaking 1 night getaway in paradise!',
        comment: 'We booked 1 night for our anniversary and it exceeded every expectation. The room cost was worth every penny — the ocean breeze, the impeccable Balinese staff, and the breakfast buffet were unmatched. Will definitely return!',
        helpfulCount: 28,
        isVerified: true
      },
      {
        id: 'rev2',
        author: 'Dr. Rajesh Sharma',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop',
        rating: 4.8,
        date: '1 month ago',
        stayDetails: 'Stayed 2 nights with 3 persons • Ocean Suite',
        title: 'Ideal for families. Room cost was very transparent.',
        comment: 'Great transparent pricing for 3 persons. The room was expansive, cleanliness was a solid 5/5, and the pool facilities kept the kids thrilled all day.',
        helpfulCount: 19,
        isVerified: true
      },
      {
        id: 'rev3',
        author: 'Emily Thorne',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop',
        rating: 5,
        date: '3 weeks ago',
        stayDetails: 'Stayed 1 night with 1 person • Deluxe King',
        title: 'Top customer rating well deserved!',
        comment: 'Smooth check-in, pristine pools, and the room was whisper quiet. Highly recommend booking direct on TripVerse.',
        helpfulCount: 14,
        isVerified: true
      }
    ]
  },
  {
    id: 2,
    name: 'Burj Al Arab Jumeirah',
    location: 'Jumeirah Beach Road, Dubai, United Arab Emirates',
    city: 'Dubai',
    rating: 5.0,
    reviewsCount: 850,
    basePricePerNight: 1450,
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Repeatedly voted the worlds most luxurious hotel, Burj Al Arab stands on its own island with duplex suites, 9 signature world-class restaurants, and private butler service for every guest.',
    categoryRatings: {
      cleanliness: 5.0,
      service: 5.0,
      location: 5.0,
      comfort: 5.0,
      value: 4.8
    },
    amenities: ['Private Beach & Cabanas', 'Helipad Access', '24k Gold Accents', 'Rolls-Royce Chauffeur', 'Talise Spa', 'Infinity Terrace Pool'],
    rooms: [
      {
        id: 'r21',
        name: 'Deluxe One-Bedroom Palm Suite',
        pricePerNight: 1450,
        bedType: '1 King Bed',
        maxPersons: 2,
        sqft: 1800,
        amenities: ['Duplex 2-Story Layout', 'Hermès Toiletries', 'Whirlpool Bathtub', '24/7 Butler Service', 'Panoramic Gulf Views'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80',
        description: 'Two-story luxury suite with floor-to-ceiling panoramic views of the Arabian Gulf and personalized butler service.'
      },
      {
        id: 'r22',
        name: 'Sky View Two-Bedroom Royal Suite',
        pricePerNight: 2850,
        bedType: '2 King Beds',
        maxPersons: 4,
        sqft: 3200,
        amenities: ['Rotating Canopy Bed', 'Private Cinema', 'Library & Lounge', 'Private Elevator', 'Unlimited Spa Access'],
        image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
        description: 'Ultra-luxurious royal residence on the 25th floor decorated in rich velvets, Carrara marble, and 24-carat gold.'
      }
    ],
    reviews: [
      {
        id: 'b-rev1',
        author: 'Sheikh Tariq Al-Mansoor',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop',
        rating: 5,
        date: '1 week ago',
        stayDetails: 'Stayed 1 night with 2 persons • Deluxe Suite',
        title: 'The pinnacle of global hospitality',
        comment: 'Every second felt like royalty. For 1 night, experiencing the 2-story suite, personal butler, and helicopter arrival is second to none.',
        helpfulCount: 42,
        isVerified: true
      },
      {
        id: 'b-rev2',
        author: 'Michael Chang',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop',
        rating: 5,
        date: '3 weeks ago',
        stayDetails: 'Stayed 1 night with 2 persons • Palm Suite',
        title: 'Flawless 5.0 rating is 100% accurate',
        comment: 'The Hermes amenities, custom pillow menu, and gold cappuccino made our 1 night stay memorable for a lifetime.',
        helpfulCount: 31,
        isVerified: true
      }
    ]
  },
  {
    id: 3,
    name: 'The Ritz-Carlton Place Vendôme',
    location: '15 Place Vendôme, 75001 Paris, France',
    city: 'Paris',
    rating: 4.8,
    reviewsCount: 3200,
    basePricePerNight: 350,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Nestled on the iconic Place Vendôme, this storied palace exudes quintessential French elegance with neoclassical salons, Michelin-starred cuisine by Chef Arnaud Faye, and Chanel Spa.',
    categoryRatings: {
      cleanliness: 4.9,
      service: 4.8,
      location: 5.0,
      comfort: 4.8,
      value: 4.6
    },
    amenities: ['Chanel Wellness Spa', 'Michelin-Starred Dining', 'Indoor Heated Pool', 'Private Courtyard Garden', 'Complimentary French Breakfast', 'Concierge Clefs d\'Or'],
    rooms: [
      {
        id: 'r31',
        name: 'Superior Parisian King Room',
        pricePerNight: 350,
        bedType: '1 Queen Bed',
        maxPersons: 2,
        sqft: 430,
        amenities: ['Garden View', 'Italian Marble Bathroom', 'Fresh Flowers Daily', 'Complimentary Champagne on Arrival'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80',
        description: 'Chic Parisian aesthetics with gilded woodwork, antique writing desk, and quiet courtyard view.'
      },
      {
        id: 'r32',
        name: 'Prestige Vendôme Balcony Suite',
        pricePerNight: 520,
        bedType: '1 King Bed + Sofa Bed',
        maxPersons: 3,
        sqft: 680,
        amenities: ['Private Balcony over Place Vendôme', 'Separate Dressing Room', 'Steam Shower', 'Butler Call Button'],
        image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
        description: 'Elegant suite with private wrought-iron balcony opening directly to Place Vendôme and high ceilings.'
      }
    ],
    reviews: [
      {
        id: 'r-rev1',
        author: 'Chloe Delacroix',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop',
        rating: 5,
        date: '5 days ago',
        stayDetails: 'Stayed 1 night with 2 persons • Superior Room',
        title: 'Pure Parisian romance and five-star perfection',
        comment: 'We stayed 1 night and felt so pampered. The room cost included afternoon tea in the salon and fresh croissants delivered to our bed.',
        helpfulCount: 22,
        isVerified: true
      }
    ]
  },
  {
    id: 4,
    name: 'Taj Lake Palace Historical Resort',
    location: 'Lake Pichola, Udaipur, Rajasthan, India',
    city: 'Udaipur',
    rating: 4.9,
    reviewsCount: 540,
    basePricePerNight: 480,
    image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    ],
    description: 'Floating like a white marble jewel in the middle of Lake Pichola, this 18th-century palace was built as a royal summer retreat. Reached only by private boat, it offers legendary Rajasthani hospitality.',
    categoryRatings: {
      cleanliness: 4.9,
      service: 5.0,
      location: 5.0,
      comfort: 4.9,
      value: 4.8
    },
    amenities: ['Private Royal Boat Transfers', 'Jiva Spa Boat', 'Historic Palace Courtyards', 'Royal Welcome Ceremony', 'Rooftop Dining over Lake'],
    rooms: [
      {
        id: 'r41',
        name: 'Palace Heritage Lake View Room',
        pricePerNight: 480,
        bedType: '1 King Bed',
        maxPersons: 2,
        sqft: 520,
        amenities: ['Unobstructed Lake Pichola Views', 'Custom Silk Furnishings', 'Royal Bath with Forest Essentials', 'Historic Jharokha Window'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80',
        description: 'Authentic royal quarters with marble arches, original frescoes, and mesmerizing water views.'
      },
      {
        id: 'r42',
        name: 'Grand Royal Maharana Suite',
        pricePerNight: 790,
        bedType: '1 King Bed + Rollaway Bed',
        maxPersons: 3,
        sqft: 950,
        amenities: ['Lake Pavilion Balcony', 'Vintage Swing', 'Personal Royal Escort', 'Private Sunset Cruise Included'],
        image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
        description: 'Spectacular historic suite once inhabited by the royalty of Mewar with private open-air lake terrace.'
      }
    ],
    reviews: [
      {
        id: 't-rev1',
        author: 'Vikramaditya Rathore',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop',
        rating: 5,
        date: '2 weeks ago',
        stayDetails: 'Stayed 1 night with 2 persons • Heritage Lake View',
        title: 'Unbelievable royal experience on water',
        comment: 'Arriving by private boat with rose petals shower set the tone. The room cost was 100% justified. Dining under the stars on Lake Pichola is unmissable.',
        helpfulCount: 35,
        isVerified: true
      }
    ]
  }
];

export default function Hotels() {
  const { user } = useAuth();
  const { currency, convertUsd } = useCurrency();

  // Search & Filter States
  const [searchCity, setSearchCity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [minRating, setMinRating] = useState<number>(0);
  const [budgetFilter, setBudgetFilter] = useState<'All' | 'under150' | 'under300' | 'luxury'>('All');
  const [amenityFilter, setAmenityFilter] = useState<'All' | 'pool' | 'breakfast' | 'spa'>('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'priceDesc' | 'ratingDesc'>('recommended');

  // Interactive Selected Hotel for Detail & Booking
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);

  // Booking Calculator Parameters
  const [nights, setNights] = useState<number>(1); // Default to 1 night as requested
  const [persons, setPersons] = useState<number>(2); // Default 2 persons
  const [roomsCount, setRoomsCount] = useState<number>(1);
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');
  const [checkInDate, setCheckInDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });

  // Modal active tab: 'booking' or 'reviews'
  const [modalTab, setModalTab] = useState<'booking' | 'reviews'>('booking');

  // Customer Review Submission Form State
  const [userRatingInput, setUserRatingInput] = useState<number>(5);
  const [reviewAuthor, setReviewAuthor] = useState(user?.displayName || '');
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [reviewSuccessMsg, setReviewSuccessMsg] = useState(false);

  // Hotel data in state (so newly posted reviews dynamically update scores & list)
  const [hotelsList, setHotelsList] = useState<Hotel[]>(initialHotels);

  // Booking Form Details
  const [guestName, setGuestName] = useState(user?.displayName || '');
  const [guestEmail, setGuestEmail] = useState(user?.email || '');
  const [guestPhone, setGuestPhone] = useState(user?.phoneNumber || '');
  const [specialRequests, setSpecialRequests] = useState('High floor room with quiet view');
  const [isBookingSubmitting, setIsBookingSubmitting] = useState(false);
  const [bookingConfirmedData, setBookingConfirmedData] = useState<any | null>(null);

  // When opening a hotel modal
  const handleSelectHotel = (hotel: Hotel, initialTab: 'booking' | 'reviews' = 'booking') => {
    setSelectedHotel(hotel);
    setSelectedRoomId(hotel.rooms[0]?.id || '');
    setModalTab(initialTab);
    setBookingConfirmedData(null);
    setReviewSuccessMsg(false);
    if (user?.displayName && !guestName) setGuestName(user.displayName);
    if (user?.email && !guestEmail) setGuestEmail(user.email);
    if (user?.phoneNumber && !guestPhone) setGuestPhone(user.phoneNumber);
  };

  // Find currently selected room in modal
  const currentRoom = useMemo(() => {
    if (!selectedHotel) return null;
    return selectedHotel.rooms.find(r => r.id === selectedRoomId) || selectedHotel.rooms[0];
  }, [selectedHotel, selectedRoomId]);

  // Compute Check-out Date based on Check-in Date + nights
  const checkOutDate = useMemo(() => {
    const date = new Date(checkInDate);
    date.setDate(date.getDate() + (nights || 1));
    return date.toISOString().split('T')[0];
  }, [checkInDate, nights]);

  // Dynamic Price Breakdown Calculations (Requested: 1 night with how many persons and room costs)
  const priceCalculations = useMemo(() => {
    if (!currentRoom) return { roomCostPerNight: 0, roomSubtotal: 0, extraPersonFee: 0, extraPersonsCount: 0, taxes: 0, discount: 0, total: 0 };
    
    const roomCostPerNight = currentRoom.pricePerNight;
    // Base room covers 1 guest. Each additional person adds guest hospitality, breakfast & amenities ($35/night/person)
    const extraPersonsCount = Math.max(0, persons - 1);
    const extraPersonFee = extraPersonsCount * 35 * nights;
    
    const roomSubtotal = roomCostPerNight * nights * roomsCount;
    const grossTotal = roomSubtotal + extraPersonFee;
    const discount = Math.round(grossTotal * 0.10); // 10% TripVerse Member promo
    const taxes = Math.round((grossTotal - discount) * 0.12); // 12% luxury hotel tax & service charge
    const total = (grossTotal - discount) + taxes;

    return {
      roomCostPerNight,
      roomSubtotal,
      extraPersonFee,
      extraPersonsCount,
      taxes,
      discount,
      total
    };
  }, [currentRoom, nights, persons, roomsCount]);

  // Filtered hotels
  const filteredHotels = useMemo(() => {
    return hotelsList.filter(hotel => {
      const matchCity = searchCity === 'All' || hotel.city.toLowerCase() === searchCity.toLowerCase();
      const matchQuery = !searchQuery || 
        hotel.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        hotel.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchRating = hotel.rating >= minRating;

      let matchBudget = true;
      if (budgetFilter === 'under150') matchBudget = hotel.basePricePerNight <= 150;
      else if (budgetFilter === 'under300') matchBudget = hotel.basePricePerNight <= 300;
      else if (budgetFilter === 'luxury') matchBudget = hotel.basePricePerNight >= 300;

      let matchAmenity = true;
      if (amenityFilter === 'pool') matchAmenity = hotel.amenities.some(a => a.toLowerCase().includes('pool'));
      else if (amenityFilter === 'breakfast') matchAmenity = hotel.amenities.some(a => a.toLowerCase().includes('breakfast'));
      else if (amenityFilter === 'spa') matchAmenity = hotel.amenities.some(a => a.toLowerCase().includes('spa') || a.toLowerCase().includes('wellness'));

      return matchCity && matchQuery && matchRating && matchBudget && matchAmenity;
    }).sort((a, b) => {
      if (sortBy === 'priceAsc') return a.basePricePerNight - b.basePricePerNight;
      if (sortBy === 'priceDesc') return b.basePricePerNight - a.basePricePerNight;
      if (sortBy === 'ratingDesc') return b.rating - a.rating;
      return 0; // recommended
    });
  }, [hotelsList, searchCity, searchQuery, minRating, budgetFilter, amenityFilter, sortBy]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (searchCity !== 'All') count++;
    if (minRating > 0) count++;
    if (budgetFilter !== 'All') count++;
    if (amenityFilter !== 'All') count++;
    if (sortBy !== 'recommended') count++;
    return count;
  }, [searchQuery, searchCity, minRating, budgetFilter, amenityFilter, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSearchCity('All');
    setMinRating(0);
    setBudgetFilter('All');
    setAmenityFilter('All');
    setSortBy('recommended');
  };

  // Handle Review Submission
  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHotel || !reviewText.trim()) return;

    const newReview: Review = {
      id: 'rev_' + Date.now(),
      author: reviewAuthor.trim() || 'Verified Guest',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${Date.now()}`,
      rating: userRatingInput,
      date: 'Just now',
      stayDetails: `Stayed ${nights} night${nights > 1 ? 's' : ''} with ${persons} person${persons > 1 ? 's' : ''} • ${currentRoom?.name}`,
      title: reviewTitle.trim() || 'Outstanding Hotel Experience!',
      comment: reviewText.trim(),
      helpfulCount: 1,
      isVerified: true
    };

    setHotelsList(prevList => {
      return prevList.map(h => {
        if (h.id === selectedHotel.id) {
          const updatedReviews = [newReview, ...h.reviews];
          // Recalculate average rating
          const newAvgRating = +(updatedReviews.reduce((acc, r) => acc + r.rating, 0) / updatedReviews.length).toFixed(1);
          const updatedHotel = {
            ...h,
            rating: newAvgRating,
            reviewsCount: h.reviewsCount + 1,
            reviews: updatedReviews
          };
          setSelectedHotel(updatedHotel);
          return updatedHotel;
        }
        return h;
      });
    });

    setReviewText('');
    setReviewTitle('');
    setReviewSuccessMsg(true);
    setTimeout(() => setReviewSuccessMsg(false), 4000);
  };

  // Handle Hotel Booking Confirmation
  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHotel || !currentRoom) return;

    setIsBookingSubmitting(true);
    const bookingId = 'TV-HTL-' + Math.floor(100000 + Math.random() * 900000);
    const bookingRecord = {
      bookingId,
      hotelId: selectedHotel.id,
      hotelName: selectedHotel.name,
      hotelLocation: selectedHotel.location,
      roomName: currentRoom.name,
      roomCostPerNight: currentRoom.pricePerNight,
      nights,
      persons,
      roomsCount,
      checkInDate,
      checkOutDate,
      breakdown: priceCalculations,
      guestName: guestName.trim() || 'Guest Traveler',
      guestEmail: guestEmail.trim() || 'guest@tripverse.app',
      guestPhone: guestPhone.trim() || '+1 555-0192',
      specialRequests,
      status: 'confirmed',
      bookedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
    };

    try {
      // If user is authenticated, sync to Firestore
      if (user?.uid) {
        await setDoc(doc(db, 'bookings', bookingId), {
          userId: user.uid,
          type: 'hotel',
          status: 'confirmed',
          amount: priceCalculations.total,
          hotelName: selectedHotel.name,
          roomType: currentRoom.name,
          nights,
          persons,
          checkIn: checkInDate,
          checkOut: checkOutDate,
          guestName: bookingRecord.guestName,
          guestEmail: bookingRecord.guestEmail,
          createdAt: new Date().toISOString()
        });
      }
    } catch (err) {
      console.warn('Firestore booking sync notice:', err);
    }

    // Save in local storage
    try {
      const existing = JSON.parse(localStorage.getItem('tripverse_hotel_bookings') || '[]');
      localStorage.setItem('tripverse_hotel_bookings', JSON.stringify([bookingRecord, ...existing]));
    } catch {}

    setIsBookingSubmitting(false);
    setBookingConfirmedData(bookingRecord);
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-16 relative overflow-hidden">
      {/* Top Hero Banner with rich tourism ambient lighting */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        {/* Multi-Color Ambient Orbs */}
        <div className="absolute -top-24 -right-20 w-[420px] h-[420px] bg-cyan-400/25 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-1/3 -left-20 w-[380px] h-[380px] bg-amber-500/20 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute -bottom-16 right-1/4 w-[360px] h-[360px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest mb-3">
                <Sparkles size={14} /> Luxury Stays & Resort Bookings
              </span>
              <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white">
                Find & Book Exclusive Hotels
              </h1>
              <p className="text-blue-100 text-sm md:text-base font-medium mt-2 max-w-2xl">
                Compare verified customer ratings, transparent room costs for 1 night and multiple guests, and instant room confirmation.
              </p>
            </div>

            {/* Quick Stats Pill */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl flex items-center gap-6">
              <div>
                <div className="text-2xl font-black text-white">4.9★</div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-blue-200">Customer Rating</div>
              </div>
              <div className="h-8 w-px bg-white/20"></div>
              <div>
                <div className="text-2xl font-black text-white">100%</div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-blue-200">Verified Reviews</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="max-w-7xl mx-auto px-6 md:px-10 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl border border-[#E0E4E9] p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
            {/* Search by Name / Location */}
            <div className="relative">
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Destination / Hotel Name
              </label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
                <Search size={16} className="text-gray-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Bali, Dubai, Paris..."
                  className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
                />
              </div>
            </div>

            {/* City Quick Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Destination Filter
              </label>
              <select
                value={searchCity}
                onChange={(e) => setSearchCity(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">🌍 All Destinations</option>
                <option value="Bali">🇮🇩 Bali, Indonesia</option>
                <option value="Dubai">🇦🇪 Dubai, UAE</option>
                <option value="Paris">🇫🇷 Paris, France</option>
                <option value="Udaipur">🇮🇳 Udaipur, India</option>
              </select>
            </div>

            {/* Rating Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Customer Rating
              </label>
              <select
                value={minRating}
                onChange={(e) => setMinRating(Number(e.target.value))}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value={0}>All Ratings</option>
                <option value={4.8}>⭐ 4.8+ Superb</option>
                <option value={4.9}>⭐ 4.9+ Exceptional</option>
                <option value={5.0}>⭐ 5.0 Perfect</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Sort Pricing & Rating
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="recommended">Recommended Picks</option>
                <option value="ratingDesc">Highest Customer Rating</option>
                <option value="priceAsc">Room Cost: Low to High</option>
                <option value="priceDesc">Room Cost: High to Low</option>
              </select>
            </div>
          </div>

          {/* Secondary Filter Chips Row: Budget & Amenities */}
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 mr-1">
                Nightly Budget:
              </span>
              <button
                type="button"
                onClick={() => setBudgetFilter('All')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'All' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                All Prices
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under150')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under150' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                &lt; $150 / ₹12,600
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under300')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under300' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                &lt; $300 / ₹25,200
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('luxury')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'luxury' ? "bg-purple-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Luxury &gt; $300 / ₹25,200
              </button>

              <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 ml-2 mr-1">
                Feature:
              </span>
              <button
                type="button"
                onClick={() => setAmenityFilter('All')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  amenityFilter === 'All' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                All Features
              </button>
              <button
                type="button"
                onClick={() => setAmenityFilter('pool')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  amenityFilter === 'pool' ? "bg-cyan-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                🏊 Swimming Pool
              </button>
              <button
                type="button"
                onClick={() => setAmenityFilter('breakfast')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  amenityFilter === 'breakfast' ? "bg-amber-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                🍳 Free Breakfast
              </button>
              <button
                type="button"
                onClick={() => setAmenityFilter('spa')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  amenityFilter === 'spa' ? "bg-emerald-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                💆 Wellness Spa
              </button>
            </div>

            {activeFiltersCount > 0 && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw size={13} />
                Reset Filters ({activeFiltersCount})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Hotel Cards Listing */}
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-black text-brand bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200 uppercase tracking-widest inline-flex items-center gap-1.5 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></span>
                Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
              </span>
            </div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Featured Hotels & Resorts ({filteredHotels.length})
            </h2>
            <p className="text-xs md:text-sm text-text-secondary font-medium">
              Click <strong className="text-brand">"Select Hotel & Book Room"</strong> or <strong className="text-brand">"Customer Reviews"</strong> to configure persons, nights & room costs.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredHotels.map((hotel) => (
            <motion.div 
              whileHover={{ y: -6 }}
              key={hotel.id} 
              className="bg-white rounded-3xl border border-[#E0E4E9] overflow-hidden group shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
            >
              {/* Image & Price Overlay */}
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={hotel.image} 
                  alt={hotel.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent"></div>
                
                {/* Top Badges */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <span className="bg-brand text-white px-3 py-1 rounded-full text-xs font-black shadow-md flex items-center gap-1">
                    <Sparkles size={12} /> Best Seller
                  </span>
                  <button 
                    onClick={() => handleSelectHotel(hotel, 'reviews')}
                    className="bg-black/60 hover:bg-black/80 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-white/20 transition-all cursor-pointer"
                  >
                    <MessageSquare size={13} className="text-yellow-400" />
                    <span>{hotel.reviewsCount} Reviews</span>
                  </button>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
                  <div className="pr-4">
                    {/* Stars and Rating */}
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            size={14} 
                            className={i < Math.floor(hotel.rating) ? "fill-yellow-400 text-yellow-400" : "fill-gray-400 text-gray-400"} 
                          />
                        ))}
                      </div>
                      <span className="bg-yellow-400 text-black font-black text-xs px-2 py-0.5 rounded-md">
                        {hotel.rating} / 5
                      </span>
                      <span className="text-white/90 text-xs font-bold">
                        ({hotel.reviewsCount} ratings)
                      </span>
                    </div>

                    <h3 className="text-xl md:text-2xl font-black text-white leading-tight drop-shadow-sm">
                      {hotel.name}
                    </h3>
                    <p className="text-white/80 text-xs font-semibold flex items-center gap-1 mt-1">
                      <MapPin size={13} className="text-brand shrink-0" /> {hotel.location}
                    </p>
                  </div>

                  {/* 1 Night Price Badge */}
                  <div className="bg-white/95 backdrop-blur-md p-3 rounded-2xl text-center min-w-[110px] shadow-lg shrink-0">
                    <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest block">
                      From
                    </span>
                    <p className="text-brand font-black text-xl leading-none my-0.5">
                      {convertUsd(hotel.basePricePerNight).primaryFormatted}
                    </p>
                    <p className="text-xs font-bold text-gray-500">
                      ({convertUsd(hotel.basePricePerNight).secondaryFormatted})
                    </p>
                    <p className="text-[10px] font-bold text-gray-600 uppercase mt-0.5">
                      1 night stay
                    </p>
                  </div>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs text-text-secondary line-clamp-2 mb-4 leading-relaxed font-medium">
                    {hotel.description}
                  </p>

                  {/* Amenities Icons */}
                  <div className="flex flex-wrap items-center gap-2 mb-6">
                    <span className="inline-flex items-center gap-1 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-lg">
                      <Wifi size={13} className="text-brand" /> Free WiFi
                    </span>
                    <span className="inline-flex items-center gap-1 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-lg">
                      <Coffee size={13} className="text-brand" /> Breakfast
                    </span>
                    <span className="inline-flex items-center gap-1 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-lg">
                      <Wind size={13} className="text-brand" /> AC Suites
                    </span>
                    <span className="inline-flex items-center gap-1 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-lg">
                      <Users size={13} className="text-brand" /> 1-4 Persons
                    </span>
                  </div>

                  {/* Price Preview for 1 night & persons */}
                  <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-3 mb-6 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Info size={16} className="text-brand shrink-0" />
                      <span>Rate for <strong>1 Night (2 Guests)</strong>:</span>
                    </div>
                    <span className="font-black text-brand text-sm">
                      {convertUsd(hotel.basePricePerNight).combined}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-3 border-t border-gray-100">
                  <button 
                    onClick={() => handleSelectHotel(hotel, 'reviews')}
                    className="w-full sm:w-1/2 flex items-center justify-center gap-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-800 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <Star size={14} className="text-yellow-500 fill-yellow-500" />
                    <span>Customer Reviews ({hotel.reviewsCount})</span>
                  </button>

                  <button 
                    onClick={() => handleSelectHotel(hotel, 'booking')}
                    className="w-full sm:w-1/2 flex items-center justify-center gap-2 bg-brand hover:bg-brand-dark text-white py-3 rounded-xl text-xs font-black shadow-md hover:shadow-lg transition-all cursor-pointer"
                  >
                    <span>SELECT HOTEL & BOOK</span>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* ================= MODAL: HOTEL BOOKING, 1 NIGHT CALCULATION, ROOM COSTS, CUSTOMER RATINGS ================= */}
      <AnimatePresence>
        {selectedHotel && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-4xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              {/* Close Button */}
              <button 
                onClick={() => setSelectedHotel(null)}
                className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-md transition-all cursor-pointer"
              >
                <X size={20} />
              </button>

              {/* Modal Top Header with Hotel Image Banner */}
              <div className="relative h-48 sm:h-56 shrink-0 overflow-hidden">
                <img 
                  src={selectedHotel.image} 
                  alt={selectedHotel.name} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
                <div className="absolute bottom-4 left-6 right-16 text-white">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-yellow-400 text-black text-xs font-black px-2 py-0.5 rounded">
                      {selectedHotel.rating} / 5.0
                    </span>
                    <span className="text-white/90 text-xs font-bold">
                      Customer Rating ({selectedHotel.reviewsCount} reviews)
                    </span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black leading-tight">{selectedHotel.name}</h2>
                  <p className="text-white/80 text-xs font-medium flex items-center gap-1 mt-0.5">
                    <MapPin size={13} className="text-brand" /> {selectedHotel.location}
                  </p>
                </div>
              </div>

              {/* Modal Navigation Tabs: 'booking' or 'reviews' */}
              <div className="flex border-b border-gray-200 bg-gray-50 px-6 shrink-0">
                <button
                  type="button"
                  onClick={() => setModalTab('booking')}
                  className={`py-3.5 px-4 text-xs md:text-sm font-black border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                    modalTab === 'booking'
                      ? 'border-brand text-brand bg-white'
                      : 'border-transparent text-text-secondary hover:text-gray-900'
                  }`}
                >
                  <CreditCard size={16} />
                  <span>Configure Persons, Nights & Room Booking</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModalTab('reviews')}
                  className={`py-3.5 px-4 text-xs md:text-sm font-black border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                    modalTab === 'reviews'
                      ? 'border-brand text-brand bg-white'
                      : 'border-transparent text-text-secondary hover:text-gray-900'
                  }`}
                >
                  <Star size={16} className="text-yellow-500 fill-yellow-500" />
                  <span>Customer Ratings & Reviews ({selectedHotel.reviews.length})</span>
                </button>
              </div>

              {/* Modal Body Container */}
              <div className="p-6 overflow-y-auto flex-1">
                {/* ================= TAB 1: BOOKING & 1 NIGHT ROOM COSTS CALCULATOR ================= */}
                {modalTab === 'booking' && !bookingConfirmedData && (
                  <div className="space-y-6">
                    {/* Stay Duration (Nights) & Number of Persons Controls */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 sm:p-5">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-xs font-black uppercase tracking-wider text-gray-900 flex items-center gap-2">
                          <Calendar size={16} className="text-brand" /> Select Nights & Persons
                        </h4>
                        <span className="text-xs font-bold text-brand bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
                          {nights} Night{nights > 1 ? 's' : ''} Stay ({checkInDate} to {checkOutDate})
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {/* Check-in Date */}
                        <div>
                          <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                            Check-in Date
                          </label>
                          <input
                            type="date"
                            value={checkInDate}
                            onChange={(e) => setCheckInDate(e.target.value)}
                            className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>

                        {/* Number of Nights (Defaults to 1 night) */}
                        <div>
                          <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                            Number of Nights
                          </label>
                          <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-2 py-1.5">
                            <button
                              type="button"
                              onClick={() => setNights(Math.max(1, nights - 1))}
                              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 font-bold transition-all cursor-pointer"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="text-sm font-black text-gray-900">
                              {nights} {nights === 1 ? 'Night' : 'Nights'}
                            </span>
                            <button
                              type="button"
                              onClick={() => setNights(nights + 1)}
                              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 font-bold transition-all cursor-pointer"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        </div>

                        {/* Number of Persons */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                              How Many Persons (Guests)
                            </label>
                            <span className="text-[10px] font-bold text-brand">±$35/night per person</span>
                          </div>
                          <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-2 py-1.5">
                            <button
                              type="button"
                              onClick={() => setPersons(Math.max(1, persons - 1))}
                              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 font-bold transition-all cursor-pointer active:scale-95"
                              title="Decrease person (reduces total money)"
                            >
                              <Minus size={14} />
                            </button>
                            <div className="text-center">
                              <span className="text-sm font-black text-gray-900 flex items-center justify-center gap-1">
                                <Users size={14} className="text-brand" /> {persons} {persons === 1 ? 'Guest' : 'Guests'}
                              </span>
                              <span className="text-[9px] text-gray-500 font-medium block">
                                {persons === 1 ? 'Base room covered' : `+${persons - 1} extra guest surcharge`}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setPersons(persons + 1)}
                              className="w-8 h-8 rounded-lg bg-brand text-white hover:bg-brand-dark flex items-center justify-center font-bold transition-all cursor-pointer active:scale-95"
                              title="Increase person (increases total money)"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Room Selection & Individual Room Costs */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-black text-gray-900 uppercase tracking-wider flex items-center gap-2">
                          <Bed size={16} className="text-brand" /> Available Room Options & 1 Night Cost
                        </h4>
                        <span className="text-xs text-text-secondary font-semibold">
                          Click to select a room
                        </span>
                      </div>

                      <div className="space-y-3">
                        {selectedHotel.rooms.map((room) => {
                          const isSelected = room.id === selectedRoomId;
                          return (
                            <div
                              key={room.id}
                              onClick={() => setSelectedRoomId(room.id)}
                              className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                                isSelected
                                  ? 'border-brand bg-blue-50/40 shadow-sm'
                                  : 'border-gray-200 hover:border-gray-300 bg-white'
                              }`}
                            >
                              <div className="flex items-start sm:items-center gap-4">
                                <img
                                  src={room.image}
                                  alt={room.name}
                                  className="w-20 h-20 rounded-xl object-cover shrink-0"
                                />
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h5 className="text-sm font-black text-gray-900">{room.name}</h5>
                                    {isSelected && (
                                      <span className="bg-brand text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                                        <Check size={10} /> Selected
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-text-secondary mt-0.5">{room.description}</p>
                                  <div className="flex flex-wrap items-center gap-2 mt-2 text-[11px] font-bold text-gray-600">
                                    <span>🛏️ {room.bedType}</span>
                                    <span>•</span>
                                    <span>👥 Fits up to {room.maxPersons} persons</span>
                                    <span>•</span>
                                    <span>📐 {room.sqft} sq.ft</span>
                                  </div>
                                </div>
                              </div>

                              {/* Price for 1 Night */}
                              <div className="text-right shrink-0 self-end sm:self-center">
                                <span className="text-[10px] font-bold text-text-secondary uppercase">
                                  Room cost for 1 night
                                </span>
                                <div className="text-lg font-black text-brand leading-tight">
                                  {convertUsd(room.pricePerNight).primaryFormatted}
                                </div>
                                <div className="text-xs font-bold text-gray-500">
                                  ({convertUsd(room.pricePerNight).secondaryFormatted})
                                </div>
                                <span className="text-[10px] text-gray-500 font-medium">
                                  for {persons} guest{persons > 1 ? 's' : ''}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* ITEMIZED PRICE BREAKDOWN CARD (1 Night + Persons + Room Costs) */}
                    <div className="bg-gradient-to-br from-white to-blue-50/50 border border-blue-200 rounded-2xl p-5 shadow-sm">
                      <h4 className="text-xs font-black uppercase tracking-wider text-gray-900 mb-3 flex items-center justify-between">
                        <span>Price & Room Cost Breakdown</span>
                        <span className="text-brand font-bold text-[11px]">
                          {nights} Night{nights > 1 ? 's' : ''} • {persons} Person{persons > 1 ? 's' : ''}
                        </span>
                      </h4>

                      <div className="space-y-2 text-xs font-semibold text-gray-700">
                        <div className="flex justify-between">
                          <span className="text-text-secondary">
                            Room Cost ({currentRoom?.name}) x {nights} night{nights > 1 ? 's' : ''}:
                          </span>
                          <span className="text-gray-900 font-bold">
                            {convertUsd(priceCalculations.roomSubtotal).combined}
                          </span>
                        </div>

                        {priceCalculations.extraPersonsCount > 0 && (
                          <div className="flex justify-between text-orange-600">
                            <span>
                              Additional Guest Surcharge ({priceCalculations.extraPersonsCount} extra person x $35):
                            </span>
                            <span>+{convertUsd(priceCalculations.extraPersonFee).combined}</span>
                          </div>
                        )}

                        <div className="flex justify-between text-green-700">
                          <span>TripVerse Special Discount (10% OFF):</span>
                          <span>-{convertUsd(priceCalculations.discount).combined}</span>
                        </div>

                        <div className="flex justify-between text-text-secondary">
                          <span>Taxes & Hotel Luxury Fees (12%):</span>
                          <span>+{convertUsd(priceCalculations.taxes).combined}</span>
                        </div>

                        <div className="border-t border-gray-200 pt-3 mt-3 flex justify-between items-baseline">
                          <div>
                            <span className="text-sm font-black text-gray-900 block">Total Payable Amount ({currency})</span>
                            <span className="text-[10px] text-gray-500 font-medium">
                              Includes 1 night room cost, all {persons} guests & taxes
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-2xl font-black text-brand leading-none block">
                              {convertUsd(priceCalculations.total).primaryFormatted}
                            </span>
                            <span className="text-xs font-bold text-gray-500">
                              ({convertUsd(priceCalculations.total).secondaryFormatted})
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Guest Information Form & Booking CTA */}
                    <form onSubmit={handleConfirmBooking} className="space-y-4 pt-2">
                      <h4 className="text-xs font-black uppercase tracking-wider text-gray-900">
                        Lead Guest Contact Information
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                            Full Name
                          </label>
                          <input
                            type="text"
                            required
                            value={guestName}
                            onChange={(e) => setGuestName(e.target.value)}
                            placeholder="e.g. John Doe"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                            Email Address
                          </label>
                          <input
                            type="email"
                            required
                            value={guestEmail}
                            onChange={(e) => setGuestEmail(e.target.value)}
                            placeholder="e.g. john@example.com"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                            Phone Number
                          </label>
                          <input
                            type="tel"
                            required
                            value={guestPhone}
                            onChange={(e) => setGuestPhone(e.target.value)}
                            placeholder="+1 555-0192"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isBookingSubmitting}
                        className="w-full bg-brand hover:bg-brand-dark text-white py-4 rounded-2xl font-black text-sm tracking-wide shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {isBookingSubmitting ? (
                          <span>Processing Room Reservation...</span>
                        ) : (
                          <>
                            <ShieldCheck size={18} />
                            <span>CONFIRM HOTEL BOOKING ({convertUsd(priceCalculations.total).primaryFormatted} / {convertUsd(priceCalculations.total).secondaryFormatted})</span>
                            <ArrowRight size={16} />
                          </>
                        )}
                      </button>
                    </form>
                  </div>
                )}

                {/* ================= BOOKING CONFIRMED SUCCESS VOUCHER ================= */}
                {modalTab === 'booking' && bookingConfirmedData && (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-4 sm:p-8 text-center space-y-6"
                  >
                    <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                      <CheckCircle2 size={36} />
                    </div>

                    <div>
                      <span className="bg-green-100 text-green-800 text-xs font-black uppercase px-3 py-1 rounded-full">
                        Booking Confirmed
                      </span>
                      <h3 className="text-2xl font-black text-gray-900 mt-2">
                        You're Heading to {bookingConfirmedData.hotelName}!
                      </h3>
                      <p className="text-xs text-text-secondary font-medium mt-1">
                        Confirmation voucher has been sent to <strong>{bookingConfirmedData.guestEmail}</strong>
                      </p>
                    </div>

                    {/* Voucher Summary Ticket */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6 text-left max-w-lg mx-auto space-y-4 text-xs">
                      <div className="flex justify-between items-center border-b border-gray-200 pb-3">
                        <div>
                          <span className="text-[10px] font-bold text-text-secondary uppercase">Booking Reference</span>
                          <div className="text-base font-black text-brand">{bookingConfirmedData.bookingId}</div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] font-bold text-text-secondary uppercase">Status</span>
                          <div className="text-green-600 font-black">Guaranteed</div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-[10px] font-bold text-text-secondary uppercase">Room & Stay</span>
                          <div className="font-bold text-gray-900">{bookingConfirmedData.roomName}</div>
                          <div className="text-gray-500">{bookingConfirmedData.nights} Night(s) • {bookingConfirmedData.persons} Person(s)</div>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-text-secondary uppercase">Dates</span>
                          <div className="font-bold text-gray-900">{bookingConfirmedData.checkInDate}</div>
                          <div className="text-gray-500">to {bookingConfirmedData.checkOutDate}</div>
                        </div>
                      </div>

                      <div className="border-t border-gray-200 pt-3 flex justify-between items-center">
                        <div>
                          <span className="text-[10px] font-bold text-text-secondary uppercase">Total Amount Paid</span>
                          <div className="text-xl font-black text-gray-900">{convertUsd(bookingConfirmedData.breakdown.total).combined}</div>
                        </div>
                        <button
                          type="button"
                          onClick={() => window.print()}
                          className="flex items-center gap-1.5 bg-white border border-gray-300 hover:bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-700 shadow-2xs cursor-pointer"
                        >
                          <Printer size={14} /> Print Voucher
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => setSelectedHotel(null)}
                        className="bg-brand text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow hover:bg-brand-dark transition-all cursor-pointer"
                      >
                        Done
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedHotel(null);
                          window.location.href = '/dashboard';
                        }}
                        className="bg-gray-100 text-gray-800 font-bold text-xs px-6 py-2.5 rounded-xl hover:bg-gray-200 transition-all cursor-pointer"
                      >
                        View in Dashboard
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* ================= TAB 2: HOTEL CUSTOMER REVIEWS & RATINGS ================= */}
                {modalTab === 'reviews' && (
                  <div className="space-y-8">
                    {/* Overall Rating Score & Category Breakdown */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                        {/* Big Rating Badge */}
                        <div className="text-center md:border-r md:border-gray-200 md:pr-6">
                          <div className="text-5xl font-black text-gray-900 leading-none mb-1">
                            {selectedHotel.rating}
                            <span className="text-2xl text-gray-400 font-bold">/5</span>
                          </div>
                          <div className="flex justify-center gap-1 my-2">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                size={18} 
                                className={i < Math.floor(selectedHotel.rating) ? "fill-yellow-400 text-yellow-400" : "fill-gray-300 text-gray-300"} 
                              />
                            ))}
                          </div>
                          <div className="text-xs font-black uppercase tracking-wider text-brand">
                            Exceptional Experience
                          </div>
                          <div className="text-[11px] text-text-secondary mt-0.5">
                            Based on {selectedHotel.reviewsCount} verified customer reviews
                          </div>
                        </div>

                        {/* Category Progress Bars */}
                        <div className="md:col-span-2 space-y-2.5">
                          <div>
                            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
                              <span>Cleanliness & Hygiene</span>
                              <span>{selectedHotel.categoryRatings.cleanliness} / 5.0</span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="bg-brand h-full rounded-full" style={{ width: `${(selectedHotel.categoryRatings.cleanliness / 5) * 100}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
                              <span>Staff Hospitality & Service</span>
                              <span>{selectedHotel.categoryRatings.service} / 5.0</span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="bg-brand h-full rounded-full" style={{ width: `${(selectedHotel.categoryRatings.service / 5) * 100}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
                              <span>Location & Vicinity</span>
                              <span>{selectedHotel.categoryRatings.location} / 5.0</span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="bg-brand h-full rounded-full" style={{ width: `${(selectedHotel.categoryRatings.location / 5) * 100}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
                              <span>Room Comfort & Noise Isolation</span>
                              <span>{selectedHotel.categoryRatings.comfort} / 5.0</span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="bg-brand h-full rounded-full" style={{ width: `${(selectedHotel.categoryRatings.comfort / 5) * 100}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
                              <span>Value for Room Cost</span>
                              <span>{selectedHotel.categoryRatings.value} / 5.0</span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="bg-brand h-full rounded-full" style={{ width: `${(selectedHotel.categoryRatings.value / 5) * 100}%` }}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Interactive "Write a Customer Review" Form */}
                    <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
                      <h4 className="text-sm font-black text-gray-900 mb-1 flex items-center gap-2">
                        <MessageSquare size={16} className="text-brand" /> Share Your Hotel Review & Rating
                      </h4>
                      <p className="text-xs text-text-secondary mb-4">
                        Help fellow travelers by reviewing the 1 night room costs, service, and guest stay experience.
                      </p>

                      {reviewSuccessMsg && (
                        <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded-xl text-xs font-bold flex items-center gap-2">
                          <CheckCircle2 size={16} /> Thank you! Your review has been added to customer ratings.
                        </div>
                      )}

                      <form onSubmit={handleAddReview} className="space-y-3.5">
                        <div className="flex flex-wrap items-center gap-4">
                          <div>
                            <label className="text-[10px] font-bold uppercase text-text-secondary block mb-1">
                              Your Rating (Stars)
                            </label>
                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  type="button"
                                  key={star}
                                  onClick={() => setUserRatingInput(star)}
                                  className="p-1 hover:scale-110 transition-transform cursor-pointer"
                                >
                                  <Star 
                                    size={22} 
                                    className={star <= userRatingInput ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-300"} 
                                  />
                                </button>
                              ))}
                              <span className="ml-2 text-xs font-black text-gray-800">
                                {userRatingInput}.0 Stars
                              </span>
                            </div>
                          </div>

                          <div className="flex-1 min-w-[200px]">
                            <label className="text-[10px] font-bold uppercase text-text-secondary block mb-1">
                              Your Name
                            </label>
                            <input
                              type="text"
                              value={reviewAuthor}
                              onChange={(e) => setReviewAuthor(e.target.value)}
                              placeholder="e.g. Praveen Srinivas"
                              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-text-secondary block mb-1">
                            Review Title
                          </label>
                          <input
                            type="text"
                            value={reviewTitle}
                            onChange={(e) => setReviewTitle(e.target.value)}
                            placeholder="e.g. Fantastic 1 night stay, very transparent room cost"
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-text-secondary block mb-1">
                            Review Details
                          </label>
                          <textarea
                            rows={3}
                            required
                            value={reviewText}
                            onChange={(e) => setReviewText(e.target.value)}
                            placeholder="Describe how many persons stayed, comfort of the bed, cleanliness, and value for price..."
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-medium text-gray-900 outline-none focus:border-brand"
                          ></textarea>
                        </div>

                        <button
                          type="submit"
                          className="bg-brand text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow hover:bg-brand-dark transition-all cursor-pointer"
                        >
                          Submit Customer Review
                        </button>
                      </form>
                    </div>

                    {/* Customer Reviews List */}
                    <div className="space-y-4">
                      <h4 className="text-sm font-black text-gray-900">
                        Customer Reviews ({selectedHotel.reviews.length})
                      </h4>

                      {selectedHotel.reviews.map((rev) => (
                        <div 
                          key={rev.id} 
                          className="bg-gray-50/70 border border-gray-200 rounded-2xl p-4 sm:p-5 space-y-3"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <img 
                                src={rev.avatar} 
                                alt={rev.author} 
                                className="w-10 h-10 rounded-full object-cover border border-gray-200"
                              />
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <h5 className="text-xs font-black text-gray-900">{rev.author}</h5>
                                  {rev.isVerified && (
                                    <span className="inline-flex items-center gap-0.5 bg-green-100 text-green-800 text-[10px] font-bold px-1.5 py-0.5 rounded">
                                      <CheckCircle2 size={10} /> Verified Guest
                                    </span>
                                  )}
                                </div>
                                <span className="text-[11px] text-gray-500 font-medium">
                                  {rev.stayDetails} • {rev.date}
                                </span>
                              </div>
                            </div>

                            {/* Review Score */}
                            <div className="flex items-center gap-1 bg-yellow-100 text-yellow-800 px-2 py-1 rounded-md text-xs font-black">
                              <Star size={12} className="fill-yellow-600 text-yellow-600" />
                              <span>{rev.rating}.0</span>
                            </div>
                          </div>

                          <h6 className="text-xs font-black text-gray-900">{rev.title}</h6>
                          <p className="text-xs text-text-secondary leading-relaxed font-medium">
                            {rev.comment}
                          </p>

                          <div className="flex items-center gap-2 pt-1 text-[11px] text-gray-400 font-semibold">
                            <ThumbsUp size={12} />
                            <span>{rev.helpfulCount} travelers found this review helpful</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
