import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, ChevronRight, Star, MapPin, Tag, TrendingUp, ShieldCheck, Clock, Sparkles, Plane, Car, Train, Bike, Hotel, ArrowRight } from 'lucide-react';
import { cn } from '../lib/utils';
import { Link, useNavigate } from 'react-router-dom';

const categories = [
  { id: 'flights', name: 'Flights', icon: '✈️', path: '/flights' },
  { id: 'hotels', name: 'Hotels', icon: '🏨', path: '/hotels' },
  { id: 'trains', name: 'Trains', icon: '🚆', path: '/trains' },
  { id: 'cabs', name: 'Cars & Cabs', icon: '🚗', path: '/cabs' },
  { id: 'bikes', name: 'Bikes & Scooters', icon: '🛵', path: '/bikes' },
  { id: 'buses', name: 'Buses', icon: '🚌', path: '/buses' },
  { id: 'packages', name: 'Holidays', icon: '🌴', path: '/holidays' },
];

const trendingOffers = [
  { id: 1, title: 'Flat 15% OFF*', desc: 'On Domestic Flights using ICICI Bank Cards. Use code: TRAVELXICICI', icon: '🏷️', color: 'bg-red-50', link: '/flights' },
  { id: 2, title: 'Bali Special', desc: 'Book 5 nights and get 1 night free on luxury stays. Limited period offer.', icon: '🌴', color: 'bg-blue-50', link: '/hotels' },
  { id: 3, title: 'Scooter & Bike Pass', desc: 'Unlimited riding in Goa & Rishikesh from ₹450 ($5.40)/day with 2 helmets.', icon: '🛵', color: 'bg-amber-50', link: '/bikes' },
  { id: 4, title: 'Self-Drive SUVs', desc: 'Book Thar 4x4 or Innova Crysta with zero deposit & doorstep delivery.', icon: '🚗', color: 'bg-emerald-50', link: '/cabs' },
  { id: 5, title: 'Vande Bharat Express', desc: 'Semi-high speed chair car & executive rail booking with confirmed PNR.', icon: '🚆', color: 'bg-purple-50', link: '/trains' }
];

const featuredDestinations = [
  { id: 1, name: 'Maldives Paradise Escape', priceInr: '₹75,500', priceUsd: '$899', rating: 4.9, img: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=800&q=80', tag: 'Island Retreat' },
  { id: 2, name: 'Paris & Alps, France', priceInr: '₹1,04,160', priceUsd: '$1,240', rating: 4.8, img: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=800&q=80', tag: 'Romantic Stays' },
  { id: 3, name: 'Cultural Rajasthan, Jaipur', priceInr: '₹10,080', priceUsd: '$120', rating: 4.9, img: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80', tag: 'Heritage Forts' },
  { id: 4, name: 'Dubai Skyline & Safari', priceInr: '₹63,000', priceUsd: '$750', rating: 4.9, img: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=800&q=80', tag: 'Luxury & Desert' },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState('flights');
  const navigate = useNavigate();

  const handleSearchClick = () => {
    const found = categories.find(c => c.id === activeTab);
    if (found) {
      navigate(found.path);
    } else {
      navigate('/flights');
    }
  };

  return (
    <div className="pb-24 relative overflow-hidden bg-[#F2F5F8]">
      {/* ================= MULTI-COLOR TOURISM AMBIENT BACKGROUND GLOWS ================= */}
      <div className="absolute top-0 left-0 w-full h-[620px] bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      {/* Radiant Cyan Orb */}
      <div className="absolute top-20 -left-20 w-[450px] h-[450px] bg-cyan-400/20 rounded-full blur-[110px] pointer-events-none" />
      {/* Warm Sunset Amber Orb */}
      <div className="absolute top-36 right-10 w-[420px] h-[420px] bg-amber-500/20 rounded-full blur-[120px] pointer-events-none" />
      {/* Emerald Oasis Orb */}
      <div className="absolute top-[600px] left-1/4 w-[400px] h-[400px] bg-emerald-500/15 rounded-full blur-[120px] pointer-events-none" />
      {/* Royal Violet Aura */}
      <div className="absolute top-52 left-1/2 -translate-x-1/2 w-[380px] h-[380px] bg-purple-500/15 rounded-full blur-[130px] pointer-events-none" />
      {/* Radial Stars Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Hero Section with rich multi-color tourism ambient effects */}
      <section className="relative h-[480px] md:h-[430px] px-6 md:px-10 py-12 text-white bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] overflow-hidden">
        {/* Internal Multi-Color Ambient Orbs */}
        <div className="absolute -top-20 -right-20 w-[420px] h-[420px] bg-cyan-400/25 rounded-full blur-[100px] pointer-events-none animate-pulse" />
        <div className="absolute top-1/4 -left-20 w-[380px] h-[380px] bg-amber-500/20 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute -bottom-16 right-1/3 w-[360px] h-[360px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[300px] h-[300px] bg-purple-500/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[size:28px_28px] opacity-35 pointer-events-none" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-7xl mx-auto relative z-10"
        >
          <div className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest mb-3 border border-white/20">
            <Sparkles size={14} className="text-amber-300" /> Explore 120+ Global Destinations
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">Where to next?</h1>
          <p className="text-white/90 text-lg md:text-xl font-medium drop-shadow-2xs">
            Book flights, hotels, luxury cars, trains & bike rentals with seamless currency conversion.
          </p>
        </motion.div>

        {/* Search Bar Container */}
        <div className="absolute top-[220px] left-1/2 -translate-x-1/2 w-[calc(100%-48px)] max-w-7xl">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-3xl shadow-[0_16px_50px_rgba(0,0,0,0.18)] border border-[#E0E4E9] overflow-hidden"
          >
            {/* Search Tabs */}
            <div className="flex border-b border-[#E0E4E9] px-4 md:px-6 overflow-x-auto no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id)}
                  className={cn(
                    "flex flex-col items-center gap-1 py-4 px-5 border-b-4 transition-all shrink-0 cursor-pointer",
                    activeTab === cat.id 
                      ? "border-brand text-brand" 
                      : "border-transparent text-text-secondary hover:text-brand"
                  )}
                >
                  <span className="text-xl">{cat.icon}</span>
                  <span className="text-[11px] font-black uppercase tracking-widest whitespace-nowrap">{cat.name}</span>
                </button>
              ))}
            </div>

            {/* Quick Search Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-5 divide-x divide-gray-100">
              <div 
                onClick={handleSearchClick}
                className="p-4 hover:bg-blue-50/30 cursor-pointer transition-colors group"
              >
                <p className="text-[10px] font-extrabold text-text-secondary uppercase mb-1">From / Origin</p>
                <h4 className="text-xl font-black text-gray-900 group-hover:text-brand">DEL</h4>
                <p className="text-xs text-text-secondary font-medium">New Delhi Intl Airport / Station</p>
              </div>
              <div 
                onClick={handleSearchClick}
                className="p-4 hover:bg-blue-50/30 cursor-pointer transition-colors group"
              >
                <p className="text-[10px] font-extrabold text-text-secondary uppercase mb-1">To / Destination</p>
                <h4 className="text-xl font-black text-gray-900 group-hover:text-brand">DXB / GOA</h4>
                <p className="text-xs text-text-secondary font-medium">Dubai, Goa, Paris, Varanasi</p>
              </div>
              <div 
                onClick={handleSearchClick}
                className="p-4 hover:bg-blue-50/30 cursor-pointer transition-colors group"
              >
                <p className="text-[10px] font-extrabold text-text-secondary uppercase mb-1">Departure Date</p>
                <h4 className="text-xl font-black text-gray-900 group-hover:text-brand">Flexible</h4>
                <p className="text-xs text-text-secondary font-medium">Daily inventory available</p>
              </div>
              <div 
                onClick={handleSearchClick}
                className="p-4 hover:bg-blue-50/30 cursor-pointer transition-colors group"
              >
                <p className="text-[10px] font-extrabold text-text-secondary uppercase mb-1">Rental / Booking Mode</p>
                <h4 className="text-xl font-black text-gray-900 group-hover:text-brand capitalize">{activeTab}</h4>
                <p className="text-xs text-text-secondary font-medium">Verified TripVerse Partners</p>
              </div>
              <div 
                onClick={handleSearchClick}
                className="p-4 hover:bg-blue-50/30 cursor-pointer transition-colors group"
              >
                <p className="text-[10px] font-extrabold text-text-secondary uppercase mb-1">Currency</p>
                <h4 className="text-xl font-black text-brand">INR (₹) / USD ($)</h4>
                <p className="text-xs text-text-secondary font-medium">Global Switcher Active</p>
              </div>
            </div>

            {/* Action Bottom */}
            <div className="flex justify-center -mt-6">
              <button 
                onClick={handleSearchClick}
                className="bg-brand text-white px-12 py-3.5 rounded-full font-black text-lg shadow-[0_8px_20px_rgba(0,140,255,0.4)] hover:scale-105 transition-transform flex items-center gap-2 cursor-pointer"
              >
                <span>EXPLORE & BOOK {activeTab.toUpperCase()}</span>
                <ArrowRight size={18} />
              </button>
            </div>
            <div className="h-6"></div>
          </motion.div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-6 md:px-10 mt-[230px] md:mt-[180px] space-y-16">
        
        {/* ================= 5 CORE TRAVEL SERVICES SHOWCASE ================= */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-black text-gray-900 tracking-tight flex items-center gap-2">
                <Sparkles className="text-brand" /> All-in-One Travel Booking Hub
              </h2>
              <p className="text-xs md:text-sm text-text-secondary font-medium mt-1">
                Explore confirmed bookings for bikes, self-drive cars, express trains, flights & luxury hotels.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {/* Bikes Card */}
            <Link to="/bikes" className="group">
              <motion.div 
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl overflow-hidden border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all h-full flex flex-col justify-between"
              >
                <div className="h-40 relative overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1609630875171-b1321377ee65?auto=format&fit=crop&w=800&q=80" 
                    alt="Royal Enfield Himalayan 450"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 bg-brand text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow">
                    Bikes & Scooters
                  </span>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-gray-900 text-sm group-hover:text-brand transition-colors">
                      Himalayan 450 & Scooters
                    </h4>
                    <p className="text-[11px] text-text-secondary mt-1">Zero deposit, 2 helmets free in Goa, Manali, Rishikesh.</p>
                  </div>
                  <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                    <span className="text-xs font-black text-brand">From ₹450 ($5.40)/day</span>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-brand" />
                  </div>
                </div>
              </motion.div>
            </Link>

            {/* Cars Card */}
            <Link to="/cabs" className="group">
              <motion.div 
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl overflow-hidden border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all h-full flex flex-col justify-between"
              >
                <div className="h-40 relative overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80" 
                    alt="Mahindra Thar 4x4 & Mercedes"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 bg-amber-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow">
                    Cars & Cabs
                  </span>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-gray-900 text-sm group-hover:text-brand transition-colors">
                      SUVs, Sedans & 4x4 Thar
                    </h4>
                    <p className="text-[11px] text-text-secondary mt-1">Self-drive & chauffeur luxury rentals with zero deposit.</p>
                  </div>
                  <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                    <span className="text-xs font-black text-brand">From ₹1,600 ($19)/day</span>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-brand" />
                  </div>
                </div>
              </motion.div>
            </Link>

            {/* Trains Card */}
            <Link to="/trains" className="group">
              <motion.div 
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl overflow-hidden border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all h-full flex flex-col justify-between"
              >
                <div className="h-40 relative overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1532105956626-9569c03602f6?auto=format&fit=crop&w=800&q=80" 
                    alt="Vande Bharat Express"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 bg-blue-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow">
                    Train Booking
                  </span>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-gray-900 text-sm group-hover:text-brand transition-colors">
                      Vande Bharat & Rajdhani
                    </h4>
                    <p className="text-[11px] text-text-secondary mt-1">IRCTC authorized ticketing with live coach availability.</p>
                  </div>
                  <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                    <span className="text-xs font-black text-brand">From ₹510 ($6.10)</span>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-brand" />
                  </div>
                </div>
              </motion.div>
            </Link>

            {/* Flights Card */}
            <Link to="/flights" className="group">
              <motion.div 
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl overflow-hidden border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all h-full flex flex-col justify-between"
              >
                <div className="h-40 relative overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&w=800&q=80" 
                    alt="Flight Airline Booking"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow">
                    Flights
                  </span>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-gray-900 text-sm group-hover:text-brand transition-colors">
                      Air India, Emirates, IndiGo
                    </h4>
                    <p className="text-[11px] text-text-secondary mt-1">Direct airfares with free cabin baggage and instant e-ticket.</p>
                  </div>
                  <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                    <span className="text-xs font-black text-brand">From $190 (₹15,960)</span>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-brand" />
                  </div>
                </div>
              </motion.div>
            </Link>

            {/* Hotels Card */}
            <Link to="/hotels" className="group">
              <motion.div 
                whileHover={{ y: -6 }}
                className="bg-white rounded-3xl overflow-hidden border border-[#E0E4E9] shadow-sm hover:shadow-xl transition-all h-full flex flex-col justify-between"
              >
                <div className="h-40 relative overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80" 
                    alt="Luxury Hotel Resorts"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <span className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow">
                    Hotels & Resorts
                  </span>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-black text-gray-900 text-sm group-hover:text-brand transition-colors">
                      Luxury Resorts & Stays
                    </h4>
                    <p className="text-[11px] text-text-secondary mt-1">Transparent room rates for 1 night and multiple guests.</p>
                  </div>
                  <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                    <span className="text-xs font-black text-brand">From $120 (₹10,080)</span>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-brand" />
                  </div>
                </div>
              </motion.div>
            </Link>
          </div>
        </section>

        {/* Trending Offers */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-black text-gray-900 tracking-tight flex items-center gap-2">
              <Tag className="text-brand" /> Trending Travel Offers
            </h2>
            <Link to="/holidays" className="text-sm font-bold text-brand hover:underline">View All</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingOffers.map((offer) => (
              <Link to={offer.link} key={offer.id}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-white border border-[#E0E4E9] rounded-2xl p-5 flex gap-5 cursor-pointer hover:shadow-lg transition-all"
                >
                  <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shrink-0 shadow-2xs", offer.color)}>
                    {offer.icon}
                  </div>
                  <div className="flex flex-col justify-center">
                    <h4 className="font-extrabold text-gray-900 mb-1 leading-tight">{offer.title}</h4>
                    <p className="text-xs text-text-secondary leading-relaxed">{offer.desc}</p>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Destinations */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-black text-gray-900 tracking-tight flex items-center gap-2">
              <TrendingUp className="text-brand" /> Featured Global Holidays
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredDestinations.map((dest) => (
              <motion.div
                whileHover={{ y: -8 }}
                key={dest.id}
                className="bg-white border border-[#E0E4E9] rounded-3xl overflow-hidden group cursor-pointer shadow-sm hover:shadow-xl transition-all"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={dest.img} 
                    alt={dest.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-xl flex items-center gap-1 text-[10px] font-black shadow-sm">
                    <Star size={12} className="text-yellow-500 fill-yellow-500" />
                    {dest.rating}
                  </div>
                  <span className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-md border border-white/20">
                    {dest.tag}
                  </span>
                </div>
                <div className="p-4">
                  <h4 className="font-black text-gray-900 text-base mb-1">{dest.name}</h4>
                  <div className="flex items-center justify-between mt-2">
                    <div>
                      <span className="text-[10px] font-bold text-text-secondary uppercase block">Package From</span>
                      <p className="text-brand font-black text-sm">
                        {dest.priceInr} <span className="text-xs text-gray-500 font-bold">({dest.priceUsd})</span>
                      </p>
                    </div>
                    <Link to="/holidays" className="p-2 bg-blue-50 text-brand rounded-xl hover:bg-brand hover:text-white transition-colors">
                      <ChevronRight size={18} />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Dedicated Vehicles Banner (Cars & Bikes) */}
        <section className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] rounded-3xl p-6 md:p-10 text-white relative overflow-hidden shadow-2xl">
          {/* Ambient Glow Orbs */}
          <div className="absolute -top-12 -right-12 w-80 h-80 bg-cyan-400/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
          <div className="absolute -bottom-10 left-1/4 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="max-w-xl text-center lg:text-left">
              <span className="bg-amber-400 text-black text-xs font-black uppercase tracking-wider px-3.5 py-1 rounded-full mb-3 inline-block shadow">
                🚗 & 🏍️ Self-Drive Fleet Booking
              </span>
              <h3 className="text-3xl md:text-4xl font-black tracking-tight leading-tight">
                Cars, Thar 4x4 & Royal Enfield Himalayan 450
              </h3>
              <p className="text-blue-100 text-sm font-medium mt-2 leading-relaxed">
                Tour Goa beaches, Rishikesh rapids, or Leh-Ladakh passes. Includes unlimited kilometers, zero security deposit, and free helmets/accessories.
              </p>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 mt-6">
                <Link
                  to="/cabs"
                  className="bg-white hover:bg-gray-100 text-brand px-6 py-3 rounded-xl font-black text-xs shadow-md transition-all flex items-center gap-1.5"
                >
                  <Car size={16} />
                  <span>BOOK CARS & CABS</span>
                </Link>
                <Link
                  to="/bikes"
                  className="bg-brand-dark hover:bg-black text-white px-6 py-3 rounded-xl font-black text-xs shadow-md transition-all flex items-center gap-1.5 border border-white/20"
                >
                  <Bike size={16} />
                  <span>BOOK BIKES & SCOOTERS</span>
                </Link>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full lg:w-auto shrink-0">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl text-center">
                <span className="text-2xl block mb-1">🏔️</span>
                <div className="font-black text-sm text-white">Himalayan 450</div>
                <div className="text-amber-300 font-black text-xs mt-0.5">₹1,850 ($22)/day</div>
              </div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl text-center">
                <span className="text-2xl block mb-1">🚙</span>
                <div className="font-black text-sm text-white">Thar 4x4 Open</div>
                <div className="text-amber-300 font-black text-xs mt-0.5">₹3,800 ($45)/day</div>
              </div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl text-center">
                <span className="text-2xl block mb-1">👑</span>
                <div className="font-black text-sm text-white">Mercedes E-Class</div>
                <div className="text-amber-300 font-black text-xs mt-0.5">₹8,500 ($101)/day</div>
              </div>
            </div>
          </div>
        </section>

        {/* Trust Factors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-8 border-t border-b border-[#E0E4E9]">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-brand shrink-0">
              <ShieldCheck size={26} />
            </div>
            <div>
              <h4 className="font-black text-gray-900">Secure Bank-Grade Checkout</h4>
              <p className="text-xs text-text-secondary font-medium">100% encrypted bookings with live currency conversion</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 shrink-0">
              <Clock size={26} />
            </div>
            <div>
              <h4 className="font-black text-gray-900">24/7 Traveler Concierge</h4>
              <p className="text-xs text-text-secondary font-medium">Dedicated support for flights, trains, cars & bike rentals</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center text-green-600 shrink-0">
              <MapPin size={26} />
            </div>
            <div>
              <h4 className="font-black text-gray-900">Global & Domestic Reach</h4>
              <p className="text-xs text-text-secondary font-medium">Instant ticket issuance in 120+ destinations worldwide</p>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
