import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bike, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Clock, 
  Calendar, 
  Fuel, 
  Gauge, 
  Check, 
  X, 
  ArrowRight, 
  Search, 
  Sparkles, 
  CheckCircle2, 
  Printer, 
  ThumbsUp,
  SlidersHorizontal,
  RotateCcw,
  Users,
  Info
} from 'lucide-react';
import { cn, formatInrPrice } from '../lib/utils';
import { useAuth } from '../lib/AuthContext';
import { useCurrency } from '../lib/CurrencyContext';

interface TwoWheeler {
  id: string;
  name: string;
  category: 'Scooter' | 'Cruiser' | 'Sport' | 'Electric';
  engine: string;
  mileage: string;
  fuelType: 'Petrol' | 'Electric';
  pricePerDayInr: number;
  rating: number;
  ridesCount: number;
  image: string;
  badge?: string;
  availableCities: string[];
  inclusions: string[];
  description: string;
}

const vehiclesData: TwoWheeler[] = [
  {
    id: 'b1',
    name: 'Honda Activa 6G Premium',
    category: 'Scooter',
    engine: '110cc',
    mileage: '55 kmpl',
    fuelType: 'Petrol',
    pricePerDayInr: 450,
    rating: 4.8,
    ridesCount: 520,
    badge: 'Most Popular',
    availableCities: ['Goa', 'Rishikesh', 'Bali', 'Jaipur', 'Manali', 'Pondicherry'],
    image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80',
    inclusions: ['2 ISI Helmets Included', 'Unlimited Kilometers', 'Zero Security Deposit', 'Phone Mount & USB Charger'],
    description: 'The undisputed king of daily city exploring. Ultra smooth automatic transmission, high fuel efficiency, and comfortable upright seating.'
  },
  {
    id: 'b2',
    name: 'Vespa SXL 150 Italian Edition',
    category: 'Scooter',
    engine: '150cc',
    mileage: '45 kmpl',
    fuelType: 'Petrol',
    pricePerDayInr: 750,
    rating: 4.9,
    ridesCount: 380,
    badge: 'Style Icon',
    availableCities: ['Goa', 'Pondicherry', 'Bali', 'Jaipur'],
    image: 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=800&q=80',
    inclusions: ['2 Vintage Helmets', 'Front Disc ABS', 'Full Tank on Request', 'Unlimited KMs'],
    description: 'Iconic retro Italian design with punchy 150cc power. Perfect for coastal beach cruises in Goa and heritage alleyways.'
  },
  {
    id: 'b3',
    name: 'Royal Enfield Classic 350 Reborn',
    category: 'Cruiser',
    engine: '349cc',
    mileage: '38 kmpl',
    fuelType: 'Petrol',
    pricePerDayInr: 1200,
    rating: 4.9,
    ridesCount: 740,
    badge: 'Explorer Choice',
    availableCities: ['Goa', 'Manali', 'Rishikesh', 'Jaipur', 'Leh Ladakh'],
    image: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80',
    inclusions: ['Dual Channel ABS', 'Luggage Carrier Rack', '2 Full Face Helmets', 'Crash Guard Installed'],
    description: 'The legendary thumping sound meets refined comfort. Built for highway cruising, mountain roads in Manali, and desert trails.'
  },
  {
    id: 'b4',
    name: 'Royal Enfield Himalayan 450 (Sherpa)',
    category: 'Cruiser',
    engine: '452cc Liquid-Cooled DOHC (40 PS)',
    mileage: '32 kmpl',
    fuelType: 'Petrol',
    pricePerDayInr: 1850,
    rating: 5.0,
    ridesCount: 340,
    badge: 'Adventure Tourer',
    availableCities: ['Manali', 'Leh Ladakh', 'Rishikesh', 'Goa', 'Jaipur'],
    image: 'https://images.unsplash.com/photo-1609630875171-b1321377ee65?auto=format&fit=crop&w=1200&q=80',
    inclusions: ['Tripper TFT Navigation Dash', 'Touring Panniers & Top Rack', '2 Full Face Dual-Sport Helmets', 'Ride-by-Wire & Long Travel Suspension'],
    description: 'The all-new Himalayan 450 equipped with the Sherpa 452cc liquid-cooled engine, 21-inch spoke wheel, and high ground clearance built to conquer Leh-Ladakh, Spiti Valley, and rugged terrain.'
  },
  {
    id: 'b5',
    name: 'Ather 450X Gen 3 (Smart EV)',
    category: 'Electric',
    engine: '6.4 kW Motor',
    mileage: '105 km Range',
    fuelType: 'Electric',
    pricePerDayInr: 650,
    rating: 4.8,
    ridesCount: 210,
    badge: 'Zero Emission',
    availableCities: ['Goa', 'Jaipur', 'Pondicherry'],
    image: 'https://images.unsplash.com/photo-1558980664-769d59546b3d?auto=format&fit=crop&w=800&q=80',
    inclusions: ['Free Fast Charging at Hubs', 'Touchscreen Navigation', 'Reverse Assist Mode', 'Portable Home Charger'],
    description: 'Instant torque, whisper-quiet electric thrill with Google Maps touchscreen dashboard and zero fuel expense.'
  },
  {
    id: 'b6',
    name: 'KTM Duke 390 (Gen 3)',
    category: 'Sport',
    engine: '399cc DOHC',
    mileage: '28 kmpl',
    fuelType: 'Petrol',
    pricePerDayInr: 1950,
    rating: 4.9,
    ridesCount: 410,
    badge: 'Street Rocket',
    availableCities: ['Goa', 'Jaipur', 'Rishikesh', 'Manali'],
    image: 'https://images.unsplash.com/photo-1558981420-87aa9dad1c89?auto=format&fit=crop&w=800&q=80',
    inclusions: ['Cornering ABS & Traction Control', 'Quickshifter+ Enabled', '2 DOT Certified Helmets', 'TFT Display'],
    description: 'Sharp handling, lightweight chassis and exhilarating acceleration for riders who love pure performance.'
  }
];

export default function Bikes() {
  const { user } = useAuth();
  const { currency, convertInr } = useCurrency();

  // Filters
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Scooter' | 'Cruiser' | 'Sport' | 'Electric'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [budgetFilter, setBudgetFilter] = useState<'All' | 'under600' | 'under1500' | 'premium'>('All');
  const [sortBy, setSortBy] = useState<'recommended' | 'priceAsc' | 'priceDesc' | 'ratingDesc'>('recommended');

  // Booking Modal
  const [selectedVehicle, setSelectedVehicle] = useState<TwoWheeler | null>(null);
  const [rentalDays, setRentalDays] = useState(2);
  const [ridersCount, setRidersCount] = useState<number>(1);
  const [pickupCity, setPickupCity] = useState('Goa');
  const [pickupLocationType, setPickupLocationType] = useState('Hub');
  const [pickupDate, setPickupDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [riderName, setRiderName] = useState(user?.displayName || '');
  const [riderPhone, setRiderPhone] = useState(user?.phoneNumber || '');
  const [licenseNumber, setLicenseNumber] = useState('DL-042021008924');
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);

  // Filtered List
  const filteredVehicles = useMemo(() => {
    return vehiclesData.filter(v => {
      const matchCity = selectedCity === 'All' || v.availableCities.includes(selectedCity);
      const matchCat = selectedCategory === 'All' || v.category === selectedCategory;
      
      let matchBudget = true;
      if (budgetFilter === 'under600') matchBudget = v.pricePerDayInr <= 600;
      else if (budgetFilter === 'under1500') matchBudget = v.pricePerDayInr <= 1500;
      else if (budgetFilter === 'premium') matchBudget = v.pricePerDayInr >= 1500;

      const matchQuery = !searchQuery || 
        v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        v.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchCity && matchCat && matchBudget && matchQuery;
    }).sort((a, b) => {
      if (sortBy === 'priceAsc') return a.pricePerDayInr - b.pricePerDayInr;
      if (sortBy === 'priceDesc') return b.pricePerDayInr - a.pricePerDayInr;
      if (sortBy === 'ratingDesc') return b.rating - a.rating;
      return 0;
    });
  }, [selectedCity, selectedCategory, budgetFilter, searchQuery, sortBy]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (selectedCity !== 'All') count++;
    if (selectedCategory !== 'All') count++;
    if (budgetFilter !== 'All') count++;
    if (sortBy !== 'recommended') count++;
    return count;
  }, [searchQuery, selectedCity, selectedCategory, budgetFilter, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCity('All');
    setSelectedCategory('All');
    setBudgetFilter('All');
    setSortBy('recommended');
  };

  // Price Calculation in Rupees and Dollars
  const bookingPrices = useMemo(() => {
    if (!selectedVehicle) return { baseInr: 0, pillionInr: 0, taxInr: 0, discountInr: 0, totalInr: 0 };
    const baseInr = selectedVehicle.pricePerDayInr * rentalDays;
    const pillionInr = (ridersCount - 1) * 180 * rentalDays;
    const subtotal = baseInr + pillionInr;
    const discountInr = Math.round(subtotal * 0.10); // 10% promo
    const taxInr = Math.round((subtotal - discountInr) * 0.05); // 5% GST
    const totalInr = (subtotal - discountInr) + taxInr;
    return {
      baseInr,
      pillionInr,
      discountInr,
      taxInr,
      totalInr
    };
  }, [selectedVehicle, rentalDays, ridersCount]);

  const handleBookVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicle) return;

    const bookingId = 'TV-BIKE-' + Math.floor(100000 + Math.random() * 900000);
    const details = {
      bookingId,
      vehicleName: selectedVehicle.name,
      category: selectedVehicle.category,
      rentalDays,
      pickupCity,
      pickupDate,
      pickupLocationType,
      riderName: riderName.trim() || 'Rider',
      riderPhone: riderPhone.trim() || '+91 98765 43210',
      licenseNumber,
      pricing: bookingPrices,
      bookedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };

    setBookingConfirmed(details);
  };

  return (
    <div className="min-h-screen bg-[#F2F5F8] pb-20 relative overflow-hidden">
      {/* ================= MULTI-COLOR TOURISM AMBIENT BACKGROUND EFFECTS ================= */}
      <div className="absolute top-0 left-0 w-full h-[520px] bg-gradient-to-b from-[#041422] to-transparent pointer-events-none -z-10" />
      {/* Radiant Cyan Orb */}
      <div className="absolute top-16 -left-20 w-[420px] h-[420px] bg-cyan-400/20 rounded-full blur-[100px] pointer-events-none" />
      {/* Warm Sunset Amber Orb */}
      <div className="absolute top-28 right-10 w-[400px] h-[400px] bg-amber-500/20 rounded-full blur-[120px] pointer-events-none" />
      {/* Emerald Oasis Orb */}
      <div className="absolute top-80 left-1/3 w-[380px] h-[380px] bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      {/* Royal Violet Aura */}
      <div className="absolute top-36 left-1/2 -translate-x-1/2 w-[350px] h-[350px] bg-purple-500/15 rounded-full blur-[120px] pointer-events-none" />
      {/* Radial Stars Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Top Hero Banner with rich tourism & travel ambient effects */}
      <div className="bg-gradient-to-r from-[#041422] via-[#082949] to-[#008CFF] text-white py-14 px-6 md:px-10 relative overflow-hidden">
        {/* Ambient travel light orbs */}
        <div className="absolute -top-12 -right-12 w-80 h-80 bg-cyan-400/25 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-10 left-1/4 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-10 left-10 w-64 h-64 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 w-60 h-60 bg-purple-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[size:28px_28px] opacity-30 pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-blue-100 uppercase tracking-widest border border-white/20">
              <Bike size={15} /> Bike & Scooter Self-Drive Rentals
            </span>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              Active Currency: {currency === 'INR' ? 'Indian Rupee (₹)' : 'US Dollar ($)'}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 tracking-tight drop-shadow-sm">
            Rent Bikes & Scooters on the Go
          </h1>
          <p className="text-blue-100 font-medium text-sm md:text-base max-w-2xl mx-auto drop-shadow-2xs">
            From the rugged Himalayas on the <strong>Royal Enfield Himalayan 450</strong> to coastal rides in Goa on Vespas & Activas. Prices update dynamically in {currency === 'INR' ? 'Rupees (₹)' : 'Dollars ($)'}.
          </p>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-6 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-5 border border-[#E0E4E9] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
            {/* Search Input */}
            <div className="relative">
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Search Model / Brand / Engine
              </label>
              <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-brand">
                <Search size={16} className="text-gray-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Himalayan, Activa, Enfield, KTM..."
                  className="bg-transparent w-full text-xs md:text-sm font-bold text-gray-900 outline-none"
                />
              </div>
            </div>

            {/* City Selector */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Select City / Destination
              </label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">🌍 All Available Cities</option>
                <option value="Goa">🏖️ Goa (North & South)</option>
                <option value="Rishikesh">⛰️ Rishikesh, Uttarakhand</option>
                <option value="Manali">🏔️ Manali, Himachal</option>
                <option value="Jaipur">🏰 Jaipur, Rajasthan</option>
                <option value="Pondicherry">🌊 Pondicherry</option>
                <option value="Bali">🌴 Bali, Indonesia</option>
                <option value="Leh Ladakh">🏔️ Leh Ladakh</option>
              </select>
            </div>

            {/* Vehicle Category Filter */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Vehicle Type
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="All">All 2-Wheelers</option>
                <option value="Cruiser">🏍️ Adventure & Cruiser (Himalayan 450 / Classic)</option>
                <option value="Scooter">🛵 Scooters (Activa 6G / Vespa)</option>
                <option value="Sport">🏁 Sport Bikes (KTM Duke 390)</option>
                <option value="Electric">⚡ Electric Scooters (Ather 450X)</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1">
                Sort Pricing & Rating
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs md:text-sm font-bold text-gray-800 outline-none focus:border-brand cursor-pointer"
              >
                <option value="recommended">Recommended Picks</option>
                <option value="priceAsc">Rate: Low to High</option>
                <option value="priceDesc">Rate: High to Low</option>
                <option value="ratingDesc">Highest Customer Rating</option>
              </select>
            </div>
          </div>

          {/* Secondary Filter Chips Row */}
          <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-gray-400 mr-1">
                Daily Budget:
              </span>
              <button
                type="button"
                onClick={() => setBudgetFilter('All')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'All' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                All Rates
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under600')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under600' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Economy &lt; ₹600 ($7.15)/day
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('under1500')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'under1500' ? "bg-brand text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Mid-Range &lt; ₹1,500 ($17.85)/day
              </button>
              <button
                type="button"
                onClick={() => setBudgetFilter('premium')}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer",
                  budgetFilter === 'premium' ? "bg-amber-600 text-white shadow-xs" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                Adventure Tourer &gt; ₹1,500 ($17.85)/day
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-blue-50 border border-blue-100 rounded-xl px-3 py-1 flex items-center gap-1.5 text-xs text-brand font-bold">
                <ShieldCheck size={14} />
                <span>Zero Deposit • 2 Helmets Free</span>
              </div>

              {activeFiltersCount > 0 && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 hover:bg-red-100 px-3 py-1 rounded-lg transition-colors cursor-pointer"
                >
                  <RotateCcw size={12} />
                  Reset ({activeFiltersCount})
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Vehicles Grid */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Available Bikes & Scooters ({filteredVehicles.length})
            </h2>
            <p className="text-xs md:text-sm text-text-secondary font-medium">
              Self-drive rentals delivered to your hotel, airport, or nearest pickup station.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredVehicles.map((vehicle, i) => {
            const bikePrice = convertInr(vehicle.pricePerDayInr);
            return (
              <motion.div
                key={vehicle.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group border border-[#E0E4E9] flex flex-col justify-between"
              >
                {/* Image Section */}
                <div className="h-56 relative overflow-hidden bg-gray-100">
                  <img
                    src={vehicle.image}
                    alt={vehicle.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent"></div>

                  {/* Badges */}
                  <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                    <span className="bg-brand text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
                      <Sparkles size={11} /> {vehicle.badge || vehicle.category}
                    </span>
                    <span className="bg-black/60 backdrop-blur-md text-white text-[11px] font-bold px-2 py-0.5 rounded-md border border-white/20">
                      {vehicle.fuelType}
                    </span>
                  </div>

                  {/* Title & Rating on Image */}
                  <div className="absolute bottom-3 left-4 right-4 text-white">
                    <div className="flex items-center gap-1 text-yellow-400 text-xs font-black mb-0.5">
                      <Star size={12} fill="currentColor" />
                      <span>{vehicle.rating}</span>
                      <span className="text-white/80 font-medium text-[10px]">({vehicle.ridesCount} rides)</span>
                    </div>
                    <h3 className="text-lg font-black leading-tight drop-shadow-sm">{vehicle.name}</h3>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Specs Pill Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs font-bold text-gray-700 mb-4 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                      <div className="flex items-center gap-1.5">
                        <Gauge size={13} className="text-brand shrink-0" />
                        <span>Engine: {vehicle.engine}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Fuel size={13} className="text-brand shrink-0" />
                        <span>Mileage: {vehicle.mileage}</span>
                      </div>
                    </div>

                    <p className="text-xs text-text-secondary line-clamp-2 mb-4 font-medium">
                      {vehicle.description}
                    </p>

                    {/* Inclusions */}
                    <div className="space-y-1 mb-5">
                      {vehicle.inclusions.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-xs text-gray-800 font-semibold">
                          <Check size={13} className="text-green-600 shrink-0" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Dual Price & CTA */}
                  <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase text-text-secondary block">
                        Rental Cost Per Day
                      </span>
                      {/* Dual currency in Rupees & Dollars */}
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-2xl font-black text-brand leading-none">
                          {bikePrice.primaryFormatted}
                        </span>
                        <span className="text-xs font-bold text-gray-500">
                          ({bikePrice.secondaryFormatted})
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedVehicle(vehicle);
                        setBookingConfirmed(null);
                      }}
                      className="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-xl font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>BOOK RIDE</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Booking Drawer / Modal */}
      <AnimatePresence>
        {selectedVehicle && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-xl max-h-[92vh] rounded-3xl shadow-2xl border border-[#E0E4E9] overflow-hidden flex flex-col relative my-auto"
            >
              <button
                onClick={() => setSelectedVehicle(null)}
                className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer"
              >
                <X size={18} />
              </button>

              {/* Modal Banner */}
              <div className="relative h-44 shrink-0 overflow-hidden bg-gray-900">
                <img src={selectedVehicle.image} alt={selectedVehicle.name} className="w-full h-full object-cover opacity-80" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-6 right-12 text-white">
                  <span className="bg-brand text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md mb-1 inline-block">
                    {selectedVehicle.category}
                  </span>
                  <h3 className="text-xl font-black">{selectedVehicle.name}</h3>
                  <div className="flex items-center gap-2 text-xs font-semibold text-white/80 mt-0.5">
                    <span>{selectedVehicle.engine}</span>
                    <span>•</span>
                    <span>{selectedVehicle.mileage}</span>
                    <span>•</span>
                    <span className="text-yellow-400 font-bold">{selectedVehicle.rating}★ ({selectedVehicle.ridesCount} reviews)</span>
                  </div>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto flex-1">
                {!bookingConfirmed ? (
                  <form onSubmit={handleBookVehicle} className="space-y-5">
                    {/* Duration & Dates */}
                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black uppercase text-gray-900 flex items-center gap-1.5">
                          <Clock size={15} className="text-brand" /> Rental Duration
                        </span>
                        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-2 py-1">
                          <button
                            type="button"
                            onClick={() => setRentalDays(Math.max(1, rentalDays - 1))}
                            className="w-6 h-6 rounded bg-gray-100 font-bold hover:bg-gray-200"
                          >
                            -
                          </button>
                          <span className="text-xs font-black px-2">{rentalDays} Day{rentalDays > 1 ? 's' : ''}</span>
                          <button
                            type="button"
                            onClick={() => setRentalDays(rentalDays + 1)}
                            className="w-6 h-6 rounded bg-gray-100 font-bold hover:bg-gray-200"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-gray-200 pt-2.5">
                        <div>
                          <span className="text-xs font-black uppercase text-gray-900 flex items-center gap-1.5">
                            <Users size={15} className="text-brand" /> Riders / Travelers
                          </span>
                          <span className="text-[10px] text-gray-500 font-medium">±₹180/day per additional rider</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-2 py-1">
                          <button
                            type="button"
                            onClick={() => setRidersCount(Math.max(1, ridersCount - 1))}
                            className="w-6 h-6 rounded bg-gray-100 font-bold hover:bg-gray-200 cursor-pointer active:scale-95"
                            title="Decrease rider (reduces money)"
                          >
                            -
                          </button>
                          <span className="text-xs font-black px-2">{ridersCount} {ridersCount === 1 ? 'Solo Rider' : '2 Riders (Pillion)'}</span>
                          <button
                            type="button"
                            onClick={() => setRidersCount(Math.min(2, ridersCount + 1))}
                            className="w-6 h-6 rounded bg-brand text-white font-bold hover:bg-brand-dark cursor-pointer active:scale-95"
                            title="Increase rider (increases money)"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                            Pickup Date
                          </label>
                          <input
                            type="date"
                            value={pickupDate}
                            onChange={(e) => setPickupDate(e.target.value)}
                            className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-900 outline-none focus:border-brand"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                            Pickup City
                          </label>
                          <select
                            value={pickupCity}
                            onChange={(e) => setPickupCity(e.target.value)}
                            className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-900 outline-none focus:border-brand"
                          >
                            {selectedVehicle.availableCities.map(c => (
                              <option key={c} value={c}>{c}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Delivery Options */}
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-text-secondary block mb-1.5">
                        Pickup / Delivery Preference
                      </label>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        {[
                          { id: 'Hub', label: 'Self Pickup Hub' },
                          { id: 'Airport', label: 'Airport Delivery' },
                          { id: 'Hotel', label: 'Hotel Doorstep' },
                        ].map(opt => (
                          <button
                            type="button"
                            key={opt.id}
                            onClick={() => setPickupLocationType(opt.id)}
                            className={`p-2.5 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                              pickupLocationType === opt.id
                                ? 'bg-blue-50 border-brand text-brand'
                                : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Rider Information */}
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                          Lead Rider Name
                        </label>
                        <input
                          type="text"
                          required
                          value={riderName}
                          onChange={(e) => setRiderName(e.target.value)}
                          placeholder="Your Name"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-text-secondary uppercase block mb-1">
                          Mobile Number
                        </label>
                        <input
                          type="tel"
                          required
                          value={riderPhone}
                          onChange={(e) => setRiderPhone(e.target.value)}
                          placeholder="+91 98765 43210"
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 outline-none focus:border-brand"
                        />
                      </div>
                    </div>

                    {/* Price Breakdown in Rupees and Dollars */}
                    <div className="bg-gradient-to-br from-white to-blue-50/50 border border-blue-200 rounded-2xl p-4 space-y-2 text-xs font-semibold text-gray-700">
                      <div className="flex justify-between">
                        <span className="text-text-secondary">
                          Rental Fee ({rentalDays} Days x {convertInr(selectedVehicle.pricePerDayInr).primaryFormatted}):
                        </span>
                        <span className="font-bold text-gray-900">
                          {convertInr(bookingPrices.baseInr).combined}
                        </span>
                      </div>
                      <div className="flex justify-between text-green-700">
                        <span>2 ISI Helmets & Zero Deposit:</span>
                        <span>Free (₹0 / $0)</span>
                      </div>
                      {bookingPrices.pillionInr > 0 && (
                        <div className="flex justify-between text-orange-600 font-bold">
                          <span>Second Pillion Rider Helmet & Insurance (+₹180/day):</span>
                          <span>+{convertInr(bookingPrices.pillionInr).combined}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-green-700">
                        <span>Early Booking Discount (10%):</span>
                        <span>-{convertInr(bookingPrices.discountInr).combined}</span>
                      </div>
                      <div className="flex justify-between text-text-secondary">
                        <span>Roadside Insurance & GST (5%):</span>
                        <span>+{convertInr(bookingPrices.taxInr).combined}</span>
                      </div>

                      <div className="border-t border-gray-200 pt-3 flex justify-between items-baseline">
                        <div>
                          <span className="text-sm font-black text-gray-900 block">Total Payable Amount ({currency})</span>
                          <span className="text-[10px] text-gray-500 font-medium">Includes helmets, taxes & unlimited KMs</span>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-black text-brand block leading-none">
                            {convertInr(bookingPrices.totalInr).primaryFormatted}
                          </span>
                          <span className="text-xs font-bold text-gray-500">
                            ({convertInr(bookingPrices.totalInr).secondaryFormatted})
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-brand hover:bg-brand-dark text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck size={16} />
                      <span>CONFIRM RENTAL BOOKING ({convertInr(bookingPrices.totalInr).primaryFormatted} / {convertInr(bookingPrices.totalInr).secondaryFormatted})</span>
                    </button>
                  </form>
                ) : (
                  /* Confirmed Voucher */
                  <div className="text-center py-4 space-y-4">
                    <div className="w-14 h-14 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle2 size={32} />
                    </div>

                    <div>
                      <span className="bg-green-100 text-green-800 text-xs font-black uppercase px-2.5 py-0.5 rounded-full">
                        Rental Confirmed
                      </span>
                      <h4 className="text-xl font-black text-gray-900 mt-1">
                        Your {bookingConfirmed.vehicleName} is Ready!
                      </h4>
                      <p className="text-xs text-text-secondary mt-0.5">
                        Booking ID: <strong className="text-brand">{bookingConfirmed.bookingId}</strong>
                      </p>
                    </div>

                    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 text-left text-xs space-y-2 max-w-sm mx-auto">
                      <div className="flex justify-between">
                        <span className="text-text-secondary">Rider:</span>
                        <span className="font-bold text-gray-900">{bookingConfirmed.riderName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-secondary">Pickup Location:</span>
                        <span className="font-bold text-gray-900">{bookingConfirmed.pickupCity} ({bookingConfirmed.pickupLocationType})</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-secondary">Duration:</span>
                        <span className="font-bold text-gray-900">{bookingConfirmed.rentalDays} Days starting {bookingConfirmed.pickupDate}</span>
                      </div>
                      <div className="flex justify-between border-t border-gray-200 pt-2 font-black text-gray-900">
                        <span>Total Paid:</span>
                        <span className="text-brand font-black text-sm">{convertInr(bookingConfirmed.pricing.totalInr).combined}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setSelectedVehicle(null)}
                        className="bg-brand text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow cursor-pointer"
                      >
                        Done
                      </button>
                      <button
                        type="button"
                        onClick={() => window.print()}
                        className="bg-gray-100 text-gray-800 font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-gray-200 flex items-center gap-1 cursor-pointer"
                      >
                        <Printer size={13} /> Print Slip
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
