import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'motion/react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Phone, 
  Mail, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  Lock, 
  CheckCircle2, 
  RefreshCw, 
  ChevronDown, 
  User, 
  Eye, 
  EyeOff, 
  Clock, 
  AlertCircle,
  Compass,
  Plane,
  Globe2,
  Luggage
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext';

const countryCodes = [
  { code: '+91', country: 'India', flag: '🇮🇳', length: 10, placeholder: '98765 43210' },
  { code: '+1', country: 'USA & Canada', flag: '🇺🇸', length: 10, placeholder: '202 555 0184' },
  { code: '+44', country: 'United Kingdom', flag: '🇬🇧', length: 10, placeholder: '7911 123456' },
  { code: '+971', country: 'UAE', flag: '🇦🇪', length: 9, placeholder: '50 123 4567' },
  { code: '+65', country: 'Singapore', flag: '🇸🇬', length: 8, placeholder: '8123 4567' },
  { code: '+61', country: 'Australia', flag: '🇦🇺', length: 9, placeholder: '412 345 678' },
  { code: '+49', country: 'Germany', flag: '🇩🇪', length: 11, placeholder: '151 23456789' },
  { code: '+33', country: 'France', flag: '🇫🇷', length: 9, placeholder: '6 12 34 56 78' },
  { code: '+966', country: 'Saudi Arabia', flag: '🇸🇦', length: 9, placeholder: '50 123 4567' },
];

// Pre-computed particles for cinematic starry backdrop
const backgroundParticles = Array.from({ length: 32 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,
  y: Math.random() * 100,
  size: Math.random() * 3 + 1,
  duration: Math.random() * 4 + 3,
  delay: Math.random() * 3
}));

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const returnPath = (location.state as any)?.from?.pathname || '/';

  const { 
    user, 
    loginWithGoogle, 
    generatePhoneOtp, 
    verifyPhoneOtp, 
    generateEmailOtp, 
    verifyEmailOtp, 
    loginWithEmailPassword, 
    signupWithEmailPassword 
  } = useAuth();

  // If already logged in, redirect to requested destination or home
  useEffect(() => {
    if (user) {
      navigate(returnPath, { replace: true });
    }
  }, [user, navigate, returnPath]);

  // Main Auth Mode: 'phone' or 'email'
  const [activeTab, setActiveTab] = useState<'phone' | 'email'>('phone');

  // Phone state
  const [selectedCountry, setSelectedCountry] = useState(countryCodes[0]);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneStep, setPhoneStep] = useState<'input' | 'otp'>('input');
  const [phoneOtp, setPhoneOtp] = useState(['', '', '', '', '', '']);
  const [generatedPhoneCode, setGeneratedPhoneCode] = useState<string | null>(null);

  // Email / Gmail state
  const [emailTabMode, setEmailTabMode] = useState<'otp' | 'password'>('otp');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [emailStep, setEmailStep] = useState<'input' | 'otp'>('input');
  const [emailOtp, setEmailOtp] = useState(['', '', '', '', '', '']);
  const [generatedEmailCode, setGeneratedEmailCode] = useState<string | null>(null);

  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'error' | 'success' | 'info' } | null>(null);
  const [countdown, setCountdown] = useState(0);

  // 3D Parallax Tilt Values using Framer Motion
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [7, -7]), { stiffness: 120, damping: 15 });
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-7, 7]), { stiffness: 120, damping: 15 });
  const shineOpacity = useSpring(useTransform(mouseY, [-0.5, 0.5], [0.15, 0]), { stiffness: 100, damping: 20 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;
    mouseX.set(clientX / width - 0.5);
    mouseY.set(clientY / height - 0.5);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  // Segmented input refs
  const phoneOtpRefs = useRef<(HTMLInputElement | null)[]>([]);
  const emailOtpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Resend Countdown Timer
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // Google Sign In
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setStatusMessage(null);
    try {
      await loginWithGoogle();
      navigate(returnPath, { replace: true });
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Google sign-in error', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  // Generate Phone OTP
  const handleGeneratePhoneOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!phoneNumber || phoneNumber.trim().length < 6) {
      setStatusMessage({ text: 'Please enter a valid mobile number', type: 'error' });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);
    const fullNumber = `${selectedCountry.code} ${phoneNumber.trim()}`;

    try {
      const res = await generatePhoneOtp(fullNumber);
      if (res.success && res.code) {
        setGeneratedPhoneCode(res.code);
        setPhoneStep('otp');
        setCountdown(30);
        setStatusMessage({
          text: `Verification OTP dispatched to ${selectedCountry.code} ${phoneNumber.trim()}`,
          type: 'success'
        });
        setTimeout(() => phoneOtpRefs.current[0]?.focus(), 150);
      } else {
        setStatusMessage({ text: res.message || 'Failed to generate OTP', type: 'error' });
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Error generating OTP', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhoneOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      const pasted = value.slice(0, 6).split('');
      const newOtp = [...phoneOtp];
      pasted.forEach((char, i) => {
        if (i < 6) newOtp[i] = char;
      });
      setPhoneOtp(newOtp);
      const nextFocus = Math.min(pasted.length, 5);
      phoneOtpRefs.current[nextFocus]?.focus();
      return;
    }

    const newOtp = [...phoneOtp];
    newOtp[index] = value;
    setPhoneOtp(newOtp);

    if (value && index < 5) {
      phoneOtpRefs.current[index + 1]?.focus();
    }
  };

  const handlePhoneOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !phoneOtp[index] && index > 0) {
      phoneOtpRefs.current[index - 1]?.focus();
    }
  };

  const autoFillPhoneOtp = () => {
    if (generatedPhoneCode) {
      const digits = generatedPhoneCode.split('');
      setPhoneOtp(digits);
      phoneOtpRefs.current[5]?.focus();
    }
  };

  const handleVerifyPhoneOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const enteredOtp = phoneOtp.join('');
    if (enteredOtp.length !== 6) {
      setStatusMessage({ text: 'Please enter all 6 digits of the OTP code', type: 'error' });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);
    const fullNumber = `${selectedCountry.code} ${phoneNumber.trim()}`;

    try {
      const res = await verifyPhoneOtp(fullNumber, enteredOtp);
      if (res.success) {
        setStatusMessage({ text: 'Phone verified! Preparing your journey...', type: 'success' });
        setTimeout(() => navigate(returnPath, { replace: true }), 600);
      } else {
        setStatusMessage({ text: res.message || 'Invalid code entered. Please try again.', type: 'error' });
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Verification error', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  // Generate Email OTP
  const handleGenerateEmailOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!email || !email.includes('@') || !email.includes('.')) {
      setStatusMessage({ text: 'Please enter a valid Gmail / Email address', type: 'error' });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);
    try {
      const res = await generateEmailOtp(email.trim());
      if (res.success && res.code) {
        setGeneratedEmailCode(res.code);
        setEmailStep('otp');
        setCountdown(30);
        setStatusMessage({
          text: `Verification code sent to ${email.trim()}`,
          type: 'success'
        });
        setTimeout(() => emailOtpRefs.current[0]?.focus(), 150);
      } else {
        setStatusMessage({ text: res.message || 'Failed to dispatch email OTP', type: 'error' });
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Error generating email OTP', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      const pasted = value.slice(0, 6).split('');
      const newOtp = [...emailOtp];
      pasted.forEach((char, i) => {
        if (i < 6) newOtp[i] = char;
      });
      setEmailOtp(newOtp);
      const nextFocus = Math.min(pasted.length, 5);
      emailOtpRefs.current[nextFocus]?.focus();
      return;
    }

    const newOtp = [...emailOtp];
    newOtp[index] = value;
    setEmailOtp(newOtp);

    if (value && index < 5) {
      emailOtpRefs.current[index + 1]?.focus();
    }
  };

  const handleEmailOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !emailOtp[index] && index > 0) {
      emailOtpRefs.current[index - 1]?.focus();
    }
  };

  const autoFillEmailOtp = () => {
    if (generatedEmailCode) {
      const digits = generatedEmailCode.split('');
      setEmailOtp(digits);
      emailOtpRefs.current[5]?.focus();
    }
  };

  const handleVerifyEmailOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const enteredOtp = emailOtp.join('');
    if (enteredOtp.length !== 6) {
      setStatusMessage({ text: 'Please enter all 6 digits of the code', type: 'error' });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);
    try {
      const res = await verifyEmailOtp(email.trim(), enteredOtp);
      if (res.success) {
        setStatusMessage({ text: 'Verified successfully! Redirecting...', type: 'success' });
        setTimeout(() => navigate(returnPath, { replace: true }), 600);
      } else {
        setStatusMessage({ text: res.message || 'Invalid code. Try again.', type: 'error' });
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Verification failed', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  // Password Login / Register
  const handlePasswordAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setStatusMessage({ text: 'Please provide both email and password', type: 'error' });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);
    try {
      if (isRegisterMode) {
        const res = await signupWithEmailPassword(email.trim(), password, fullName.trim());
        if (res.success) {
          setStatusMessage({ text: 'Account created! Welcome to TripVerse.', type: 'success' });
          setTimeout(() => navigate(returnPath, { replace: true }), 600);
        } else {
          setStatusMessage({ text: res.message || 'Registration failed', type: 'error' });
        }
      } else {
        const res = await loginWithEmailPassword(email.trim(), password);
        if (res.success) {
          setStatusMessage({ text: 'Welcome back!', type: 'success' });
          setTimeout(() => navigate(returnPath, { replace: true }), 600);
        } else {
          setStatusMessage({ text: res.message || 'Sign in failed', type: 'error' });
        }
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Authentication error', type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="min-h-[calc(100vh-64px)] relative flex flex-col justify-center items-center py-10 px-4 sm:px-6 overflow-hidden bg-gradient-to-b from-[#0c142c] via-[#1a0f35] to-[#2b102b] select-none"
    >
      {/* ================= 3D CINEMATIC TOURISM & TRAVEL BACKGROUND ================= */}
      {/* Multi-Color Sunset & Aurora Atmospheric Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Golden Sun / Horizon Glow */}
        <motion.div 
          animate={{ scale: [1, 1.08, 1], opacity: [0.65, 0.85, 0.65] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-gradient-to-t from-[#ff5e00]/30 via-[#ff2a6d]/20 to-transparent rounded-full blur-[100px] pointer-events-none"
        />
        
        {/* Tropical Lagoon & Azure Glow (Top Right) */}
        <div className="absolute -top-20 -right-20 w-[600px] h-[600px] bg-gradient-to-br from-[#00c6ff]/25 to-[#0072ff]/15 rounded-full blur-[120px] pointer-events-none"></div>
        
        {/* Warm Saffron & Coral Glow (Top Left) */}
        <div className="absolute top-10 -left-20 w-[550px] h-[550px] bg-gradient-to-br from-[#ff9900]/20 to-[#ff007f]/15 rounded-full blur-[130px] pointer-events-none"></div>

        {/* Ambient Emerald Lagoon Glow (Bottom Left) */}
        <div className="absolute bottom-0 -left-20 w-[450px] h-[450px] bg-[#00e5c9]/15 rounded-full blur-[110px] pointer-events-none"></div>
      </div>

      {/* Layered Panoramic Mountain Silhouette at the Base */}
      <div className="absolute bottom-0 inset-x-0 pointer-events-none z-0 opacity-40">
        <svg viewBox="0 0 1440 280" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
          {/* Back Mountain Ridge (Muted Twilight) */}
          <path 
            d="M0 280 L0 180 L180 110 L340 190 L520 80 L720 170 L920 60 L1120 160 L1300 100 L1440 180 L1440 280 Z" 
            fill="#1d0e33" 
            opacity="0.6"
          />
          {/* Middle Mountain Ridge with Golden Sunset Rim Lighting */}
          <path 
            d="M0 280 L0 210 L140 160 L280 230 L460 140 L640 210 L840 120 L1020 200 L1200 130 L1360 210 L1440 180 L1440 280 Z" 
            fill="#120924" 
            opacity="0.85"
          />
          {/* Front Foreground Ridge */}
          <path 
            d="M0 280 L0 250 L120 220 L300 260 L480 200 L700 250 L900 190 L1140 250 L1320 210 L1440 250 L1440 280 Z" 
            fill="#080414" 
          />
        </svg>
      </div>

      {/* Floating 3D Hot Air Balloons (Cappadocia Tourism Vibe) */}
      <motion.div
        animate={{ 
          y: [0, -26, 0], 
          x: [0, 8, 0],
          rotate: [-2, 2, -2] 
        }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-20 right-[12%] pointer-events-none z-0 hidden md:flex flex-col items-center opacity-85"
      >
        <div className="w-14 h-18 rounded-[50%_50%_45%_45%/60%_60%_40%_40%] bg-gradient-to-tr from-[#ff3366] via-[#ff9900] to-[#ffd700] p-1 shadow-[0_8px_25px_rgba(255,100,0,0.5)] border border-amber-300/40 relative">
          <div className="w-full h-full rounded-[inherit] border-r-2 border-l-2 border-white/30 flex items-center justify-center">
            <span className="text-[10px] font-black text-white/90">WANDER</span>
          </div>
          {/* Basket */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-4 h-2.5 bg-amber-900 rounded-xs border border-amber-500/50 shadow"></div>
        </div>
        <span className="text-[9px] font-bold text-amber-200 mt-4 tracking-widest uppercase bg-black/40 px-2 py-0.5 rounded-full border border-amber-500/30">
          Cappadocia
        </span>
      </motion.div>

      <motion.div
        animate={{ 
          y: [0, -18, 0], 
          x: [0, -6, 0],
          rotate: [2, -2, 2] 
        }}
        transition={{ duration: 11, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        className="absolute top-44 left-[10%] pointer-events-none z-0 hidden lg:flex flex-col items-center opacity-75"
      >
        <div className="w-11 h-14 rounded-[50%_50%_45%_45%/60%_60%_40%_40%] bg-gradient-to-tr from-[#00c6ff] via-[#0072ff] to-[#9900ef] p-0.5 shadow-[0_6px_20px_rgba(0,180,255,0.4)] border border-sky-300/40 relative">
          <div className="w-full h-full rounded-[inherit] border-r border-l border-white/30"></div>
          {/* Basket */}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3 h-2 bg-indigo-950 rounded-xs border border-sky-400/40"></div>
        </div>
        <span className="text-[9px] font-bold text-sky-200 mt-3 tracking-widest uppercase bg-black/40 px-2 py-0.5 rounded-full border border-sky-500/30">
          Air Tours
        </span>
      </motion.div>

      {/* Floating Starlight & Sunset Firefly Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {backgroundParticles.map((star) => (
          <motion.div
            key={star.id}
            initial={{ opacity: 0.2, scale: 0.8 }}
            animate={{ 
              opacity: [0.2, 0.9, 0.2], 
              scale: [0.8, 1.4, 0.8],
              y: [0, -22, 0] 
            }}
            transition={{
              duration: star.duration,
              repeat: Infinity,
              delay: star.delay,
              ease: "easeInOut"
            }}
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
              width: `${star.size}px`,
              height: `${star.size}px`,
            }}
            className={`absolute rounded-full shadow-[0_0_8px_currentColor] ${
              star.id % 3 === 0 
                ? 'bg-amber-300 text-amber-300' 
                : star.id % 3 === 1 
                ? 'bg-rose-300 text-rose-300' 
                : 'bg-cyan-200 text-cyan-200'
            }`}
          />
        ))}
      </div>

      {/* Floating 3D Curved International Flight Path with Sunset Gradient */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="travelOrbitGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF7A00" stopOpacity="0.2" />
            <stop offset="50%" stopColor="#FF2A6D" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#00C4FF" stopOpacity="0.3" />
          </linearGradient>
        </defs>
        <path
          d="M -100 220 C 300 40, 750 680, 1550 160"
          fill="none"
          stroke="url(#travelOrbitGrad)"
          strokeWidth="2.5"
          strokeDasharray="9 9"
        />
        <path
          d="M 50 850 C 450 500, 850 180, 1600 580"
          fill="none"
          stroke="url(#travelOrbitGrad)"
          strokeWidth="1.8"
          strokeDasharray="6 6"
        />
      </svg>

      {/* 3D Floating Cruising Airplane with Sunset Glow Contrail */}
      <motion.div
        animate={{
          x: ['-20vw', '110vw'],
          y: ['36vh', '18vh'],
          rotate: [12, 16, 12]
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute pointer-events-none z-0 flex items-center gap-2 opacity-70"
      >
        <Plane size={38} className="text-amber-300 drop-shadow-[0_0_18px_rgba(255,160,0,0.9)] -rotate-45" />
        <div className="w-56 h-1 bg-gradient-to-r from-amber-400 via-rose-400 to-transparent blur-[1px]"></div>
      </motion.div>

      {/* Floating 3D Tourism Landmarks & Destination Tags */}
      <motion.div
        animate={{ y: [0, -12, 0], rotateZ: [0, 4, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="hidden xl:flex items-center gap-2.5 absolute top-28 left-16 z-0 bg-white/10 backdrop-blur-xl border border-white/20 px-4 py-2.5 rounded-2xl text-white shadow-2xl pointer-events-none"
      >
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-md">
          <Globe2 size={18} />
        </div>
        <div>
          <div className="text-[10px] font-black text-amber-300 uppercase tracking-wider">Tourism Explorer</div>
          <div className="text-xs font-black text-white">Paris • Bali • Maldives • Rajasthan</div>
        </div>
      </motion.div>

      <motion.div
        animate={{ y: [0, 14, 0], rotateZ: [0, -3, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="hidden xl:flex items-center gap-2.5 absolute bottom-28 right-16 z-0 bg-white/10 backdrop-blur-xl border border-white/20 px-4 py-2.5 rounded-2xl text-white shadow-2xl pointer-events-none"
      >
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
          <Compass size={18} />
        </div>
        <div>
          <div className="text-[10px] font-black text-cyan-300 uppercase tracking-wider">Wanderlust Pass</div>
          <div className="text-xs font-black text-white">Flights • Hotels • Bike Rentals</div>
        </div>
      </motion.div>

      {/* ================= 3D TILT GLASS CARD ================= */}
      <div style={{ perspective: 1200 }} className="w-full max-w-[490px] z-10">
        <motion.div 
          style={{ 
            rotateX, 
            rotateY,
            transformStyle: 'preserve-3d'
          }}
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="relative w-full bg-white/95 backdrop-blur-2xl rounded-3xl shadow-[0_30px_90px_rgba(0,0,0,0.65)] border border-white/40 overflow-hidden"
        >
          {/* Glass Card Specular Light Sheen */}
          <motion.div 
            style={{ opacity: shineOpacity }}
            className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-transparent pointer-events-none z-20"
          />

          {/* Top Cinematic Header */}
          <div className="bg-gradient-to-r from-[#031527] via-[#04284d] to-[#008CFF] px-8 pt-8 pb-7 text-white text-center relative overflow-hidden">
            {/* Animated Light Arc */}
            <div className="absolute -top-10 -right-10 w-36 h-36 bg-sky-400/20 rounded-full blur-2xl pointer-events-none"></div>
            <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-blue-600/20 rounded-full blur-2xl pointer-events-none"></div>

            <motion.div 
              animate={{ 
                rotateY: [0, 360],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear"
              }}
              className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md mb-3 shadow-[0_8px_25px_rgba(0,140,255,0.4)] border border-white/20"
            >
              <span className="text-3xl">✈️</span>
            </motion.div>

            <h2 className="text-2xl font-black tracking-tight text-white flex items-center justify-center gap-2">
              TripVerse Portal
            </h2>
            <p className="text-sky-200 text-xs font-medium mt-1">
              Gateway to premium flights, luxury stays, trains & bike rentals
            </p>
          </div>

          <div className="p-6 sm:p-8">
            {/* Authorization Notice if redirected from protected page */}
            {(location.state as any)?.from && !statusMessage && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-5 p-3.5 rounded-2xl bg-amber-500/15 border border-amber-400/40 text-amber-900 flex items-start gap-2.5 text-xs font-semibold"
              >
                <Lock size={16} className="text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-black block text-amber-950">Sign In Required</span>
                  <span className="text-[11px] text-amber-800">
                    Please log in to view and book trips on TripVerse. You will be returned to your requested page immediately after signing in.
                  </span>
                </div>
              </motion.div>
            )}

            {/* Status / Alert Message */}
            {statusMessage && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className={`mb-5 p-3.5 rounded-xl text-xs font-semibold flex items-start gap-2.5 ${
                  statusMessage.type === 'error'
                    ? 'bg-red-50 text-red-700 border border-red-200'
                    : statusMessage.type === 'success'
                    ? 'bg-green-50 text-green-700 border border-green-200'
                    : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}
              >
                {statusMessage.type === 'error' ? (
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
                )}
                <div className="flex-1 leading-relaxed">{statusMessage.text}</div>
              </motion.div>
            )}

            {/* Google Authentication Button */}
            <div className="mb-6">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 bg-white hover:bg-gray-50 border-2 border-[#E0E4E9] active:border-brand py-3.5 px-4 rounded-xl font-bold text-gray-800 text-sm shadow-sm transition-all hover:shadow hover:border-gray-300 disabled:opacity-60 cursor-pointer"
              >
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google / Gmail</span>
              </button>
            </div>

            {/* Divider */}
            <div className="relative flex items-center justify-center my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#E0E4E9]"></div>
              </div>
              <span className="relative bg-white px-3 text-[11px] font-black text-text-secondary uppercase tracking-widest">
                or sign in with
              </span>
            </div>

            {/* Tabs: Phone Number + OTP vs. Gmail / Email */}
            <div className="grid grid-cols-2 p-1 bg-gray-100 rounded-xl mb-6">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('phone');
                  setStatusMessage(null);
                }}
                className={`flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'phone'
                    ? 'bg-white text-brand shadow-sm'
                    : 'text-text-secondary hover:text-gray-900'
                }`}
              >
                <Phone size={15} />
                <span>Phone + OTP</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('email');
                  setStatusMessage(null);
                }}
                className={`flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'email'
                    ? 'bg-white text-brand shadow-sm'
                    : 'text-text-secondary hover:text-gray-900'
                }`}
              >
                <Mail size={15} />
                <span>Gmail / Email</span>
              </button>
            </div>

            {/* ================= TAB 1: PHONE NUMBER WITH GENERATE OTP ================= */}
            {activeTab === 'phone' && (
              <div>
                {phoneStep === 'input' ? (
                  <form onSubmit={handleGeneratePhoneOtp} className="space-y-4">
                    <div>
                      <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-1.5 block">
                        Mobile Phone Number
                      </label>
                      <div className="flex rounded-xl border border-[#E0E4E9] focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/10 transition-all bg-gray-50 overflow-hidden">
                        {/* Country Code Picker */}
                        <div className="relative border-r border-[#E0E4E9] bg-white">
                          <select
                            value={selectedCountry.code}
                            onChange={(e) => {
                              const found = countryCodes.find(c => c.code === e.target.value);
                              if (found) setSelectedCountry(found);
                            }}
                            className="appearance-none bg-transparent pl-3 pr-7 py-3 text-xs font-bold text-gray-800 outline-none cursor-pointer h-full"
                          >
                            {countryCodes.map((item) => (
                              <option key={item.code} value={item.code}>
                                {item.flag} {item.code}
                              </option>
                            ))}
                          </select>
                          <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        </div>

                        {/* Number Input */}
                        <input
                          type="tel"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value.replace(/[^0-9\s]/g, ''))}
                          placeholder={selectedCountry.placeholder}
                          className="w-full bg-transparent px-3.5 py-3 text-sm font-semibold text-gray-900 outline-none placeholder:text-gray-400"
                          autoFocus
                        />
                      </div>
                      <span className="text-[11px] text-text-secondary mt-1 block">
                        Enter your mobile number to generate a secure 6-digit OTP.
                      </span>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading || !phoneNumber.trim()}
                      className="w-full flex items-center justify-center gap-2 bg-brand text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md hover:bg-brand-dark transition-all disabled:opacity-50 cursor-pointer"
                    >
                      {isLoading ? (
                        <RefreshCw size={18} className="animate-spin" />
                      ) : (
                        <>
                          <Sparkles size={16} />
                          <span>GENERATE OTP</span>
                          <ArrowRight size={16} />
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  /* Phone OTP Verification View */
                  <form onSubmit={handleVerifyPhoneOtp} className="space-y-5">
                    {/* Generated OTP Showcase Notification Banner */}
                    {generatedPhoneCode && (
                      <motion.div
                        initial={{ scale: 0.95, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 flex items-center justify-between"
                      >
                        <div>
                          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600">Verification Code</div>
                          <div className="text-base font-black text-gray-900 tracking-widest mt-0.5">
                            {generatedPhoneCode}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={autoFillPhoneOtp}
                          className="bg-brand text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm hover:bg-brand-dark transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles size={12} /> Auto-fill OTP
                        </button>
                      </motion.div>
                    )}

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest block">
                          Enter 6-Digit OTP Code
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setPhoneStep('input');
                            setPhoneOtp(['', '', '', '', '', '']);
                            setStatusMessage(null);
                          }}
                          className="text-xs font-bold text-brand hover:underline cursor-pointer"
                        >
                          Change Number
                        </button>
                      </div>

                      <div className="text-xs text-gray-600 mb-3">
                        Dispatched to: <span className="font-bold text-gray-900">{selectedCountry.code} {phoneNumber}</span>
                      </div>

                      {/* Segmented 6-digit Inputs */}
                      <div className="grid grid-cols-6 gap-2">
                        {phoneOtp.map((digit, index) => (
                          <input
                            key={index}
                            ref={(el) => {
                              phoneOtpRefs.current[index] = el;
                            }}
                            type="text"
                            inputMode="numeric"
                            maxLength={6}
                            value={digit}
                            onChange={(e) => handlePhoneOtpChange(index, e.target.value)}
                            onKeyDown={(e) => handlePhoneOtpKeyDown(index, e)}
                            className="w-full h-12 text-center text-lg font-black bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white focus:ring-2 focus:ring-brand/20 rounded-xl outline-none transition-all"
                          />
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading || phoneOtp.join('').length !== 6}
                      className="w-full flex items-center justify-center gap-2 bg-brand text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md hover:bg-brand-dark transition-all disabled:opacity-50 cursor-pointer"
                    >
                      {isLoading ? (
                        <RefreshCw size={18} className="animate-spin" />
                      ) : (
                        <>
                          <ShieldCheck size={18} />
                          <span>VERIFY OTP & SIGN IN</span>
                        </>
                      )}
                    </button>

                    <div className="flex items-center justify-between text-xs text-text-secondary font-medium pt-1">
                      <span>Didn't receive code?</span>
                      {countdown > 0 ? (
                        <span className="flex items-center gap-1 font-bold text-gray-500">
                          <Clock size={13} /> Resend in {countdown}s
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleGeneratePhoneOtp()}
                          className="font-bold text-brand hover:underline cursor-pointer"
                        >
                          Resend OTP Now
                        </button>
                      )}
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* ================= TAB 2: GMAIL / EMAIL AUTH (OTP OR PASSWORD) ================= */}
            {activeTab === 'email' && (
              <div>
                {/* Sub-mode switcher */}
                <div className="flex items-center justify-center gap-4 mb-4 pb-2 border-b border-gray-100">
                  <button
                    type="button"
                    onClick={() => {
                      setEmailTabMode('otp');
                      setStatusMessage(null);
                    }}
                    className={`text-xs font-bold pb-1 transition-all cursor-pointer ${
                      emailTabMode === 'otp'
                        ? 'text-brand border-b-2 border-brand'
                        : 'text-text-secondary hover:text-gray-800'
                    }`}
                  >
                    ⚡ Instant Email OTP
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEmailTabMode('password');
                      setStatusMessage(null);
                    }}
                    className={`text-xs font-bold pb-1 transition-all cursor-pointer ${
                      emailTabMode === 'password'
                        ? 'text-brand border-b-2 border-brand'
                        : 'text-text-secondary hover:text-gray-800'
                    }`}
                  >
                    🔑 Password Login
                  </button>
                </div>

                {emailTabMode === 'otp' ? (
                  emailStep === 'input' ? (
                    <form onSubmit={handleGenerateEmailOtp} className="space-y-4">
                      <div>
                        <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-1.5 block">
                          Gmail or Email Address
                        </label>
                        <div className="relative">
                          <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                          <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@gmail.com"
                            className="w-full bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white rounded-xl pl-10 pr-4 py-3 text-sm font-semibold outline-none transition-all placeholder:text-gray-400"
                            autoFocus
                          />
                        </div>
                        <span className="text-[11px] text-text-secondary mt-1 block">
                          Generate a one-time verification code without passwords.
                        </span>
                      </div>

                      <button
                        type="submit"
                        disabled={isLoading || !email.trim()}
                        className="w-full flex items-center justify-center gap-2 bg-brand text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md hover:bg-brand-dark transition-all disabled:opacity-50 cursor-pointer"
                      >
                        {isLoading ? (
                          <RefreshCw size={18} className="animate-spin" />
                        ) : (
                          <>
                            <Sparkles size={16} />
                            <span>GENERATE EMAIL OTP</span>
                            <ArrowRight size={16} />
                          </>
                        )}
                      </button>
                    </form>
                  ) : (
                    /* Email OTP Verification View */
                    <form onSubmit={handleVerifyEmailOtp} className="space-y-5">
                      {generatedEmailCode && (
                        <motion.div
                          initial={{ scale: 0.95, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 flex items-center justify-between"
                        >
                          <div>
                            <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600">Verification Code</div>
                            <div className="text-base font-black text-gray-900 tracking-widest mt-0.5">
                              {generatedEmailCode}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={autoFillEmailOtp}
                            className="bg-brand text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm hover:bg-brand-dark transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Sparkles size={12} /> Auto-fill Code
                          </button>
                        </motion.div>
                      )}

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest block">
                            Enter 6-Digit Email Code
                          </label>
                          <button
                            type="button"
                            onClick={() => {
                              setEmailStep('input');
                              setEmailOtp(['', '', '', '', '', '']);
                              setStatusMessage(null);
                            }}
                            className="text-xs font-bold text-brand hover:underline cursor-pointer"
                          >
                            Change Email
                          </button>
                        </div>

                        <div className="text-xs text-gray-600 mb-3">
                          Sent to: <span className="font-bold text-gray-900">{email}</span>
                        </div>

                        <div className="grid grid-cols-6 gap-2">
                          {emailOtp.map((digit, index) => (
                            <input
                              key={index}
                              ref={(el) => {
                                emailOtpRefs.current[index] = el;
                              }}
                              type="text"
                              inputMode="numeric"
                              maxLength={6}
                              value={digit}
                              onChange={(e) => handleEmailOtpChange(index, e.target.value)}
                              onKeyDown={(e) => handleEmailOtpKeyDown(index, e)}
                              className="w-full h-12 text-center text-lg font-black bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white focus:ring-2 focus:ring-brand/20 rounded-xl outline-none transition-all"
                            />
                          ))}
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isLoading || emailOtp.join('').length !== 6}
                        className="w-full flex items-center justify-center gap-2 bg-brand text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md hover:bg-brand-dark transition-all disabled:opacity-50 cursor-pointer"
                      >
                        {isLoading ? (
                          <RefreshCw size={18} className="animate-spin" />
                        ) : (
                          <>
                            <ShieldCheck size={18} />
                            <span>VERIFY & SIGN IN</span>
                          </>
                        )}
                      </button>

                      <div className="flex items-center justify-between text-xs text-text-secondary font-medium pt-1">
                        <span>Didn't get code?</span>
                        {countdown > 0 ? (
                          <span className="flex items-center gap-1 font-bold text-gray-500">
                            <Clock size={13} /> Resend in {countdown}s
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleGenerateEmailOtp()}
                            className="font-bold text-brand hover:underline cursor-pointer"
                          >
                            Resend Code Now
                          </button>
                        )}
                      </div>
                    </form>
                  )
                ) : (
                  /* Password login / register */
                  <form onSubmit={handlePasswordAuthSubmit} className="space-y-4">
                    {isRegisterMode && (
                      <div>
                        <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-1.5 block">
                          Full Name
                        </label>
                        <div className="relative">
                          <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                          <input
                            type="text"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            placeholder="Your Name"
                            className="w-full bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white rounded-xl pl-10 pr-4 py-3 text-sm font-semibold outline-none transition-all"
                          />
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest mb-1.5 block">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="you@example.com"
                          className="w-full bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white rounded-xl pl-10 pr-4 py-3 text-sm font-semibold outline-none transition-all"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-[10px] font-black text-text-secondary uppercase tracking-widest block">
                          Password
                        </label>
                        {!isRegisterMode && (
                          <button
                            type="button"
                            onClick={() => setStatusMessage({ text: 'Switch to "Instant Email OTP" tab above to sign in without remembering passwords!', type: 'info' })}
                            className="text-xs text-brand font-semibold hover:underline cursor-pointer"
                          >
                            Forgot Password?
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-gray-50 border border-[#E0E4E9] focus:border-brand focus:bg-white rounded-xl pl-10 pr-10 py-3 text-sm font-semibold outline-none transition-all"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer"
                        >
                          {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full flex items-center justify-center gap-2 bg-brand text-white py-3.5 rounded-xl font-black text-sm tracking-wide shadow-md hover:bg-brand-dark transition-all disabled:opacity-50 cursor-pointer"
                    >
                      {isLoading ? (
                        <RefreshCw size={18} className="animate-spin" />
                      ) : (
                        <span>{isRegisterMode ? 'CREATE ACCOUNT' : 'SIGN IN WITH PASSWORD'}</span>
                      )}
                    </button>

                    <div className="text-center text-xs text-text-secondary font-medium pt-1">
                      {isRegisterMode ? (
                        <>
                          Already have an account?{' '}
                          <button
                            type="button"
                            onClick={() => setIsRegisterMode(false)}
                            className="font-bold text-brand hover:underline cursor-pointer"
                          >
                            Sign In
                          </button>
                        </>
                      ) : (
                        <>
                          Don't have an account?{' '}
                          <button
                            type="button"
                            onClick={() => setIsRegisterMode(true)}
                            className="font-bold text-brand hover:underline cursor-pointer"
                          >
                            Register Now
                          </button>
                        </>
                      )}
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* Clean Secure Trust Footer without Quick Test Access */}
            <div className="mt-8 pt-5 border-t border-gray-100 -mx-6 -mb-6 sm:-mx-8 sm:-mb-8 p-5 bg-gray-50 text-center">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-gray-600 mb-2">
                <ShieldCheck size={16} className="text-green-600" />
                <span>256-Bit Bank-Grade SSL Secure Authentication</span>
              </div>
              <p className="text-[11px] text-gray-400 font-medium">
                Protected by TripVerse Security Shield. By signing in, you accept our{' '}
                <a href="#" className="underline hover:text-brand">Terms of Service</a> &{' '}
                <a href="#" className="underline hover:text-brand">Privacy Policy</a>.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
