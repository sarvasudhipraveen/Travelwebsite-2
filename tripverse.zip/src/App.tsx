import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { AIAssistant } from './components/AIAssistant';
import { AuthProvider } from './lib/AuthContext';
import { CurrencyProvider } from './lib/CurrencyContext';
import { ThemeProvider } from './lib/ThemeContext';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import Home from './pages/Home';
import Flights from './pages/Flights';
import Hotels from './pages/Hotels';
import Holidays from './pages/Holidays';
import Trains from './pages/Trains';
import Buses from './pages/Buses';
import Cabs from './pages/Cabs';
import Bikes from './pages/Bikes';
import AdminPanel from './pages/AdminPanel';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import { AnimatePresence } from 'motion/react';

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CurrencyProvider>
          <Router>
            <div className="min-h-screen flex flex-col font-sans transition-colors duration-300">
              <Navbar />
              <main className="flex-1 overflow-x-hidden relative">
                <AnimatePresence mode="wait">
                  <Routes>
                    {/* Public Authentication Route */}
                    <Route path="/login" element={<Login />} />

                    {/* Protected Routes - Sign in required to view pages and make bookings */}
                    <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                    <Route path="/flights" element={<ProtectedRoute><Flights /></ProtectedRoute>} />
                    <Route path="/hotels" element={<ProtectedRoute><Hotels /></ProtectedRoute>} />
                    <Route path="/trains" element={<ProtectedRoute><Trains /></ProtectedRoute>} />
                    <Route path="/buses" element={<ProtectedRoute><Buses /></ProtectedRoute>} />
                    <Route path="/cabs" element={<ProtectedRoute><Cabs /></ProtectedRoute>} />
                    <Route path="/bikes" element={<ProtectedRoute><Bikes /></ProtectedRoute>} />
                    <Route path="/holidays" element={<ProtectedRoute><Holidays /></ProtectedRoute>} />
                    <Route path="/admin" element={<ProtectedRoute><AdminPanel /></ProtectedRoute>} />
                    <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                    <Route path="*" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                  </Routes>
                </AnimatePresence>
              </main>
              <Footer />
              <AIAssistant />
            </div>
          </Router>
        </CurrencyProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
