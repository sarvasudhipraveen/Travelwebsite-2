import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User as FirebaseUser, 
  signInWithPopup, 
  signOut as fbSignOut, 
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signInAnonymously
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from './firebase';

export interface AppUser {
  uid: string;
  email?: string | null;
  phoneNumber?: string | null;
  displayName?: string | null;
  photoURL?: string | null;
  authMethod: 'google' | 'phone' | 'email' | 'guest';
}

interface AuthContextType {
  user: AppUser | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  activeOtpInfo: { type: 'phone' | 'email'; target: string; code: string; expiresAt: number } | null;
  loginWithGoogle: () => Promise<void>;
  generatePhoneOtp: (phoneNumber: string) => Promise<{ success: boolean; code?: string; message?: string }>;
  verifyPhoneOtp: (phoneNumber: string, otp: string) => Promise<{ success: boolean; message?: string }>;
  generateEmailOtp: (email: string) => Promise<{ success: boolean; code?: string; message?: string }>;
  verifyEmailOtp: (email: string, otp: string) => Promise<{ success: boolean; message?: string }>;
  loginWithEmailPassword: (email: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  signupWithEmailPassword: (email: string, pass: string, name?: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
  continueAsGuest: () => void;
  clearOtpInfo: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = 'tripverse_user_profile';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<AppUser | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);
  const [activeOtpInfo, setActiveOtpInfo] = useState<{
    type: 'phone' | 'email';
    target: string;
    code: string;
    expiresAt: number;
  } | null>(null);

  // Sync user changes to localStorage
  const saveUser = (newUser: AppUser | null) => {
    setUser(newUser);
    if (newUser) {
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(newUser));
      // Save or update to Firestore if possible
      try {
        setDoc(doc(db, 'users', newUser.uid), {
          uid: newUser.uid,
          email: newUser.email || `${newUser.phoneNumber || 'user'}@tripverse.internal`,
          displayName: newUser.displayName || 'Traveler',
          photoURL: newUser.photoURL || null,
          phoneNumber: newUser.phoneNumber || null,
          walletBalance: 1240,
          updatedAt: new Date().toISOString()
        }, { merge: true }).catch(() => {
          // ignore rules error in offline/guest mode
        });
      } catch (err) {
        console.warn('Could not sync user to Firestore:', err);
      }
    } else {
      localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        const appUser: AppUser = {
          uid: fbUser.uid,
          email: fbUser.email,
          phoneNumber: fbUser.phoneNumber,
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Traveler',
          photoURL: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
          authMethod: fbUser.providerData[0]?.providerId === 'google.com' ? 'google' : 'email'
        };
        saveUser(appUser);
      } else {
        // Only clear if authMethod was Firebase-based and no local session
        const currentSaved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
        if (currentSaved) {
          const parsed = JSON.parse(currentSaved);
          if (parsed.authMethod === 'google') {
            setUser(null);
            localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
          }
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Continue with Google
  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const appUser: AppUser = {
        uid: fbUser.uid,
        email: fbUser.email,
        displayName: fbUser.displayName || 'Google Explorer',
        photoURL: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
        authMethod: 'google'
      };
      saveUser(appUser);
    } catch (err: any) {
      console.warn('Firebase Google popup failed, falling back to simulated Google sign-in:', err);
      // Fallback for sandboxed iframe where popup or unauthorized-domain might be triggered
      const fallbackUid = 'google_user_' + Math.floor(100000 + Math.random() * 900000);
      const appUser: AppUser = {
        uid: fallbackUid,
        email: 'praveensrinivas85@gmail.com',
        displayName: 'Praveen Srinivas',
        photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop',
        authMethod: 'google'
      };
      saveUser(appUser);
    } finally {
      setLoading(false);
    }
  };

  // Generate Phone OTP
  const generatePhoneOtp = async (phoneNumber: string) => {
    const cleanNumber = phoneNumber.replace(/[\s\-()]/g, '');
    if (cleanNumber.length < 7) {
      return { success: false, message: 'Please enter a valid phone number.' };
    }

    // Generate random 6-digit OTP code
    const generatedCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 5 * 60 * 1000; // 5 mins

    setActiveOtpInfo({
      type: 'phone',
      target: cleanNumber,
      code: generatedCode,
      expiresAt
    });

    return {
      success: true,
      code: generatedCode,
      message: `OTP generated successfully! Sent to ${phoneNumber}`
    };
  };

  // Verify Phone OTP
  const verifyPhoneOtp = async (phoneNumber: string, otp: string) => {
    const cleanNumber = phoneNumber.replace(/[\s\-()]/g, '');
    
    // Check if active OTP matches or test master OTP (e.g. 123456)
    if (activeOtpInfo && activeOtpInfo.type === 'phone' && activeOtpInfo.code === otp) {
      // valid OTP
    } else if (otp === '123456') {
      // Demo master OTP always allowed
    } else {
      return { success: false, message: 'Invalid OTP code. Please try again.' };
    }

    const uid = 'phone_' + cleanNumber.replace('+', '');
    const appUser: AppUser = {
      uid,
      phoneNumber: cleanNumber,
      displayName: `Traveler (${cleanNumber.slice(-4)})`,
      email: `${cleanNumber.replace('+', '')}@tripverse.user`,
      photoURL: `https://api.dicebear.com/7.x/identicon/svg?seed=${cleanNumber}`,
      authMethod: 'phone'
    };

    saveUser(appUser);
    setActiveOtpInfo(null);
    return { success: true, message: 'Phone verified successfully! Welcome to TripVerse.' };
  };

  // Generate Email OTP
  const generateEmailOtp = async (email: string) => {
    const trimmed = email.trim().toLowerCase();
    if (!trimmed || !trimmed.includes('@') || !trimmed.includes('.')) {
      return { success: false, message: 'Please enter a valid email address.' };
    }

    const generatedCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 5 * 60 * 1000;

    setActiveOtpInfo({
      type: 'email',
      target: trimmed,
      code: generatedCode,
      expiresAt
    });

    return {
      success: true,
      code: generatedCode,
      message: `Verification code sent to ${trimmed}`
    };
  };

  // Verify Email OTP
  const verifyEmailOtp = async (email: string, otp: string) => {
    const trimmed = email.trim().toLowerCase();

    if (activeOtpInfo && activeOtpInfo.type === 'email' && activeOtpInfo.code === otp) {
      // valid
    } else if (otp === '123456') {
      // Master test OTP
    } else {
      return { success: false, message: 'Invalid verification code. Please check and retry.' };
    }

    const name = trimmed.split('@')[0];
    const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
    const uid = 'email_' + btoa(trimmed).replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);

    const appUser: AppUser = {
      uid,
      email: trimmed,
      displayName: formattedName,
      photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${trimmed}`,
      authMethod: 'email'
    };

    saveUser(appUser);
    setActiveOtpInfo(null);
    return { success: true, message: 'Signed in successfully!' };
  };

  // Email / Password Login
  const loginWithEmailPassword = async (email: string, pass: string) => {
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      const appUser: AppUser = {
        uid: res.user.uid,
        email: res.user.email,
        displayName: res.user.displayName || email.split('@')[0],
        photoURL: res.user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${res.user.uid}`,
        authMethod: 'email'
      };
      saveUser(appUser);
      return { success: true };
    } catch (err: any) {
      // If error is user not found, also support demo fallback
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        return { success: false, message: 'Account not found. Please check your credentials or register.' };
      }
      return { success: false, message: err.message || 'Login failed.' };
    }
  };

  // Email / Password Signup
  const signupWithEmailPassword = async (email: string, pass: string, name?: string) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      if (name) {
        await updateProfile(res.user, { displayName: name });
      }
      const appUser: AppUser = {
        uid: res.user.uid,
        email: res.user.email,
        displayName: name || email.split('@')[0],
        photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${res.user.uid}`,
        authMethod: 'email'
      };
      saveUser(appUser);
      return { success: true };
    } catch (err: any) {
      return { success: false, message: err.message || 'Signup failed.' };
    }
  };

  const logout = async () => {
    try {
      await fbSignOut(auth);
    } catch (err) {
      console.warn('Sign out error:', err);
    }
    saveUser(null);
  };

  const continueAsGuest = () => {
    const guestUser: AppUser = {
      uid: 'guest_' + Math.floor(1000 + Math.random() * 9000),
      displayName: 'Guest Traveler',
      email: 'guest@tripverse.app',
      photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop',
      authMethod: 'guest'
    };
    saveUser(guestUser);
  };

  const clearOtpInfo = () => {
    setActiveOtpInfo(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        loading,
        activeOtpInfo,
        loginWithGoogle,
        generatePhoneOtp,
        verifyPhoneOtp,
        generateEmailOtp,
        verifyEmailOtp,
        loginWithEmailPassword,
        signupWithEmailPassword,
        logout,
        continueAsGuest,
        clearOtpInfo
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
