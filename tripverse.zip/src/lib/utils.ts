import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const USD_TO_INR_RATE = 84;

/**
 * Formats a price in USD into dual currency display: Rupees (₹) and Dollars ($)
 */
export function formatDualPrice(usdAmount: number) {
  const inr = Math.round(usdAmount * USD_TO_INR_RATE);
  return {
    inr: `₹${inr.toLocaleString('en-IN')}`,
    usd: `$${usdAmount.toLocaleString('en-US')}`,
    combined: `₹${inr.toLocaleString('en-IN')} ($${usdAmount.toLocaleString('en-US')})`,
    badge: `₹${inr.toLocaleString('en-IN')} • $${usdAmount.toLocaleString('en-US')}`
  };
}

/**
 * Formats a price in INR into dual currency display: Rupees (₹) and Dollars ($)
 */
export function formatInrPrice(inrAmount: number) {
  const usd = +(inrAmount / USD_TO_INR_RATE).toFixed(1);
  return {
    inr: `₹${inrAmount.toLocaleString('en-IN')}`,
    usd: `$${usd.toLocaleString('en-US')}`,
    combined: `₹${inrAmount.toLocaleString('en-IN')} ($${usd.toLocaleString('en-US')})`,
    badge: `₹${inrAmount.toLocaleString('en-IN')} • $${usd.toLocaleString('en-US')}`
  };
}
