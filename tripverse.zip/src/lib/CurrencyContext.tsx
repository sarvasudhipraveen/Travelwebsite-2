import React, { createContext, useContext, useState, useEffect } from 'react';

export type Currency = 'INR' | 'USD';

export const USD_TO_INR_RATE = 84;

export interface PriceDisplay {
  primaryValue: number;
  primaryFormatted: string;
  secondaryValue: number;
  secondaryFormatted: string;
  symbol: string;
  combined: string;
  badge: string;
}

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  toggleCurrency: () => void;
  rate: number;
  symbol: string;
  formatPrice: (usdAmount: number, options?: { showSecondary?: boolean }) => string;
  formatFromInr: (inrAmount: number, options?: { showSecondary?: boolean }) => string;
  convertUsd: (usdAmount: number) => PriceDisplay;
  convertInr: (inrAmount: number) => PriceDisplay;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'tripverse_currency';

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrencyState] = useState<Currency>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      return (saved === 'USD' || saved === 'INR') ? saved : 'INR';
    } catch {
      return 'INR';
    }
  });

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, newCurrency);
    } catch (err) {
      console.warn('Could not save currency to localStorage:', err);
    }
  };

  const toggleCurrency = () => {
    setCurrency(currency === 'INR' ? 'USD' : 'INR');
  };

  const symbol = currency === 'INR' ? '₹' : '$';

  /**
   * Formats a USD base amount according to the current active currency.
   * If currency is 'INR', converts using USD_TO_INR_RATE and prepends ₹.
   * If currency is 'USD', prepends $.
   * If showSecondary is true, also appends the other currency in parentheses.
   */
  const formatPrice = (usdAmount: number, options?: { showSecondary?: boolean }) => {
    const inrValue = Math.round(usdAmount * USD_TO_INR_RATE);
    const inrFormatted = `₹${inrValue.toLocaleString('en-IN')}`;
    const usdFormatted = `$${usdAmount.toLocaleString('en-US')}`;

    if (currency === 'INR') {
      return options?.showSecondary ? `${inrFormatted} (${usdFormatted})` : inrFormatted;
    } else {
      return options?.showSecondary ? `${usdFormatted} (${inrFormatted})` : usdFormatted;
    }
  };

  /**
   * Formats an INR base amount (like bike rentals) according to current active currency.
   */
  const formatFromInr = (inrAmount: number, options?: { showSecondary?: boolean }) => {
    const usdValue = +(inrAmount / USD_TO_INR_RATE).toFixed(1);
    const inrFormatted = `₹${inrAmount.toLocaleString('en-IN')}`;
    const usdFormatted = `$${usdValue.toLocaleString('en-US')}`;

    if (currency === 'INR') {
      return options?.showSecondary ? `${inrFormatted} (${usdFormatted})` : inrFormatted;
    } else {
      return options?.showSecondary ? `${usdFormatted} (${inrFormatted})` : usdFormatted;
    }
  };

  /**
   * Converts a USD base amount into a comprehensive dual-currency object
   * prioritizing the globally selected active currency.
   */
  const convertUsd = (usdAmount: number): PriceDisplay => {
    const inrValue = Math.round(usdAmount * USD_TO_INR_RATE);
    const inrFormatted = `₹${inrValue.toLocaleString('en-IN')}`;
    const usdFormatted = `$${usdAmount.toLocaleString('en-US')}`;

    if (currency === 'INR') {
      return {
        primaryValue: inrValue,
        primaryFormatted: inrFormatted,
        secondaryValue: usdAmount,
        secondaryFormatted: usdFormatted,
        symbol: '₹',
        combined: `${inrFormatted} (${usdFormatted})`,
        badge: `${inrFormatted} • ${usdFormatted}`
      };
    } else {
      return {
        primaryValue: usdAmount,
        primaryFormatted: usdFormatted,
        secondaryValue: inrValue,
        secondaryFormatted: inrFormatted,
        symbol: '$',
        combined: `${usdFormatted} (${inrFormatted})`,
        badge: `${usdFormatted} • ${inrFormatted}`
      };
    }
  };

  /**
   * Converts an INR base amount (e.g. for Indian bike rentals) into a comprehensive
   * dual-currency object prioritizing the globally selected active currency.
   */
  const convertInr = (inrAmount: number): PriceDisplay => {
    const usdValue = +(inrAmount / USD_TO_INR_RATE).toFixed(1);
    const inrFormatted = `₹${inrAmount.toLocaleString('en-IN')}`;
    const usdFormatted = `$${usdValue.toLocaleString('en-US')}`;

    if (currency === 'INR') {
      return {
        primaryValue: inrAmount,
        primaryFormatted: inrFormatted,
        secondaryValue: usdValue,
        secondaryFormatted: usdFormatted,
        symbol: '₹',
        combined: `${inrFormatted} (${usdFormatted})`,
        badge: `${inrFormatted} • ${usdFormatted}`
      };
    } else {
      return {
        primaryValue: usdValue,
        primaryFormatted: usdFormatted,
        secondaryValue: inrAmount,
        secondaryFormatted: inrFormatted,
        symbol: '$',
        combined: `${usdFormatted} (${inrFormatted})`,
        badge: `${usdFormatted} • ${inrFormatted}`
      };
    }
  };

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        setCurrency,
        toggleCurrency,
        rate: USD_TO_INR_RATE,
        symbol,
        formatPrice,
        formatFromInr,
        convertUsd,
        convertInr
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};
