import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Gemini API Key from environment or explicit key provided by user
const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || "AQ.Ab8RN6K64pq_K4PCGLgnNH9Ae-JR45IEo9psHEZsUPWG01MqoQ";

// Initialize Gemini API with modern @google/genai SDK
const genAI = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json());

// Real-Time AI Travel Assistant Endpoint (Handles both /api/chat and /api/ai/chat)
const handleChat = async (req: express.Request, res: express.Response) => {
  try {
    const { message, history } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: "Message is required" });
    }

    const formattedHistory = Array.isArray(history) 
      ? history.map((item: any) => ({
          role: item.role === 'model' ? 'model' : 'user',
          parts: Array.isArray(item.parts) ? item.parts : [{ text: item.text || '' }]
        }))
      : [];

    const chat = genAI.chats.create({
      model: "gemini-3.8-flash",
      config: {
        systemInstruction: `You are 'TripBot', the real-time AI travel assistant for TripVerse (a premier global travel platform).
Your key capabilities:
1. Dynamic travel itineraries and destination recommendations (Goa, Dubai, Paris, Tokyo, Bali, New York, Delhi, Manali, etc.).
2. Person/Passenger budget calculations: Always explain how price changes dynamically with traveler count (e.g., "For 2 travelers, base flight fare is ₹11,000, taxes ₹1,320, total ₹12,320. For 4 travelers, it scales to ₹24,640").
3. Helping travelers choose between flights, express trains (Vande Bharat, Rajdhani), luxury cabs & self-drive cars, rental bikes, buses, and resort hotels.
4. Formatting responses with clean markdown, bullet points, highlighted numbers, and pricing estimates in both INR (₹) and USD ($).
Be enthusiastic, accurate, fast, and helpful!`,
      },
      history: formattedHistory,
    });

    const response = await chat.sendMessage({ message });
    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Error:", error);
    // Return friendly travel assistance fallback if API key quota or transient issue occurs
    res.json({
      text: `Hello! I'm your TripVerse AI Travel Assistant.\n\n` +
            `Here are quick recommendations for your trip:\n` +
            `• **Dynamic Traveler Pricing**: When you adjust the number of travelers (passengers, guests, riders), TripVerse automatically recalculates fares, taxes, and discounts in real time.\n` +
            `• **Trending Destinations**: Goa (Beaches & Nightlife), Dubai (Desert Safari & Luxury), Kashmir & Manali (Snow & Valleys), Bali (Tropical Escapes).\n` +
            `• **Booking Modes**: Check out our **Flights**, **Hotels**, **Trains**, **Cars & Cabs**, and **Bikes** in the navigation bar above!`
    });
  }
};

app.post("/api/chat", handleChat);
app.post("/api/ai/chat", handleChat);

async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start();
